from pathlib import Path
import base64,gzip,hashlib,json
root=Path(__file__).resolve().parent
base=gzip.decompress((root.parent/'index.html.gz').read_bytes())
payload=''.join((root/f'web-delta-{i}.b64').read_text() for i in range(4))
delta=json.loads(gzip.decompress(base64.b64decode(payload)))
assert hashlib.sha256(base).hexdigest()==delta['base_sha256'], 'Source HTML changed; update delta first.'
lines=base.decode().splitlines(True)
for start,end,new in reversed(delta['operations']): lines[start:end]=new
target=''.join(lines).encode()
assert hashlib.sha256(target).hexdigest()==delta['target_sha256'], 'Reconstruction mismatch'
out=root/'app/src/main/assets/index.html'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(target)
print('Verified exact native HTML:',len(target),'bytes')
