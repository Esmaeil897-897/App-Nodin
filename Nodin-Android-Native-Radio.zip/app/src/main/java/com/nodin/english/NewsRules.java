package com.nodin.english;
import android.content.Context;
import org.json.*;
import java.util.*;
@androidx.media3.common.util.UnstableApi
final class NewsRules {
 static JSONArray read(Context c){try{return new JSONArray(DailyNews.prefs(c).getString("rules","[]"));}catch(Exception e){return new JSONArray();}}
 static JSONArray clean(JSONArray input){LinkedHashMap<String,JSONObject> out=new LinkedHashMap<>();if(input==null)return new JSONArray();for(int i=0;i<Math.min(30,input.length());i++){JSONObject a=input.optJSONObject(i);if(a==null)continue;String cat=a.optString("category"),country=a.optString("country","all"),lang=a.optString("language","fa");if(!DailyNews.CATEGORIES.contains(cat)||cat.equals("all"))continue;if(!cat.equals("migration"))country="all";else if(!DailyNews.COUNTRIES.contains(country))continue;if(!Arrays.asList("fa","en","both").contains(lang))lang="fa";String key=cat+":"+country;try{out.put(key,new JSONObject().put("key",key).put("category",cat).put("country",country).put("language",lang).put("enabled",a.optBoolean("enabled",false)).put("interval",DailyNews.bound(a.optInt("interval",20),1,30)).put("count",DailyNews.bound(a.optInt("count",1),1,5)).put("older",a.optBoolean("older",false)));}catch(Exception ignored){}}return new JSONArray(out.values());}
 static void save(Context c,JSONArray input){DailyNews.prefs(c).edit().putString("rules",clean(input).toString()).apply();}
 static int minimum(Context c){JSONArray rules=read(c);if(rules.length()==0)return DailyNews.interval(c);int min=30;for(int i=0;i<rules.length();i++){JSONObject r=rules.optJSONObject(i);if(r!=null&&r.optBoolean("enabled"))min=Math.min(min,r.optInt("interval",20));}return min;}
 static boolean active(Context c){JSONArray rules=read(c);for(int i=0;i<rules.length();i++)if(rules.optJSONObject(i).optBoolean("enabled"))return true;return false;}
}
