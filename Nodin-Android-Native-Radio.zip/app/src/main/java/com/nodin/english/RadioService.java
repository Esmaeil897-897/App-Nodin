package com.nodin.english;

import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.*;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.*;

@androidx.media3.common.util.UnstableApi
public class RadioService extends MediaSessionService {
    private ExoPlayer player;
    private MediaSession session;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable retry;
    private int retries;
    private WindowManager wm;
    private LinearLayout bubble;
    private TextView badge;
    private LinearLayout controls;
    private WindowManager.LayoutParams params;
    private boolean expanded;
    @Override public void onCreate(){
        super.onCreate();
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory()
            .setUserAgent("NodinAndroid/7").setConnectTimeoutMs(15000).setReadTimeoutMs(20000);
        player=new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true)
            .setHandleAudioBecomingNoisy(true).setWakeMode(C.WAKE_MODE_NETWORK).build();
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        session=new MediaSession.Builder(this,player).setSessionActivity(open).build();
        player.addListener(new Player.Listener(){
            @Override public void onEvents(Player p,Player.Events events){
                if(p.getCurrentMediaItem()==null){cancelRetry();hideBubble();}
                if(badge!=null)badge.setText(p.isPlaying()?"📻":"📻\nⅡ");
            }
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_READY){retries=0;cancelRetry();}
            }
            @Override public void onMediaItemTransition(MediaItem item,int reason){retries=0;cancelRetry();}
            @Override public void onPlayWhenReadyChanged(boolean ready,int reason){if(!ready)cancelRetry();}
            @Override public void onPlayerError(PlaybackException error){
                if(!player.getPlayWhenReady())return;
                if(error.errorCode!=PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED &&
                   error.errorCode!=PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT &&
                   error.errorCode!=PlaybackException.ERROR_CODE_IO_UNSPECIFIED)return;
                cancelRetry();
                if(++retries>6)return;
                String id=player.getCurrentMediaItem()==null?"":player.getCurrentMediaItem().mediaId;
                retry=()->{
                    if(player.getPlayWhenReady() && player.getCurrentMediaItem()!=null && id.equals(player.getCurrentMediaItem().mediaId)){
                        player.prepare();player.play();
                    }
                };
                handler.postDelayed(retry,Math.min(30000,1000L<<(retries-1)));
            }
        });
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info){return session;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        int result=super.onStartCommand(intent,flags,startId);
        if(intent!=null && "overlay".equals(intent.getAction())){
            if(getSharedPreferences("native",MODE_PRIVATE).getBoolean("overlay",false) &&
                Settings.canDrawOverlays(this) && player.getCurrentMediaItem()!=null)showBubble();
            else hideBubble();
        }
        return result;
    }
    private void cancelRetry(){if(retry!=null){handler.removeCallbacks(retry);retry=null;}}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView button(String text,Runnable action){
        TextView b=new TextView(this);b.setText(text);b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);b.setTextSize(20);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(48),dp(56)));
        b.setOnClickListener(v->action.run());return b;
    }
    private void showBubble(){
        if(bubble!=null)return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        bubble=new LinearLayout(this);bubble.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(2,84,124));bg.setCornerRadius(dp(30));
        bubble.setBackground(bg);bubble.setElevation(dp(8));
        badge=button("📻",()->{});badge.setContentDescription("رادیوی شناور؛ لمس برای کنترل، کشیدن برای جابه‌جایی");
        bubble.addView(badge);
        controls=new LinearLayout(this);controls.setVisibility(View.GONE);
        controls.addView(button("▶Ⅱ",()->{if(player.getPlayWhenReady()){player.pause();}else{if(player.getPlaybackState()==Player.STATE_IDLE)player.prepare();player.play();}}));
        controls.addView(button("■",()->{player.pause();player.stop();player.clearMediaItems();hideBubble();}));
        controls.addView(button("↗",()->startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP))));
        controls.addView(button("×",()->{getSharedPreferences("native",MODE_PRIVATE).edit().putBoolean("overlay",false).apply();hideBubble();}));
        bubble.addView(controls);
        params=new WindowManager.LayoutParams(dp(56),dp(56),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(160);
        badge.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy;int ox,oy;boolean moved;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;moved=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){
                    float dx=e.getRawX()-sx,dy=e.getRawY()-sy;
                    if(Math.abs(dx)+Math.abs(dy)>dp(8))moved=true;
                    params.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-params.width,ox+(int)dx));
                    params.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-params.height,oy+(int)dy));
                    try{wm.updateViewLayout(bubble,params);}catch(Exception ignored){}return true;
                }
                if(e.getAction()==MotionEvent.ACTION_UP){
                    if(!moved){expanded=!expanded;controls.setVisibility(expanded?View.VISIBLE:View.GONE);params.width=dp(expanded?248:56);
                        params.x=Math.max(0,Math.min(params.x,getResources().getDisplayMetrics().widthPixels-params.width));
                        try{wm.updateViewLayout(bubble,params);}catch(Exception ignored){}}
                    return true;
                }return true;
            }
        });
        try{wm.addView(bubble,params);}catch(Exception e){bubble=null;badge=null;}
    }
    private void hideBubble(){if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;badge=null;expanded=false;}}
    @Override public void onDestroy(){cancelRetry();hideBubble();player.release();session.release();super.onDestroy();}
}
