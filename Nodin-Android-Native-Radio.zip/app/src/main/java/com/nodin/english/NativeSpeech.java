package com.nodin.english;
import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.*;
import android.media.AudioAttributes;
import android.webkit.WebView;
import java.util.*;
import org.json.*;

final class NativeSpeech {
 private final Activity activity;
 private final WebView web;
 private TextToSpeech tts;
 private boolean ready, failed, closed;
 private JSONObject pending;
 private String active="";
 private final Map<String,Integer> offsets=new HashMap<>();
 private String first="",last="";
 NativeSpeech(Activity a,WebView w){
  activity=a;web=w;
  tts=new TextToSpeech(a,status->a.runOnUiThread(()->{
   if(closed)return;
   ready=status==TextToSpeech.SUCCESS; failed=!ready;
   if(ready){
    tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
    tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
     public void onStart(String id){activity.runOnUiThread(()->{if(id.equals(first))event(active,"start","");});}
     public void onDone(String id){activity.runOnUiThread(()->{if(id.equals(last)){event(active,"end","");active="";}});}
     public void onError(String id){activity.runOnUiThread(()->{if(offsets.containsKey(id)){event(active,"error","خطا در پخش گفتار دستگاه");active="";}});}
     public void onStop(String id,boolean interrupted){}
     public void onRangeStart(String id,int start,int end,int frame){activity.runOnUiThread(()->{if(offsets.containsKey(id))boundary(active,start+offsets.get(id));});}
    });
   }
   publishVoices();
   if(pending!=null){JSONObject p=pending;pending=null;speak(p);}
  }));
 }
 void publishVoices(){
  if(closed)return;
  JSONArray voices=new JSONArray();
  if(ready && tts!=null && tts.getVoices()!=null){
   for(Voice v:tts.getVoices())try{
    JSONObject o=new JSONObject();o.put("name",v.getName());o.put("voiceURI",v.getName());o.put("lang",v.getLocale().toLanguageTag());o.put("localService",!v.isNetworkConnectionRequired());o.put("default",false);voices.put(o);
   }catch(Exception ignored){}
  }
  web.evaluateJavascript("window.onNodinVoices && window.onNodinVoices("+voices+","+ready+");",null);
 }
 void speak(JSONObject p){
  if(closed)return;
  String id=p.optString("id"),text=p.optString("text");
  if(!ready){if(failed){event(id,"error","موتور گفتار دستگاه در دسترس نیست؛ در تنظیمات اندروید موتور و صدای انگلیسی را نصب یا فعال کنید.");}else {pending=p;}return;}
  stop(); active=id;
  Locale locale=Locale.forLanguageTag(p.optString("lang","en-GB"));
  int available=tts.setLanguage(locale);
  if(available<0){event(id,"error","صدای این زبان نصب نیست؛ از تنظیمات گفتار اندروید دادهٔ صوتی انگلیسی را نصب کنید.");active="";return;}
  String uri=p.optString("voiceURI");
  Set<Voice> voices=tts.getVoices();Voice chosen=null;
  if(voices!=null)for(Voice v:voices){
   if(!uri.isEmpty() && v.getName().equals(uri) && v.getLocale().getLanguage().equals(locale.getLanguage())){chosen=v;break;}
   if(uri.isEmpty() && v.getLocale().equals(locale) && !v.isNetworkConnectionRequired())chosen=v;
  }
  if(chosen!=null)tts.setVoice(chosen);
  tts.setSpeechRate((float)Math.max(.1,Math.min(2,p.optDouble("rate",.92))));
  tts.setPitch((float)Math.max(.1,Math.min(2,p.optDouble("pitch",1))));
  Bundle params=new Bundle();params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,(float)Math.max(0,Math.min(1,p.optDouble("volume",1))));
  int limit=TextToSpeech.getMaxSpeechInputLength()-1;
  List<String> chunks=new ArrayList<>();List<Integer> starts=new ArrayList<>();
  for(int start=0;start<text.length();){int end=Math.min(text.length(),start+limit);if(end<text.length()){int space=text.lastIndexOf(' ',end);if(space>start)end=space+1;else if(Character.isHighSurrogate(text.charAt(end-1)))end--;}
   starts.add(start);chunks.add(text.substring(start,end));start=end;}
  if(chunks.isEmpty()){event(id,"end","");active="";return;}
  first=id+":0";last=id+":"+(chunks.size()-1);
  for(int i=0;i<chunks.size();i++){String part=id+":"+i;offsets.put(part,starts.get(i));if(tts.speak(chunks.get(i),i==0?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,params,part)==TextToSpeech.ERROR){event(id,"error","درخواست گفتار اجرا نشد");active="";break;}}
 }
 void stop(){pending=null;active="";first="";last="";offsets.clear();if(tts!=null)tts.stop();}
 private void event(String id,String type,String message){if(closed||id.isEmpty())return;web.evaluateJavascript("window.onNodinSpeech && window.onNodinSpeech("+JSONObject.quote(id)+","+JSONObject.quote(type)+","+JSONObject.quote(message)+");",null);}
 private void boundary(String id,int index){if(closed||id.isEmpty())return;web.evaluateJavascript("window.onNodinSpeech && window.onNodinSpeech("+JSONObject.quote(id)+",'boundary',"+index+");",null);}
 void close(){stop();closed=true;if(tts!=null)tts.shutdown();}
}
