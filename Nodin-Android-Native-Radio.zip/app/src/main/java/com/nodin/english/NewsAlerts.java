package com.nodin.english;

import android.content.Context;
import androidx.work.*;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/** Durable delayed checks; Android may defer them during Doze. No exact alarm permission. */
@androidx.media3.common.util.UnstableApi
public class NewsAlerts extends Worker {
 static final String WORK="nodin_news_alerts_v1";
 public NewsAlerts(Context context,WorkerParameters parameters){super(context,parameters);}
 static void ensure(Context context,boolean successor,long expectedRevision){
  synchronized(DailyNews.class){
   android.content.SharedPreferences p=DailyNews.prefs(context);long revision=p.getLong("revision",0);
   if(!p.getBoolean("enabled",false)||(expectedRevision>=0&&revision!=expectedRevision))return;
   OneTimeWorkRequest request=new OneTimeWorkRequest.Builder(NewsAlerts.class).addTag(WORK)
    .setInputData(new Data.Builder().putLong("revision",revision).build())
    .setInitialDelay(NewsRules.minimum(context),TimeUnit.MINUTES)
    .setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();
   WorkManager.getInstance(context).enqueueUniqueWork(WORK+"_"+revision,successor?ExistingWorkPolicy.APPEND_OR_REPLACE:ExistingWorkPolicy.KEEP,request);
  }
 }
 @Override public Result doWork(){
  Context context=getApplicationContext();long revision=getInputData().getLong("revision",-1);
  if(revision!=DailyNews.prefs(context).getLong("revision",0)||!DailyNews.prefs(context).getBoolean("enabled",false))return Result.success();
  try {
   DailyNews.deliver(context,false,this::isStopped,(value,from,to)->{if(isStopped())throw new IOException("Cancelled");return NewsTranslation.fetch(context,value,from,to);});
   return Result.success();
  } catch(Exception failure){DailyNews.prefs(context).edit().putString("delivery_state","error").apply();return Result.success();}
  finally {if(!isStopped())ensure(context,true,revision);}
 }
}
