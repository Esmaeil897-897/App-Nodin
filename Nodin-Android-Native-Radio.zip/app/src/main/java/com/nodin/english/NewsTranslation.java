package com.nodin.english;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

/** Short notification translations, with bounded cache and explicit source fallback. */
@androidx.media3.common.util.UnstableApi
final class NewsTranslation {
 interface Translator { String translate(String text,String source,String target) throws Exception; }
 static final class Display { final String title,body;Display(String t,String b){title=t;body=b;} }
 static String language(String text){
  if(text.matches("(?s).*[\\u0600-\\u06ff].*"))return "fa";
  if(text.matches("(?s).*[\\u0370-\\u03ff].*"))return "el";
  if(text.matches("(?s).*[çÇğĞıİşŞ].*"))return "tr";
  if(text.matches("(?is).*\\b(migranti|immigrazione|sbarcati|rifugiati|soccorso)\\b.*"))return "it";
  return "en";
 }
 static String translated(String value,String from,String to,Translator tr)throws Exception{
  if(value.isEmpty()||from.equals(to))return value;
  String translated=tr.translate(value,from,to);
  if(translated==null||translated.trim().isEmpty()||translated.equalsIgnoreCase(value))throw new IOException("Translation unavailable");
  return translated;
 }
 static boolean correctLanguage(String value,String target){if(value.isEmpty())return true;return target.equals("fa")?value.matches("(?s).*[\\u0600-\\u06ff].*"):!value.matches("(?s).*[\\u0600-\\u06ff\\u0370-\\u03ff].*");}
 static String sourceName(String value,String mode){if(!mode.equals("fa"))return value;String source=value.toLowerCase(Locale.ROOT);String[][] names={{"bbc","بی‌بی‌سی"},{"guardian","گاردین"},{"euronews","یورونیوز"},{"infomigrants","اینفومایگرنتس"},{"playstation","پلی‌استیشن"},{"xbox","ایکس‌باکس"},{"ansa","آنسا"},{"sky","اسکای نیوز"},{"goc.gov","ادارهٔ مهاجرت"},{"sg.gov","گارد ساحلی ترکیه"},{"hcg.gr","گارد ساحلی یونان"},{"astynomia","پلیس یونان"},{"icisleri","وزارت کشور ترکیه"}};for(String[] name:names)if(source.contains(name[0]))return name[1];return "منبع خبر";}
 static Display display(DailyNews.Story s,String mode,Translator tr){
  String rawTitle=DailyNews.shorten(s.title,150),rawBody=DailyNews.shorten(s.desc,180),from=language(rawTitle+" "+rawBody);if(from.equals("en")&&s.link.matches("https://(?:www\\.)?(?:goc|sg|icisleri)\\.gov\\.tr/.*"))from="tr";if(from.equals("en")&&s.link.contains("ansa.it/")&&!s.link.contains("/english/"))from="it";
  try {
   String target=mode.equals("en")?"en":"fa";
   String title=translated(rawTitle,from,target,tr),body=translated(rawBody,from,target,tr);
   if(!correctLanguage(title,target)||!correctLanguage(body,target))return null;
   String country=DailyNews.countryName(s.country);if(country.contains(" / "))country=country.split(" / ")[mode.equals("en")?1:0];
   String source=sourceName(s.source,mode)+(country.isEmpty()?"":" • "+country);
   String expanded=source+"\n"+body;
   if(mode.equals("both")){String enTitle=translated(rawTitle,from,"en",tr),enBody=translated(rawBody,from,"en",tr);if(!correctLanguage(enTitle,"en")||!correctLanguage(enBody,"en"))return null;expanded+="\n\n"+enTitle+"\n"+enBody;}
   return new Display(title,expanded.trim());
  } catch(Exception e){return null;} // Never substitute an English story for a Persian-only notice.
 }
 static String read(InputStream in)throws IOException{try(InputStream input=in){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=input.read(b))!=-1)out.write(b,0,n);return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
 static List<String> chunks(String value){List<String> out=new ArrayList<>();StringBuilder chunk=new StringBuilder();int bytes=0;for(int i=0;i<value.length();){int cp=value.codePointAt(i);String letter=new String(Character.toChars(cp));int size=letter.getBytes(StandardCharsets.UTF_8).length;if(bytes+size>450){out.add(chunk.toString());chunk.setLength(0);bytes=0;}chunk.append(letter);bytes+=size;i+=Character.charCount(cp);}if(chunk.length()>0)out.add(chunk.toString());return out;}
 static String fetch(Context c,String value,String from,String to)throws Exception{
  String key=Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest((from+"|"+to+"|"+value).getBytes(StandardCharsets.UTF_8)));
  android.content.SharedPreferences p=c.getSharedPreferences("news_translation",Context.MODE_PRIVATE);
  String cached=p.getString(key,"");if(!cached.isEmpty())return cached;
  List<String> parts=new ArrayList<>();
  for(String part:chunks(value)){
   String url="https://api.mymemory.translated.net/get?q="+Uri.encode(part)+"&langpair="+Uri.encode(from+"|"+to);
   android.webkit.WebResourceResponse response=NativeNews.fetch(Uri.parse("https://appassets.androidplatform.net/native-news?url="+Uri.encode(url)));
   if(response.getStatusCode()!=200){response.getData().close();throw new IOException("Translation HTTP");}
   JSONObject data=new JSONObject(read(response.getData()));String translated=DailyNews.text(data.optJSONObject("responseData")==null?"":data.getJSONObject("responseData").optString("translatedText"));
   if(data.optInt("responseStatus")!=200||translated.isEmpty()||translated.toUpperCase(Locale.ROOT).contains("MYMEMORY WARNING")||translated.toUpperCase(Locale.ROOT).contains("QUERY LENGTH LIMIT")||(to.equals("fa")&&!translated.matches("(?s).*[\\u0600-\\u06ff].*")))throw new IOException("Translation unavailable");
   parts.add(translated);
  }
  String result=String.join("",parts);
  android.content.SharedPreferences.Editor editor=p.edit();if(p.getAll().size()>=150)editor.clear();editor.putString(key,result).apply();return result;
 }
}
