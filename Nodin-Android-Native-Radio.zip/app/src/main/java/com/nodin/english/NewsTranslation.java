package com.nodin.english;

import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

/** Short notification translations, with bounded cache and explicit source fallback. */
@androidx.media3.common.util.UnstableApi
final class NewsTranslation {
 interface Translator { String translate(String text,String source,String target) throws Exception; }
 static final class Display { final String title,body;Display(String t,String b){title=t;body=b;} }
 static String language(String text){
  if(text.matches("(?s).*[\\u0600-\\u06ff].*"))return "fa";
  if(text.matches("(?s).*[\\u0370-\\u03ff].*"))return "el";
  if(text.matches("(?s).*[çÇğĞıİşŞ].*"))return "tr";
  if(text.matches("(?is).*\\b(migranti|immigrazione|sbarcati|rifugiati|soccorso)\\b.*"))return "it";
  return "en";
 }
 static String translated(String value,String from,String to,Translator tr)throws Exception{
  if(value.isEmpty()||from.equals(to))return value;
  String translated=tr.translate(value,from,to);
  if(translated==null||translated.trim().isEmpty()||translated.equalsIgnoreCase(value))throw new IOException("Translation unavailable");
  return translated;
 }
 static Display display(DailyNews.Story s,String mode,Translator tr){
  String rawTitle=DailyNews.shorten(s.title,150),rawBody=DailyNews.shorten(s.desc,180),from=language(rawTitle+" "+rawBody);
  String source=s.source+(s.country.isEmpty()?"":" • "+(mode.equals("en")?DailyNews.countryName(s.country).split(" / ")[1]:DailyNews.countryName(s.country)));
  try {
   String target=mode.equals("en")?"en":"fa";
   String title=translated(rawTitle,from,target,tr),body=translated(rawBody,from,target,tr);
   String expanded=source+"\n"+body;
   if(mode.equals("both"))expanded+="\n\nEnglish\n"+translated(rawTitle,from,"en",tr)+"\n"+translated(rawBody,from,"en",tr);
   if(!from.equals(target)||mode.equals("both"))expanded+="\n"+(mode.equals("en")?"Machine translation":"ترجمهٔ ماشینی");
   return new Display(title,expanded.trim());
  } catch(Exception e){return new Display(rawTitle,source+"\n"+rawBody+"\n"+(mode.equals("en")?"Original text — translation unavailable":"متن اصلی — ترجمه دریافت نشد"));}
 }
 static String read(InputStream in)throws IOException{try(InputStream input=in){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=input.read(b))!=-1)out.write(b,0,n);return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
 static List<String> chunks(String value){List<String> out=new ArrayList<>();StringBuilder chunk=new StringBuilder();int bytes=0;for(int i=0;i<value.length();){int cp=value.codePointAt(i);String letter=new String(Character.toChars(cp));int size=letter.getBytes(StandardCharsets.UTF_8).length;if(bytes+size>450){out.add(chunk.toString());chunk.setLength(0);bytes=0;}chunk.append(letter);bytes+=size;i+=Character.charCount(cp);}if(chunk.length()>0)out.add(chunk.toString());return out;}
 static String fetch(Context c,String value,String from,String to)throws Exception{
  String key=Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest((from+"|"+to+"|"+value).getBytes(StandardCharsets.UTF_8)));
  android.content.SharedPreferences p=c.getSharedPreferences("news_translation",Context.MODE_PRIVATE);
  String cached=p.getString(key,"");if(!cached.isEmpty())return cached;
  List<String> parts=new ArrayList<>();
  for(String part:chunks(value)){
   String url="https://api.mymemory.translated.net/get?q="+Uri.encode(part)+"&langpair="+Uri.encode(from+"|"+to);
   android.webkit.WebResourceResponse response=NativeNews.fetch(Uri.parse("https://appassets.androidplatform.net/native-news?url="+Uri.encode(url)));
   if(response.getStatusCode()!=200){response.getData().close();throw new IOException("Translation HTTP");}
   JSONObject data=new JSONObject(read(response.getData()));String translated=DailyNews.text(data.optJSONObject("responseData")==null?"":data.getJSONObject("responseData").optString("translatedText"));
   if(data.optInt("responseStatus")!=200||translated.isEmpty()||translated.toUpperCase(Locale.ROOT).contains("MYMEMORY WARNING")||translated.toUpperCase(Locale.ROOT).contains("QUERY LENGTH LIMIT")||(to.equals("fa")&&!translated.matches("(?s).*[\\u0600-\\u06ff].*")))throw new IOException("Translation unavailable");
   parts.add(translated);
  }
  String result=String.join("",parts);
  android.content.SharedPreferences.Editor editor=p.edit();if(p.getAll().size()>=150)editor.clear();editor.putString(key,result).apply();return result;
 }
}
