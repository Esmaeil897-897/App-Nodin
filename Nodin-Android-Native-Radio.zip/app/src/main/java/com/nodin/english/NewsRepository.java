package com.nodin.english;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.Uri;
import org.json.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.parser.Parser;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

/** One durable archive and source ledger shared by all news tabs and the worker. */
@androidx.media3.common.util.UnstableApi
final class NewsRepository extends SQLiteOpenHelper {
 static final long RETENTION=10*86400000L;
 static final AtomicBoolean REFRESHING=new AtomicBoolean(false);
 private static NewsRepository instance;
 final Context context;
 static synchronized NewsRepository get(Context c){if(instance==null)instance=new NewsRepository(c.getApplicationContext(),"nodin-news.db");return instance;}
 NewsRepository(Context c,String database){super(c,database,null,1);context=c;setWriteAheadLoggingEnabled(true);}
 @Override public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE stories(id TEXT PRIMARY KEY,linkKey TEXT NOT NULL,category TEXT,country TEXT,title TEXT,description TEXT,link TEXT,source TEXT,published TEXT,time INTEGER)");db.execSQL("CREATE INDEX story_time ON stories(time DESC)");db.execSQL("CREATE INDEX story_group ON stories(category,country,time DESC)");db.execSQL("CREATE TABLE sent(linkKey TEXT PRIMARY KEY,delivered INTEGER)");db.execSQL("CREATE TABLE sources(url TEXT PRIMARY KEY,etag TEXT,modified TEXT,checked INTEGER,success INTEGER,state TEXT,count INTEGER)");}
 @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
 android.content.SharedPreferences meta(){return context.getSharedPreferences("news_hub",Context.MODE_PRIVATE);}
 static String digest(String value){try{return android.util.Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP|android.util.Base64.URL_SAFE);}catch(Exception e){throw new IllegalStateException(e);}}
 static String canonical(String value){Uri u=Uri.parse(value);Uri.Builder b=u.buildUpon().fragment(null).clearQuery();for(String key:u.getQueryParameterNames())if(!key.startsWith("utm_")&&!Arrays.asList("fbclid","gclid").contains(key))for(String item:u.getQueryParameters(key))b.appendQueryParameter(key,item);return b.build().toString();}
 static DailyNews.Story from(JSONObject a){DailyNews.Story s=new DailyNews.Story();s.title=DailyNews.shorten(DailyNews.text(a.optString("title")),500);s.desc=DailyNews.shorten(DailyNews.text(a.optString("desc")),500);s.link=a.optString("link");s.source=DailyNews.shorten(DailyNews.text(a.optString("source")),120);s.published=a.optString("published");s.time=DailyNews.date(s.published);return s;}
 static boolean archived(DailyNews.Story s,long now){return !s.title.isEmpty()&&DailyNews.safeLink(s.link)&&s.time>0&&s.time<=now+60000&&now-s.time<=RETENTION;}
 synchronized void ingest(String category,String country,List<DailyNews.Story> items){
  if(!DailyNews.CATEGORIES.contains(category)||category.equals("all")||(!country.isEmpty()&&!DailyNews.COUNTRIES.contains(country)))return;
  SQLiteDatabase db=getWritableDatabase();long now=System.currentTimeMillis();db.beginTransaction();
  try{for(DailyNews.Story s:items){if(!archived(s,now))continue;String key=digest(canonical(s.link)),id=digest(category+"|"+country+"|"+key);ContentValues v=new ContentValues();v.put("id",id);v.put("linkKey",key);v.put("category",category);v.put("country",country);v.put("title",s.title);v.put("description",s.desc);v.put("link",s.link);v.put("source",s.source);v.put("published",s.published);v.put("time",s.time);db.insertWithOnConflict("stories",null,v,SQLiteDatabase.CONFLICT_REPLACE);}prune(db,now);db.setTransactionSuccessful();}finally{db.endTransaction();}
  meta().edit().putLong("revision",meta().getLong("revision",0)+1).apply();
 }
 static void prune(SQLiteDatabase db,long now){db.delete("stories","time < ?",new String[]{String.valueOf(now-RETENTION)});db.delete("sent","delivered < ?",new String[]{String.valueOf(now-RETENTION)});db.execSQL("DELETE FROM stories WHERE id NOT IN (SELECT id FROM stories ORDER BY time DESC LIMIT 5000)");}
 synchronized void ingest(JSONObject data){JSONArray items=data.optJSONArray("items");if(items==null)return;List<DailyNews.Story> stories=new ArrayList<>();for(int i=0;i<Math.min(items.length(),150);i++){JSONObject a=items.optJSONObject(i);if(a!=null)stories.add(from(a));}ingest(data.optString("category","migration"),data.optString("country",""),stories);}
 static DailyNews.Story cursorStory(Cursor row){DailyNews.Story s=new DailyNews.Story();s.id=row.getString(0);s.category=row.getString(1);s.country=row.getString(2);s.title=row.getString(3);s.desc=row.getString(4);s.link=row.getString(5);s.source=row.getString(6);s.published=row.getString(7);s.time=row.getLong(8);return s;}
 static final String COLUMNS="id,category,country,title,description,link,source,published,time";
 List<DailyNews.Story> all(){List<DailyNews.Story> out=new ArrayList<>();try(Cursor r=getReadableDatabase().rawQuery("SELECT "+COLUMNS+" FROM stories WHERE time>=? ORDER BY time DESC LIMIT 5000",new String[]{String.valueOf(System.currentTimeMillis()-RETENTION)})){while(r.moveToNext())out.add(cursorStory(r));}return out;}
 List<DailyNews.Story> candidates(String category,String country){return candidates(category,country,false);}
 List<DailyNews.Story> candidates(String category,String country,boolean older){List<DailyNews.Story> out=new ArrayList<>();String where="time>=? AND linkKey NOT IN (SELECT linkKey FROM sent)";List<String> args=new ArrayList<>();args.add(String.valueOf(System.currentTimeMillis()-(older?RETENTION:72*3600000L)));if(!category.equals("all")){where+=" AND category=?";args.add(category);}if(category.equals("migration")&&!country.equals("all")){where+=" AND country=?";args.add(country);}try(Cursor r=getReadableDatabase().rawQuery("SELECT "+COLUMNS+" FROM stories WHERE "+where+" ORDER BY time DESC LIMIT 150",args.toArray(new String[0]))){Set<String> seen=new HashSet<>();while(r.moveToNext()){DailyNews.Story s=cursorStory(r);if(seen.add(canonical(s.link)))out.add(s);}}return out;}
 boolean unsent(DailyNews.Story s){try(Cursor row=getReadableDatabase().rawQuery("SELECT linkKey FROM sent WHERE linkKey=?",new String[]{digest(canonical(s.link))})){return !row.moveToFirst();}}
 synchronized void delivered(DailyNews.Story s){ContentValues v=new ContentValues();v.put("linkKey",digest(canonical(s.link)));v.put("delivered",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("sent",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 JSONObject snapshot(long since)throws JSONException{
  JSONObject o=new JSONObject();long revision=meta().getLong("revision",0);o.put("revision",revision).put("checked",meta().getLong("checked",0)).put("refreshing",REFRESHING.get());
  JSONArray health=new JSONArray();try(Cursor r=getReadableDatabase().rawQuery("SELECT url,checked,success,state,count FROM sources ORDER BY url",null)){while(r.moveToNext())health.put(new JSONObject().put("url",r.getString(0)).put("checked",r.getLong(1)).put("success",r.getLong(2)).put("state",r.getString(3)).put("count",r.getInt(4)));}o.put("sources",health);
  if(since>=0&&since==revision)return o.put("unchanged",true);
  JSONArray items=new JSONArray();for(DailyNews.Story s:all())items.put(new JSONObject().put("id",s.id).put("category",s.category).put("country",s.country).put("title",s.title).put("desc",s.desc).put("link",s.link).put("source",s.source).put("published",s.published).put("time",s.time));return o.put("items",items);
 }
 String rss()throws Exception{
  StringWriter out=new StringWriter();org.xmlpull.v1.XmlSerializer xml=android.util.Xml.newSerializer();xml.setOutput(out);xml.startDocument("UTF-8",true);xml.startTag("","rss");xml.attribute("","version","2.0");xml.startTag("","channel");tag(xml,"title","Nodin — all news / همهٔ خبرها");tag(xml,"link","https://appassets.androidplatform.net/assets/index.html");tag(xml,"description","Collected news from the last ten days; original source links and publication dates.");tag(xml,"ttl","20");Set<String> seen=new HashSet<>();for(DailyNews.Story s:all()){String key=canonical(s.link);if(!seen.add(key))continue;xml.startTag("","item");tag(xml,"title",s.title);tag(xml,"link",s.link);tag(xml,"guid",s.link);tag(xml,"description",s.desc);tag(xml,"category",s.category+(s.country.isEmpty()?"":"/"+s.country));tag(xml,"pubDate",Instant.ofEpochMilli(s.time).atZone(ZoneOffset.UTC).format(DateTimeFormatter.RFC_1123_DATE_TIME));xml.startTag("","source");xml.attribute("","url",s.link);xml.text(s.source);xml.endTag("","source");xml.endTag("","item");}xml.endTag("","channel");xml.endTag("","rss");xml.endDocument();return out.toString();
 }
 static void tag(org.xmlpull.v1.XmlSerializer x,String tag,String value)throws Exception{x.startTag("",tag);x.text(value);x.endTag("",tag);}
 static String selected(Element parent,String css){Element e=parent.selectFirst(css);return e==null?"":e.text();}
 static List<DailyNews.Story> parseFeed(String body,String url)throws IOException{
  Document doc=Jsoup.parse(body,url,Parser.xmlParser());if(doc.getElementsByTag("rss").isEmpty()&&doc.getElementsByTag("feed").isEmpty()&&doc.getElementsByTag("rdf:RDF").isEmpty())throw new IOException("Not a news feed");List<DailyNews.Story> out=new ArrayList<>();for(Element item:doc.select("item,entry")){
   DailyNews.Story s=new DailyNews.Story();s.title=DailyNews.text(selected(item,"title"));s.desc=DailyNews.shorten(DailyNews.text(selected(item,"description,summary,content")),500);s.published=selected(item,"pubDate,published,updated");if(s.published.isEmpty())s.published=item.getElementsByTag("dc:date").text();s.time=DailyNews.date(s.published);Element link=item.selectFirst("link[href]:not([rel=self])");if(link==null)link=item.selectFirst("link");if(link!=null)s.link=link.hasAttr("href")?link.absUrl("href"):link.text().trim();s.source=Uri.parse(url).getHost();if(!s.title.isEmpty()&&DailyNews.safeLink(s.link))out.add(s);if(out.size()==150)break;
  }return out;
 }
 static String htmlDate(String value){java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\b(\\d{1,2})[./-](\\d{1,2})[./-]((?:20)?\\d{2})\\b").matcher(value);if(m.find()){String y=m.group(3);return (y.length()==2?"20"+y:y)+String.format(Locale.ROOT,"-%02d-%02d",Integer.parseInt(m.group(2)),Integer.parseInt(m.group(1)));}java.util.regex.Matcher iso=java.util.regex.Pattern.compile("20\\d{2}-\\d{2}-\\d{2}").matcher(value);return iso.find()?iso.group():"";}
 static List<DailyNews.Story> parseHtml(String body,String url,String country){
  Document doc=Jsoup.parse(body,url);List<DailyNews.Story> out=new ArrayList<>();for(Element link:doc.select("a.news-card-horizontal,article a[href],.entry a[href],a[href]")){
   DailyNews.Story s=new DailyNews.Story();s.title=selected(link,".card-title,h2,h3");if(s.title.isEmpty())s.title=link.text();if(s.title.length()<16)continue;s.desc=selected(link,".card-text");s.link=link.absUrl("href");s.published=htmlDate(link.text()+" "+s.link);Element article=link.closest("article,.ipost,.entry,.news-card-horizontal");if(s.published.isEmpty()&&article!=null){Element time=article.selectFirst("time[datetime]");s.published=time==null?htmlDate(article.text()):time.attr("datetime");}s.time=DailyNews.date(s.published);s.source=Uri.parse(url).getHost();
   if(!DailyNews.safeLink(s.link)||!s.link.startsWith("https://"+Uri.parse(url).getHost()+"/"))continue;
   boolean topic=(s.title+" "+s.desc).toLowerCase(Locale.ROOT).matches("(?s).*(göç|gocmen|sığın|mülteci|sınır dışı|μεταναστ|μετανάστ|αλλοδαπ|διακινητ|πρόσφυγ|migrant|refuge|asylum|immigr|sbarch|rifugiat).*" );
   if(topic){s.country=country;out.add(s);}if(out.size()==80)break;
  }return out;
 }
 static final class Route {String category,country,kind;Route(String a,String b,String k){category=a;country=b;kind=k;}}
 Map<String,List<Route>> routes()throws Exception{Map<String,List<Route>> routes=new LinkedHashMap<>();JSONObject categories=new JSONObject(NewsTranslation.read(context.getAssets().open("headline-feeds.json")));for(Iterator<String> keys=categories.keys();keys.hasNext();){String category=keys.next();JSONArray feeds=categories.getJSONArray(category);for(int i=0;i<feeds.length();i++)routes.computeIfAbsent(feeds.getString(i),k->new ArrayList<>()).add(new Route(category,"","rss"));}JSONObject migrants=new JSONObject(NewsTranslation.read(context.getAssets().open("migration-notification-feeds.json")));for(String country:DailyNews.COUNTRIES){JSONArray feeds=migrants.getJSONArray(country);for(int i=0;i<feeds.length();i++)routes.computeIfAbsent(feeds.getString(i),k->new ArrayList<>()).add(new Route("migration",country,"rss"));}JSONObject pages=new JSONObject(NewsTranslation.read(context.getAssets().open("migration-html-feeds.json")));for(Iterator<String> keys=pages.keys();keys.hasNext();){String country=keys.next();JSONArray sources=pages.getJSONArray(country);for(int i=0;i<sources.length();i++)routes.computeIfAbsent(sources.getString(i),k->new ArrayList<>()).add(new Route("migration",country,"html"));}return routes;}
 void source(String url,NativeNews.Download result,String state,int count){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("url",url);v.put("checked",System.currentTimeMillis());v.put("state",state);if(!state.equals("unchanged"))v.put("count",count);if(state.equals("ok")||state.equals("unchanged")){v.put("success",System.currentTimeMillis());if(result!=null&&result.status==200){v.put("etag",result.etag);v.put("modified",result.modified);}}if(db.update("sources",v,"url=?",new String[]{url})==0)db.insert("sources",null,v);}
 void refreshSource(String url,List<Route> routes,boolean force,BooleanSupplier stopped){
  if(stopped.getAsBoolean())return;String etag="",modified="";try(Cursor c=getReadableDatabase().rawQuery("SELECT etag,modified FROM sources WHERE url=?",new String[]{url})){if(c.moveToFirst()&&!force){etag=Objects.toString(c.getString(0),"");modified=Objects.toString(c.getString(1),"");}}
  try{NativeNews.Download response=NativeNews.download(url,etag,modified);if(stopped.getAsBoolean())return;if(response.status==304){source(url,response,"unchanged",0);return;}
   String body=new String(response.bytes,StandardCharsets.UTF_8);List<DailyNews.Story> base=routes.get(0).kind.equals("rss")?parseFeed(body,url):parseHtml(body,url,routes.get(0).country);
   for(Route route:routes){List<DailyNews.Story> items=new ArrayList<>();for(DailyNews.Story s:base){boolean include=route.country.isEmpty()||DailyNews.migration(s,route.country);if(route.category.equals("crime"))include=include&&(s.title+" "+s.desc).matches("(?is).*(murder|kill|homicide|manslaughter|stab|fatal|قتل|جنایت).*" );if(include)items.add(s);}ingest(route.category,route.country,items);}
   source(url,response,"ok",base.size());
  }catch(Exception e){source(url,null,"failed",0);}
 }
 boolean refresh(boolean force,BooleanSupplier stopped)throws Exception{
  if(!REFRESHING.compareAndSet(false,true))return false;ExecutorService pool=Executors.newFixedThreadPool(4);
  try{List<Callable<Void>> jobs=new ArrayList<>();routes().forEach((url,routes)->jobs.add(()->{refreshSource(url,routes,force,stopped);return null;}));List<Future<Void>> results=pool.invokeAll(jobs,4,TimeUnit.MINUTES);for(Future<Void> future:results)if(!future.isCancelled())try{future.get();}catch(ExecutionException ignored){}
   synchronized(this){prune(getWritableDatabase(),System.currentTimeMillis());meta().edit().putLong("checked",System.currentTimeMillis()).putLong("revision",meta().getLong("revision",0)+1).apply();}return true;
  }finally{pool.shutdownNow();REFRESHING.set(false);}
 }
}
