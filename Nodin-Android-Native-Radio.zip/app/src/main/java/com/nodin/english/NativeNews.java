package com.nodin.english;

import android.net.Uri;
import android.webkit.WebResourceResponse;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Read-only, whitelisted transport shared by the foreground and news worker. */
final class NativeNews {
 private static final Set<String> HOSTS=new HashSet<>(Arrays.asList(
 "api.mymemory.translated.net", "blog.playstation.com", "news.xbox.com", "www.eurogamer.net", "www.gamespot.com", "www.pcgamer.com", "www.skysports.com", "www.coventrytelegraph.net", "www.christianpost.com", "www.vaticannews.va", "www.gov.uk", "feeds.bbci.co.uk", "www.theguardian.com", "feeds.skynews.com", "feeds.feedburner.com", "www.euronews.com", "www.infomigrants.net", "www.reutersagency.com", "www.reuters.com", "www.independent.co.uk", "www.murdermap.co.uk", "murdermap.co.uk", "christiantoday.com", "www.christiantoday.com", "libertaciviliimmigrazione.dlci.interno.gov.it", "www.interno.gov.it", "migration.gov.gr", "www.goc.gov.tr", "goc.gov.tr", "en.goc.gov.tr", "www.sg.gov.tr", "www.egm.gov.tr", "www.ansa.it", "www.dailysabah.com", "greekreporter.com", "www.bbc.co.uk", "www.bbc.com", "asylumineurope.org", "data.unhcr.org", "www.unhcr.org", "ec.europa.eu", "www.icisleri.gov.tr", "www.astynomia.gr", "www.hcg.gr"));
 static boolean allowed(URL url){return "https".equals(url.getProtocol())&&HOSTS.contains(url.getHost().toLowerCase(Locale.ROOT))&&(url.getPort()==-1||url.getPort()==443)&&url.getUserInfo()==null;}
 static final class Download {int status;byte[] bytes=new byte[0];String mime="text/plain",etag="",modified="";}
 static Download download(String address,String etag,String modified)throws IOException{
  URL url=new URL(address);long deadline=android.os.SystemClock.elapsedRealtime()+20000;
  for(int redirects=0;redirects<=4;redirects++){
   if(android.os.SystemClock.elapsedRealtime()>deadline)throw new IOException("Timeout");if(!allowed(url))throw new IOException("Source not allowed");
   HttpURLConnection connection=(HttpURLConnection)url.openConnection();
   try{
    connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);connection.setConnectTimeout(7000);connection.setReadTimeout(7000);connection.setRequestProperty("User-Agent","Nodin-English/8.0 (Android news reader)");
    if(!etag.isEmpty())connection.setRequestProperty("If-None-Match",etag);if(!modified.isEmpty())connection.setRequestProperty("If-Modified-Since",modified);
    int code=connection.getResponseCode();if(code>=300&&code<400&&code!=304){String location=connection.getHeaderField("Location");if(location==null)throw new IOException("Missing redirect");url=new URL(url,location);continue;}
    Download result=new Download();result.status=code;result.etag=Objects.toString(connection.getHeaderField("ETag"),"");result.modified=Objects.toString(connection.getHeaderField("Last-Modified"),"");
    if(code==304)return result;if(code!=200)throw new IOException("Source HTTP "+code);
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream input=connection.getInputStream()){byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1){if(Thread.currentThread().isInterrupted()||android.os.SystemClock.elapsedRealtime()>deadline)throw new IOException("Timeout");if(bytes.size()+count>4*1024*1024)throw new IOException("Response too large");bytes.write(buffer,0,count);}}
    result.bytes=bytes.toByteArray();result.mime=Objects.toString(connection.getContentType(),"text/plain").split(";")[0].trim();return result;
   }finally{connection.disconnect();}
  }
  throw new IOException("Too many redirects");
 }
 static WebResourceResponse fetch(Uri request){try{
  Download r=download(request.getQueryParameter("url"),"","");String mime=r.mime;if(!(mime.startsWith("image/")||mime.equals("application/pdf")))mime="text/plain";
  return new WebResourceResponse(mime,mime.startsWith("image/")||mime.equals("application/pdf")?null:"UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream(r.bytes));
 }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",502,"Unavailable",Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream("Source unavailable".getBytes(StandardCharsets.UTF_8)));}}
}
