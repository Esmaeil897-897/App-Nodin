package com.nodin.english;

import android.net.Uri;
import android.webkit.WebResourceResponse;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Same-origin, read-only news transport; never forwards arbitrary URLs. */
final class NativeNews {
    private static final Set<String> HOSTS = new HashSet<>(Arrays.asList(
        "www.gov.uk", "feeds.bbci.co.uk", "www.theguardian.com", "feeds.skynews.com",
        "feeds.feedburner.com", "www.euronews.com", "www.infomigrants.net",
        "www.reutersagency.com", "www.reuters.com", "www.independent.co.uk",
        "www.murdermap.co.uk", "murdermap.co.uk", "christiantoday.com", "www.christiantoday.com"));
    static boolean allowed(URL url) {
        return "https".equals(url.getProtocol()) && HOSTS.contains(url.getHost().toLowerCase(Locale.ROOT))
            && (url.getPort() == -1 || url.getPort() == 443) && url.getUserInfo() == null;
    }
    static WebResourceResponse fetch(Uri request) {
        int status = 502;
        String body = "News source unavailable";
        try {
            URL url = new URL(request.getQueryParameter("url"));
            long deadline = android.os.SystemClock.elapsedRealtime() + 20000;
            for (int redirects = 0; redirects <= 4; redirects++) {
                if (android.os.SystemClock.elapsedRealtime() > deadline) throw new IOException("Timeout");
                if (!allowed(url)) { status = 403; throw new IOException("Source not allowed"); }
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                try {
                    connection.setInstanceFollowRedirects(false);
                    connection.setUseCaches(false);
                    connection.setConnectTimeout(7000);
                    connection.setReadTimeout(7000);
                    connection.setRequestProperty("Cache-Control", "no-cache, no-store");
                    connection.setRequestProperty("User-Agent", "Nodin-English/7.5 (Android news reader)");
                    int code = connection.getResponseCode();
                    if (code >= 300 && code < 400) {
                        String location = connection.getHeaderField("Location");
                        if (location == null) throw new IOException("Missing redirect");
                        url = new URL(url, location);
                        continue;
                    }
                    if (code != 200) throw new IOException("Source HTTP " + code);
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    try (InputStream input = connection.getInputStream()) {
                        byte[] buffer = new byte[8192];
                        int count;
                        while ((count = input.read(buffer)) != -1) {
                            if (android.os.SystemClock.elapsedRealtime() > deadline) throw new IOException("Timeout");
                            if (bytes.size() + count > 4 * 1024 * 1024) throw new IOException("Response too large");
                            bytes.write(buffer, 0, count);
                        }
                    }
                    Map<String,String> headers = Collections.singletonMap("Cache-Control", "no-store");
                    return new WebResourceResponse("text/plain", "UTF-8", 200, "OK", headers,
                        new ByteArrayInputStream(bytes.toByteArray()));
                } finally { connection.disconnect(); }
            }
        } catch (Exception ignored) { }
        return new WebResourceResponse("text/plain", "UTF-8", status, "Unavailable",
            Collections.singletonMap("Cache-Control", "no-store"),
            new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
    }
}
