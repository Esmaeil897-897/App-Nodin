package com.nodin.english;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import androidx.webkit.*;
import androidx.media3.common.*;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONObject;
import java.util.Collections;

@androidx.media3.common.util.UnstableApi
public class MainActivity extends Activity {
    private WebView web;
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private JSONObject pendingPlay;
    private android.content.SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady;
    private java.io.ByteArrayOutputStream exportBuffer;
    private byte[] saveBytes;

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onEvents(Player player, Player.Events events) { publish(); }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("native",MODE_PRIVATE);
        web=new WebView(this);
        setContentView(web);
        // Edge-to-edge in Android 15: protect controls from status/navigation bars.
        web.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
                return loader.shouldInterceptRequest(req.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                if(!req.isForMainFrame()) return false;
                Uri u=req.getUrl();
                if(u.toString().equals("https://appassets.androidplatform.net/assets/index.html")) return false;
                if("https".equals(u.getScheme()) || "http".equals(u.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView v,String url){pageReady=true;publish();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                try{startActivityForResult(p.createIntent(),40);return true;}
                catch(Exception e){fileCallback=null;return false;}
            }
        });
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
            WebViewCompat.addWebMessageListener(web,"NodinNative",
                Collections.singleton("https://appassets.androidplatform.net"),
                (view,message,origin,mainFrame,reply)->{
                    if(!mainFrame) return;
                    try{command(new JSONObject(message.getData()));}catch(Exception e){toast("درخواست نامعتبر");}
                });
        }else toast("Android System WebView را به‌روز کنید تا پلیر بومی فعال شود.");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        SessionToken token=new SessionToken(this,new ComponentName(this,RadioService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try{
                controller=future.get();
                controller.addListener(listener);
                if(pendingPlay!=null){JSONObject p=pendingPlay;pendingPlay=null;play(p);}
                publish();
            }catch(Exception e){toast("اتصال به پلیر ممکن نشد");}
        },command->runOnUiThread(command));
        keepScreen();
    }
    private void command(JSONObject data) {
        String cmd=data.optString("cmd");
        if(cmd.equals("play")){ if(controller==null) pendingPlay=data; else play(data); }
        else if(cmd.equals("stop")){
            pendingPlay=null;
            if(controller!=null){controller.pause();controller.stop();controller.clearMediaItems();}
        }else if(cmd.equals("settings")) settingsDialog();
        else if(cmd.equals("overlay")) requestOverlay();
        else if(cmd.equals("exportStart")){
            exportBuffer=new java.io.ByteArrayOutputStream();
        }else if(cmd.equals("exportChunk")){
            if(exportBuffer==null)return;
            byte[] bytes=android.util.Base64.decode(data.optString("data"),android.util.Base64.DEFAULT);
            if(exportBuffer.size()+bytes.length>32*1024*1024){exportBuffer=null;toast("فایل خروجی بیش از ۳۲ مگابایت است.");return;}
            exportBuffer.write(bytes,0,bytes.length);
        }else if(cmd.equals("exportEnd")){
            if(exportBuffer==null)return;
            saveBytes=exportBuffer.toByteArray();exportBuffer=null;
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,data.optString("name","Nodin-export.json"));
            startActivityForResult(save,42);
        }
    }
    private void play(JSONObject data){
        String url=data.optString("url");
        if(!url.startsWith("https://")){toast("این رادیو لینک امن HTTPS ندارد.");return;}
        MediaItem item=new MediaItem.Builder().setMediaId(data.optString("id"))
            .setUri(url).setMediaMetadata(new MediaMetadata.Builder()
            .setTitle(data.optString("title")).setArtist("English with Nodin").build()).build();
        controller.setMediaItem(item); controller.prepare();controller.play();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},41);
        if(prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();
    }
    private void publish(){
        if(!pageReady || controller==null) return;
        try{
            MediaItem item=controller.getCurrentMediaItem();
            JSONObject o=new JSONObject();
            o.put("id",item==null?"":item.mediaId);
            o.put("title",item==null?"":String.valueOf(item.mediaMetadata.title));
            String state=controller.getPlayerError()!=null?"error":
                item==null?"idle":controller.getPlaybackState()==Player.STATE_BUFFERING?"loading":
                controller.isPlaying()?"playing":"paused";
            o.put("state",state);
            web.evaluateJavascript("window.onNativeRadioState && window.onNativeRadioState("+o+");",null);
        }catch(Exception ignored){}
    }
    private void keepScreen(){
        if(prefs.getBoolean("screen",false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void settingsDialog(){
        String[] names={"روشن نگه‌داشتن صفحه هنگام استفاده از برنامه","رادیوی شناور روی برنامه‌های دیگر"};
        boolean[] values={prefs.getBoolean("screen",false),prefs.getBoolean("overlay",false)};
        new AlertDialog.Builder(this).setTitle("تنظیمات اندروید")
            .setMultiChoiceItems(names,values,(d,n,checked)->{
                prefs.edit().putBoolean(n==0?"screen":"overlay",checked).apply();
                if(n==0) keepScreen();
                else if(checked) requestOverlay();
                else overlayCommand();
            }).setPositiveButton("بستن",null).show();
    }
    private void requestOverlay(){
        prefs.edit().putBoolean("overlay",true).apply();
        if(!Settings.canDrawOverlays(this)){
            new AlertDialog.Builder(this).setMessage("برای نمایش دکمهٔ رادیو روی برنامه‌های دیگر، اجازهٔ نمایش روی سایر برنامه‌ها را فعال کنید.")
                .setPositiveButton("بازکردن تنظیمات",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))))
                .setNegativeButton("فعلاً نه",(d,w)->prefs.edit().putBoolean("overlay",false).apply()).show();
        }else if(controller!=null && controller.getCurrentMediaItem()!=null) overlayCommand();
        else toast("ابتدا یک رادیو را پخش کنید؛ سپس دکمهٔ شناور ظاهر می‌شود.");
    }
    private void overlayCommand(){
        if(controller!=null && controller.getCurrentMediaItem()!=null)
            startService(new Intent(this,RadioService.class).setAction("overlay"));
    }
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();keepScreen();if(web!=null){web.onResume();publish();}if(prefs!=null && prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();}
    @Override protected void onPause(){super.onPause();if(web!=null) web.onPause(); /* native radio stays in service */}
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==42 && saveBytes!=null){
            byte[] bytes=saveBytes;saveBytes=null;
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();
                new Thread(()->{
                    try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){
                        if(out==null)throw new java.io.IOException();out.write(bytes);
                        runOnUiThread(()->toast("فایل ذخیره شد."));
                    }catch(Exception e){runOnUiThread(()->toast("ذخیرهٔ فایل انجام نشد."));}
                }).start();
            }
        }
        if(req==40 && fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}
    }
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){
        if(controller!=null)controller.removeListener(listener);
        if(future!=null)MediaController.releaseFuture(future);
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        web.destroy();super.onDestroy();
    }
}
