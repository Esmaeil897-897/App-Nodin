package com.nodin.english;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.*;
import androidx.media3.common.*;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONObject;
import java.util.Collections;

@androidx.media3.common.util.UnstableApi
public class MainActivity extends Activity {
    private WebView web;
    private NativeSpeech nativeSpeech;
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private JSONObject pendingPlay;
    private android.content.SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady;
    private java.io.ByteArrayOutputStream exportBuffer;
    private byte[] saveBytes;

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onEvents(Player player, Player.Events events) { publish(); }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("native",MODE_PRIVATE);
        web=new WebView(this);
        setContentView(web);
        // Edge-to-edge in Android 15: protect controls from status/navigation bars.
        web.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setTextZoom(100);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
                Uri uri=req.getUrl();
                if("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())
                    && "/native-news".equals(uri.getPath()) && "GET".equals(req.getMethod()))
                    return NativeNews.fetch(uri);
                return loader.shouldInterceptRequest(uri);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                if(!req.isForMainFrame()) return false;
                Uri u=req.getUrl();
                if(u.toString().equals("https://appassets.androidplatform.net/assets/index.html")) return false;
                if("https".equals(u.getScheme()) || "http".equals(u.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView v,String url){pageReady=true;publish();if(nativeSpeech!=null)nativeSpeech.publishVoices();publishNewsState();openNotificationNews();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                try{startActivityForResult(p.createIntent(),40);return true;}
                catch(Exception e){fileCallback=null;return false;}
            }
        });
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
            WebViewCompat.addWebMessageListener(web,"NodinNative",
                Collections.singleton("https://appassets.androidplatform.net"),
                (view,message,origin,mainFrame,reply)->{
                    if(!mainFrame) return;
                    try{command(new JSONObject(message.getData()));}catch(Exception e){toast("درخواست نامعتبر");}
                });
        }else toast("Android System WebView را به‌روز کنید تا پلیر بومی فعال شود.");
        nativeSpeech=new NativeSpeech(this,web);
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        try {
        SessionToken token=new SessionToken(this,new ComponentName(this,RadioService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try{
                controller=future.get();
                controller.addListener(listener);
                if(pendingPlay!=null){JSONObject p=pendingPlay;pendingPlay=null;play(p);}
                publish();
            }catch(Exception e){toast("اتصال به پلیر ممکن نشد");}
        },command->runOnUiThread(command));
        } catch(Exception e) {
            android.util.Log.e("Nodin", "Radio controller initialization failed", e);
            toast("اتصال به رادیو ممکن نشد؛ بخش آموزشی در دسترس است.");
        }
        keepScreen();
    }
    private void command(JSONObject data) {
        String cmd=data.optString("cmd");
        if(cmd.equals("ttsSpeak")){nativeSpeech.speak(data);}
        else if(cmd.equals("ttsStop")){nativeSpeech.stop();}
        else if(cmd.equals("ttsVoices")){nativeSpeech.publishVoices();}
        else if(cmd.equals("ttsSettings")){startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}
        else if(cmd.equals("newsStatus")){publishNewsState();}
        else if(cmd.equals("newsEnable")){
            boolean enabled=data.optBoolean("enabled");DailyNews.configure(this,data);DailyNews.schedule(this,enabled,data.optString("category","general"));
            if(enabled && Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},43);
            else if(enabled){DailyNews.now(this,false);toast("اعلان روزانه فعال شد؛ زمان نمایش به تنظیمات گوشی بستگی دارد.");}
            publishNewsState();
        }else if(cmd.equals("newsCategory")){DailyNews.configure(this,data);DailyNews.schedule(this,DailyNews.prefs(this).getBoolean("enabled",false),data.optString("category","general"));publishNewsState();}
        else if(cmd.equals("migrationStories")){DailyNews.cacheStories(this,data);}
        else if(cmd.equals("newsPreview")){if(!DailyNews.prefs(this).getBoolean("enabled",false)||!DailyNews.permitted(this))toast("ابتدا اعلان و اجازهٔ نمایش آن را فعال کنید.");else {DailyNews.now(this,true);toast("در حال بررسی خبر تازه؛ بدون خبرِ اخیر، اعلانی ارسال نمی‌شود.");}}
        else if(cmd.equals("newsSystemSettings")){startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
        else if(cmd.equals("play")){ if(controller==null) pendingPlay=data; else play(data); }
        else if(cmd.equals("stop")){
            pendingPlay=null;
            if(controller!=null){controller.pause();controller.stop();controller.clearMediaItems();}
        }else if(cmd.equals("settings")) settingsDialog();
        else if(cmd.equals("overlay")) requestOverlay();
        else if(cmd.equals("exportStart")){
            exportBuffer=new java.io.ByteArrayOutputStream();
        }else if(cmd.equals("exportChunk")){
            if(exportBuffer==null)return;
            byte[] bytes=android.util.Base64.decode(data.optString("data"),android.util.Base64.DEFAULT);
            if(exportBuffer.size()+bytes.length>32*1024*1024){exportBuffer=null;toast("فایل خروجی بیش از ۳۲ مگابایت است.");return;}
            exportBuffer.write(bytes,0,bytes.length);
        }else if(cmd.equals("exportEnd")){
            if(exportBuffer==null)return;
            saveBytes=exportBuffer.toByteArray();exportBuffer=null;
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,data.optString("name","Nodin-export.json"));
            startActivityForResult(save,42);
        }
    }
    private void publishNewsState(){if(pageReady&&web!=null)web.evaluateJavascript("window.onDailyNewsState && window.onDailyNewsState("+DailyNews.status(this)+");",null);}
    private void openNotificationNews(){Intent intent=getIntent();if(!pageReady||intent==null||!intent.hasExtra("news_title"))return;try{JSONObject o=new JSONObject();for(String key:new String[]{"category","title","link","source","published","country","displayTitle","displayBody"})o.put(key,DailyNews.shorten(intent.getStringExtra("news_"+key)==null?"":intent.getStringExtra("news_"+key),600));o.put("desc",DailyNews.shorten(intent.getStringExtra("news_description")==null?"":intent.getStringExtra("news_description"),260));intent.removeExtra("news_title");web.evaluateJavascript("("+o+").category === 'migration' ? window.NodinMigrationNotifications?.open("+o+") : window.NodinHeadlinesApi?.openNotification("+o+");",null);}catch(Exception ignored){}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);openNotificationNews();}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results){super.onRequestPermissionsResult(req,permissions,results);if(req==43){if(DailyNews.permitted(this)&&DailyNews.prefs(this).getBoolean("enabled",false))DailyNews.now(this,false);publishNewsState();}}
    private void play(JSONObject data){
        String url=data.optString("url");
        if(!url.startsWith("https://")){toast("این رادیو لینک امن HTTPS ندارد.");return;}
        MediaItem item=new MediaItem.Builder().setMediaId(data.optString("id"))
            .setUri(url).setMediaMetadata(new MediaMetadata.Builder()
            .setTitle(data.optString("title")).setArtist("English with Nodin").build()).build();
        controller.setMediaItem(item); controller.prepare();controller.play();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},41);
        if(prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();
    }
    private void publish(){
        if(!pageReady || controller==null) return;
        try{
            MediaItem item=controller.getCurrentMediaItem();
            JSONObject o=new JSONObject();
            o.put("id",item==null?"":item.mediaId);
            o.put("title",item==null?"":String.valueOf(item.mediaMetadata.title));
            String state=controller.getPlayerError()!=null?"error":
                item==null?"idle":controller.getPlaybackState()==Player.STATE_BUFFERING?"loading":
                controller.isPlaying()?"playing":"paused";
            o.put("state",state);
            web.evaluateJavascript("window.onNativeRadioState && window.onNativeRadioState("+o+");",null);
        }catch(Exception ignored){}
    }
    private void keepScreen(){
        if(prefs.getBoolean("screen",false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void settingsDialog(){
        String[] names={"روشن نگه‌داشتن صفحه هنگام استفاده از برنامه","رادیوی شناور روی برنامه‌های دیگر"};
        boolean[] values={prefs.getBoolean("screen",false),prefs.getBoolean("overlay",false)};
        new AlertDialog.Builder(this).setTitle("تنظیمات اندروید")
            .setMultiChoiceItems(names,values,(d,n,checked)->{
                prefs.edit().putBoolean(n==0?"screen":"overlay",checked).apply();
                if(n==0) keepScreen();
                else if(checked) requestOverlay();
                else overlayCommand();
            }).setPositiveButton("بستن",null).show();
    }
    private void requestOverlay(){
        prefs.edit().putBoolean("overlay",true).apply();
        if(!Settings.canDrawOverlays(this)){
            new AlertDialog.Builder(this).setMessage("برای نمایش دکمهٔ رادیو روی برنامه‌های دیگر، اجازهٔ نمایش روی سایر برنامه‌ها را فعال کنید.")
                .setPositiveButton("بازکردن تنظیمات",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))))
                .setNegativeButton("فعلاً نه",(d,w)->prefs.edit().putBoolean("overlay",false).apply()).show();
        }else if(controller!=null && controller.getCurrentMediaItem()!=null) overlayCommand();
        else toast("ابتدا یک رادیو را پخش کنید؛ سپس دکمهٔ شناور ظاهر می‌شود.");
    }
    private void overlayCommand(){
        if(controller!=null && controller.getCurrentMediaItem()!=null)
            startService(new Intent(this,RadioService.class).setAction("overlay"));
    }
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();keepScreen();if(nativeSpeech!=null&&nativeSpeech.needsRetry()){nativeSpeech.close();nativeSpeech=new NativeSpeech(this,web);}if(web!=null){web.onResume();publish();publishNewsState();}if(prefs!=null && prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();}
    @Override protected void onPause(){super.onPause();if(web!=null) web.onPause(); /* native radio stays in service */}
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==42 && saveBytes!=null){
            byte[] bytes=saveBytes;saveBytes=null;
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();
                new Thread(()->{
                    try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){
                        if(out==null)throw new java.io.IOException();out.write(bytes);
                        runOnUiThread(()->toast("فایل ذخیره شد."));
                    }catch(Exception e){runOnUiThread(()->toast("ذخیرهٔ فایل انجام نشد."));}
                }).start();
            }
        }
        if(req==40 && fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}
    }
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){
        if(controller!=null)controller.removeListener(listener);
        if(future!=null)MediaController.releaseFuture(future);
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        if(nativeSpeech!=null)nativeSpeech.close();
        web.destroy();super.onDestroy();
    }
}
