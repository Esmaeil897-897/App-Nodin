package com.nodin.english;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.net.Uri;
import androidx.work.*;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Opt-in daily news. WorkManager may delay delivery under battery restrictions. */
@androidx.media3.common.util.UnstableApi
public class DailyNews extends Worker {
 static final String CHANNEL="nodin_daily_news",WORK="nodin_news_sync_v2";
 static final int NOTIFICATION=781;
 static final List<String> COUNTRIES=Arrays.asList("uk","it","gr","tr");
 static final Set<String> CATEGORIES=new HashSet<>(Arrays.asList("all","general","gaming","migration","sport","politics","economy","local","crime","christian","euronews"));
 public DailyNews(Context c,WorkerParameters p){super(c,p);}
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("daily_news",Context.MODE_PRIVATE);}
 static boolean permitted(Context c){return (Build.VERSION.SDK_INT<33||c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)&&c.getSystemService(NotificationManager.class).areNotificationsEnabled();}
 static void channel(Context c){NotificationChannel ch=new NotificationChannel(CHANNEL,"اخبار روز نودین",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("تیتر و گزیدهٔ اخبار روز؛ لمس اعلان برای مطالعه در برنامه");c.getSystemService(NotificationManager.class).createNotificationChannel(ch);}
 static int bound(int value,int low,int high){return Math.max(low,Math.min(high,value));}
 static int interval(Context c){return bound(prefs(c).getInt("interval",20),1,30);}
 static int batchCount(Context c){return bound(prefs(c).getInt("count",1),1,5);}
 static void configure(Context c,JSONObject data){String country=data.optString("country","all"),language=data.optString("language","fa");if(!COUNTRIES.contains(country))country="all";if(!Arrays.asList("fa","en","both").contains(language))language="fa";android.content.SharedPreferences p=prefs(c);p.edit().putString("country",country).putString("language",language).putInt("interval",bound(data.optInt("interval",p.getInt("interval",20)),1,30)).putInt("count",bound(data.optInt("count",p.getInt("count",1)),1,5)).putBoolean("older",data.optBoolean("older",p.getBoolean("older",false))).apply();}
 static synchronized void schedule(Context c,boolean enabled,String category){
  if(!CATEGORIES.contains(category))category="general";
  prefs(c).edit().putBoolean("enabled",enabled).putString("category",category).putLong("revision",prefs(c).getLong("revision",0)+1).apply();
  channel(c);WorkManager w=WorkManager.getInstance(c);w.cancelUniqueWork(WORK+"_now");w.cancelAllWorkByTag(NewsAlerts.WORK);
  // Old notices cannot retain the previous language or country after a settings change.
  NotificationManager manager=c.getSystemService(NotificationManager.class);manager.cancel(NOTIFICATION);for(String country:COUNTRIES)manager.cancel(id(country));for(android.service.notification.StatusBarNotification n:manager.getActiveNotifications())if("nodin_news_story".equals(n.getTag()))manager.cancel(n.getTag(),n.getId());
  bootstrap(c);
 }
 static final long INTERVAL=20*60000L;
 static void bootstrap(Context c){WorkManager w=WorkManager.getInstance(c);w.cancelUniqueWork("nodin_daily_news_work");w.cancelUniqueWork("nodin_daily_news_work_now");w.enqueueUniquePeriodicWork(WORK,ExistingPeriodicWorkPolicy.KEEP,new PeriodicWorkRequest.Builder(DailyNews.class,20,TimeUnit.MINUTES).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build());NewsAlerts.ensure(c,false,-1);
 }
 static void now(Context c,boolean preview){WorkManager.getInstance(c).enqueueUniqueWork(WORK+"_now",ExistingWorkPolicy.REPLACE,new OneTimeWorkRequest.Builder(DailyNews.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setInputData(new Data.Builder().putBoolean("preview",preview).build()).build());}
 static void nowForRules(Context c,String keys){WorkManager.getInstance(c).enqueueUniqueWork(WORK+"_now",ExistingWorkPolicy.REPLACE,new OneTimeWorkRequest.Builder(DailyNews.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setInputData(new Data.Builder().putBoolean("preview",true).putString("ruleKeys",keys).build()).build());}
 static JSONObject status(Context c){JSONObject o=new JSONObject();try{o.put("rules",NewsRules.read(c));o.put("pushConnected",false);o.put("enabled",prefs(c).getBoolean("enabled",false));o.put("permitted",permitted(c));o.put("category",prefs(c).getString("category","general"));o.put("country",prefs(c).getString("country","all"));o.put("language",prefs(c).getString("language","fa"));o.put("last",prefs(c).getString("last_time",""));o.put("interval",interval(c));o.put("count",batchCount(c));o.put("older",prefs(c).getBoolean("older",false));o.put("checked",prefs(c).getString("alert_checked",""));o.put("deliveryState",prefs(c).getString("delivery_state",""));o.put("translationPending",prefs(c).getBoolean("translation_pending",false));}catch(Exception ignored){}return o;}
 static String text(String v){return android.text.Html.fromHtml(v==null?"":v,android.text.Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+"," ").trim();}
 static String shorten(String s,int n){return s.length()>n?s.substring(0,n-1)+"…":s;}
 static long date(String s){try{return ZonedDateTime.parse(s,DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli();}catch(Exception e){try{return Instant.parse(s).toEpochMilli();}catch(Exception ignored){try{return LocalDate.parse(s).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();}catch(Exception invalid){return 0;}}}}
 static final class Story {String id="",category="general",title="",desc="",link="",source="",published="",country="";long time;}
 static boolean safeLink(String link){try{Uri u=Uri.parse(link);return "https".equals(u.getScheme())&&u.getHost()!=null&&u.getUserInfo()==null&&(u.getPort()==-1||u.getPort()==443);}catch(Exception e){return false;}}
 static List<Story> parse(InputStream input,String source)throws Exception{
  XmlPullParser p=Xml.newPullParser();p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,true);p.setInput(input,"UTF-8");List<Story> out=new ArrayList<>();Story story=null;int type;
  while((type=p.next())!=XmlPullParser.END_DOCUMENT&&out.size()<60){if(type==XmlPullParser.START_TAG){String name=p.getName();if("item".equals(name)){story=new Story();story.source=source;}else if(story!=null&&Arrays.asList("title","description","link","pubDate").contains(name)){String v=p.nextText();if("title".equals(name))story.title=text(v);else if("description".equals(name))story.desc=text(v);else if("link".equals(name))story.link=v.trim();else {story.published=v;story.time=date(v);}}}else if(type==XmlPullParser.END_TAG&&"item".equals(p.getName())&&story!=null){if(!story.title.isEmpty()&&safeLink(story.link))out.add(story);story=null;}}
  return out;
 }
 static int id(String country){return country.isEmpty()?NOTIFICATION:NOTIFICATION+1+COUNTRIES.indexOf(country);}
 static String countryName(String country){switch(country){case "uk":return "بریتانیا / UK";case "it":return "ایتالیا / Italy";case "gr":return "یونان / Greece";case "tr":return "ترکیه / Türkiye";default:return "";}}
 static boolean migration(Story s,String country){
  if(!s.country.isEmpty())return country.equals(s.country); // Already filtered by the app's country parser.
  String value=(s.title+" "+s.desc).toLowerCase(Locale.ROOT);
  boolean migrant=value.matches("(?s).*(migran|refuge|asylum|immigra|small boat|channel crossing|deport|unhcr|smuggl|sbarc|rifugiat|göç|gocmen|göçmen|sığın|mülteci|μετανάστ|πρόσφυγ|προσφυγ|άσυλ|ασύλ|مهاجر|پناهند|پناهجو|مهاجرت).*" );
  String pattern;switch(country){case "uk":pattern="\\b(uk|britain|british|england|home office|channel|dover|calais)\\b|بریتانیا|انگلستان|مانش";break;case "it":pattern="\\b(italy|italian|italia|lampedusa|sicily|sicilia|calabria|meloni)\\b|ایتالیا";break;case "gr":pattern="\\b(greece|greek|hellenic|lesbos|lesvos|aegean|samos|kos|crete)\\b|ελλάδ|ελλην|یونان";break;case "tr":pattern="\\b(turkey|turkish|türkiye|türkiy|istanbul|izmir|edirne|ankara)\\b|ترکیه";break;default:return false;}
  return migrant&&java.util.regex.Pattern.compile(pattern).matcher(value).find();
 }
 static boolean recent(Story s,long now){return s.time>0&&s.time<=now+60000&&now-s.time<=72*3600000L;}
 static void cacheStories(Context c,JSONObject data){String country=data.optString("country");JSONArray items=data.optJSONArray("items");if(!COUNTRIES.contains(country)||items==null)return;JSONArray clean=new JSONArray();for(int i=0;i<Math.min(items.length(),30);i++){JSONObject a=items.optJSONObject(i);if(a==null||!safeLink(a.optString("link")))continue;try{JSONObject o=new JSONObject();for(String key:Arrays.asList("title","desc","link","source","published"))o.put(key,shorten(key.equals("link")?a.optString(key):text(a.optString(key)),key.equals("desc")?500:600));if(!o.getString("title").isEmpty())clean.put(o);}catch(Exception ignored){}}prefs(c).edit().putString("stories_"+country,clean.toString()).apply();NewsRepository.get(c).ingest(data);}
 static List<Story> cached(Context c,String country){List<Story> stories=new ArrayList<>();try{JSONArray items=new JSONArray(prefs(c).getString("stories_"+country,"[]"));for(int i=0;i<items.length();i++){JSONObject a=items.getJSONObject(i);Story s=new Story();s.title=a.optString("title");s.desc=a.optString("desc");s.link=a.optString("link");s.source=a.optString("source");s.published=a.optString("published");s.country=country;s.time=date(s.published);if(safeLink(s.link))stories.add(s);}}catch(Exception ignored){}return stories;}
 static void post(Context c,Story s,String category){post(c,s,category,new NewsTranslation.Display(s.title,s.source+(s.desc.isEmpty()?"":" — "+shorten(s.desc,220))));}
 static void post(Context c,Story s,String category,NewsTranslation.Display display){
  postNotice(c,s,category,display,null,id(s.country));
 }
 static void postNotice(Context c,Story s,String category,NewsTranslation.Display display,String tag,int id){
  if(!permitted(c)||display==null)return;channel(c);
  Intent intent=new Intent(c,MainActivity.class).setAction("com.nodin.english.OPEN_NEWS."+id).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("news_id",s.id).putExtra("news_category",category).putExtra("news_country",s.country).putExtra("news_title",s.title).putExtra("news_description",shorten(s.desc,260)).putExtra("news_link",s.link).putExtra("news_source",s.source).putExtra("news_published",s.published).putExtra("news_displayTitle",display.title).putExtra("news_displayBody",display.body);
  PendingIntent open=PendingIntent.getActivity(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_news).setContentTitle(shorten(display.title,160)).setContentText(shorten(display.body.replace('\n',' '),220)).setStyle(new Notification.BigTextStyle().bigText(display.body)).setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_RECOMMENDATION).setVisibility(Notification.VISIBILITY_PRIVATE).setShowWhen(true).setWhen(s.time>0?s.time:System.currentTimeMillis()).build();c.getSystemService(NotificationManager.class).notify(tag,id,n);
 }
 static boolean due(long last,long now){return last==0||now-last>=INTERVAL;}
 static boolean due(Context c,long last,long now){return last==0||now-last>=interval(c)*60000L;}
 static int deliver(Context c,boolean preview,java.util.function.BooleanSupplier stopped,NewsTranslation.Translator translator){return deliver(c,preview,"",stopped,translator);}
 static int deliver(Context c,boolean preview,String requested,java.util.function.BooleanSupplier stopped,NewsTranslation.Translator translator){
  JSONArray rules=NewsRules.read(c);android.content.SharedPreferences p=prefs(c);if(rules.length()==0)return deliverOne(c,preview,stopped,translator,p.getString("category","general"),p.getString("country","all"),p.getString("language","fa"),interval(c),batchCount(c),p.getBoolean("older",false),"last_delivered");
  Set<String> keys=new HashSet<>();try{JSONArray array=new JSONArray(requested);for(int i=0;i<array.length();i++)keys.add(array.getString(i));}catch(Exception ignored){}
  int delivered=0;long deadline=android.os.SystemClock.elapsedRealtime()+360000;java.util.function.BooleanSupplier cancelled=()->stopped.getAsBoolean()||android.os.SystemClock.elapsedRealtime()>deadline;
  int cursor=p.getInt("rule_cursor",0);for(int turn=0;turn<rules.length()&&!cancelled.getAsBoolean();turn++){int i=(cursor+turn)%rules.length();JSONObject rule=rules.optJSONObject(i);p.edit().putInt("rule_cursor",(i+1)%rules.length()).apply();if(!rule.optBoolean("enabled")||(!keys.isEmpty()&&!keys.contains(rule.optString("key"))))continue;delivered+=deliverOne(c,preview,cancelled,translator,rule.optString("category"),rule.optString("country"),rule.optString("language","fa"),rule.optInt("interval",20),rule.optInt("count",1),rule.optBoolean("older"),"last_rule_"+rule.optString("key"));}return delivered;
 }
 static boolean dueMinutes(long last,long now,int minutes){return last==0||now-last>=minutes*60000L;}
 static int deliverOne(Context c,boolean preview,java.util.function.BooleanSupplier stopped,NewsTranslation.Translator translator,String category,String scope,String language,int minutes,int limit,boolean older,String lastKey){
  NewsRepository repository=NewsRepository.get(c);android.content.SharedPreferences p=prefs(c);
  p.edit().putString("alert_checked",Instant.now().toString()).apply();
  if(stopped.getAsBoolean()||!p.getBoolean("enabled",false))return 0;
  if(!permitted(c)){p.edit().putString("delivery_state","permission").apply();return 0;}
  if(!preview&&!dueMinutes(p.getLong(lastKey,0),System.currentTimeMillis(),minutes))return 0;
  long revision=p.getLong("revision",0);int tries=0;
  List<Story> ready=new ArrayList<>();List<NewsTranslation.Display> displays=new ArrayList<>();long deadline=android.os.SystemClock.elapsedRealtime()+120000;
  for(Story story:repository.candidates(category,scope,older)){
   if(stopped.getAsBoolean()||android.os.SystemClock.elapsedRealtime()>deadline||tries++>=Math.max(6,limit*3)||ready.size()>=limit)break;
   NewsTranslation.Display display=NewsTranslation.display(story,language,translator);
   if(display==null)continue;ready.add(story);displays.add(display);
  }
  int posted=0;
  synchronized(DailyNews.class){
   if(stopped.getAsBoolean()||!p.getBoolean("enabled",false)||!permitted(c)||revision!=p.getLong("revision",0)||(!preview&&!dueMinutes(p.getLong(lastKey,0),System.currentTimeMillis(),minutes)))return 0;
   for(int i=0;i<ready.size();i++){Story story=ready.get(i);if(!repository.unsent(story))continue;
    // A stable article identity keeps several notices and their deep links separate.
    postNotice(c,story,story.category,displays.get(i),"nodin_news_story",NewsRepository.digest(NewsRepository.canonical(story.link)).hashCode());repository.delivered(story);posted++;
   }
   boolean waiting=ready.isEmpty()&&!repository.candidates(category,scope,older).isEmpty();
   android.content.SharedPreferences.Editor edit=p.edit().putBoolean("translation_pending",waiting).putString("delivery_state",posted>0?"sent":waiting?"translation":"empty");
   if(posted>0)edit.putLong(lastKey,System.currentTimeMillis()).putLong("last_delivered",System.currentTimeMillis()).putString("last_time",Instant.now().toString());edit.apply();
  }
  return posted;
 }
 @Override public Result doWork(){
  Context c=getApplicationContext();NewsRepository repository=NewsRepository.get(c);
  try{repository.refresh(getInputData().getBoolean("preview",false),this::isStopped);}catch(Exception e){return Result.retry();}
  deliver(c,getInputData().getBoolean("preview",false),getInputData().getString("ruleKeys"),this::isStopped,(value,from,to)->{if(isStopped())throw new IOException("Cancelled");return NewsTranslation.fetch(c,value,from,to);});
  NewsAlerts.ensure(c,false,-1);return Result.success();
 }
}
