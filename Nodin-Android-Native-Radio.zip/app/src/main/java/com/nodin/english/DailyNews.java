package com.nodin.english;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.net.Uri;
import androidx.work.*;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Opt-in daily headlines. WorkManager may delay delivery under battery restrictions. */
@androidx.media3.common.util.UnstableApi
public class DailyNews extends Worker {
 static final String CHANNEL="nodin_daily_news",WORK="nodin_daily_news_work";
 static final int NOTIFICATION=781;
 static final Set<String> CATEGORIES=new HashSet<>(Arrays.asList("general","gaming","sport","politics","economy","local","crime","christian","euronews"));
 public DailyNews(Context c,WorkerParameters p){super(c,p);}
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("daily_news",Context.MODE_PRIVATE);}
 static boolean permitted(Context c){return (Build.VERSION.SDK_INT<33||c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)&&c.getSystemService(NotificationManager.class).areNotificationsEnabled();}
 static void channel(Context c){NotificationChannel ch=new NotificationChannel(CHANNEL,"اخبار روز نودین",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("تیتر و گزیدهٔ اخبار روز؛ لمس اعلان برای مطالعه در برنامه");c.getSystemService(NotificationManager.class).createNotificationChannel(ch);}
 static void schedule(Context c,boolean enabled,String category){if(!CATEGORIES.contains(category))category="general";prefs(c).edit().putBoolean("enabled",enabled).putString("category",category).apply();channel(c);WorkManager w=WorkManager.getInstance(c);if(!enabled){w.cancelUniqueWork(WORK);w.cancelUniqueWork(WORK+"_now");c.getSystemService(NotificationManager.class).cancel(NOTIFICATION);return;}Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();w.enqueueUniquePeriodicWork(WORK,ExistingPeriodicWorkPolicy.UPDATE,new PeriodicWorkRequest.Builder(DailyNews.class,6,TimeUnit.HOURS).setConstraints(constraints).build());}
 static void now(Context c,boolean preview){WorkManager.getInstance(c).enqueueUniqueWork(WORK+"_now",ExistingWorkPolicy.REPLACE,new OneTimeWorkRequest.Builder(DailyNews.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setInputData(new Data.Builder().putBoolean("preview",preview).build()).build());}
 static JSONObject status(Context c){JSONObject o=new JSONObject();try{o.put("enabled",prefs(c).getBoolean("enabled",false));o.put("permitted",permitted(c));o.put("category",prefs(c).getString("category","general"));o.put("last",prefs(c).getString("last_time",""));}catch(Exception ignored){}return o;}
 static String text(String v){return android.text.Html.fromHtml(v,android.text.Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+"," ").trim();}
 static String shorten(String s,int n){return s.length()>n?s.substring(0,n-1)+"…":s;}
 static long date(String s){try{return ZonedDateTime.parse(s,DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli();}catch(Exception e){try{return Instant.parse(s).toEpochMilli();}catch(Exception ignored){return 0;}}}
 static final class Story {String title="",desc="",link="",source="",published="";long time;}
 static List<Story> parse(InputStream input,String source)throws Exception{XmlPullParser p=Xml.newPullParser();p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,true);p.setInput(input,"UTF-8");List<Story> out=new ArrayList<>();Story story=null;int type;while((type=p.next())!=XmlPullParser.END_DOCUMENT&&out.size()<60){if(type==XmlPullParser.START_TAG){String name=p.getName();if("item".equals(name)){story=new Story();story.source=source;}else if(story!=null&&Arrays.asList("title","description","link","pubDate").contains(name)){String v=p.nextText();if("title".equals(name))story.title=text(v);else if("description".equals(name))story.desc=text(v);else if("link".equals(name))story.link=v.trim();else {story.published=v;story.time=date(v);}}}else if(type==XmlPullParser.END_TAG&&"item".equals(p.getName())&&story!=null){Uri u=Uri.parse(story.link);if(!story.title.isEmpty()&&"https".equals(u.getScheme())&&u.getHost()!=null&&u.getUserInfo()==null)out.add(story);story=null;}}return out;}
 static void post(Context c,Story s,String category){if(!permitted(c))return;channel(c);Intent intent=new Intent(c,MainActivity.class).setAction("com.nodin.english.OPEN_NEWS").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("news_category",category).putExtra("news_title",s.title).putExtra("news_description",shorten(s.desc,260)).putExtra("news_link",s.link).putExtra("news_source",s.source).putExtra("news_published",s.published);PendingIntent open=PendingIntent.getActivity(c,NOTIFICATION,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);String body=s.source+(s.desc.isEmpty()?"":" — "+shorten(s.desc,220));Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_news).setContentTitle(shorten(s.title,160)).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_RECOMMENDATION).setVisibility(Notification.VISIBILITY_PRIVATE).setShowWhen(true).setWhen(s.time>0?s.time:System.currentTimeMillis()).build();c.getSystemService(NotificationManager.class).notify(NOTIFICATION,n);}
 @Override public Result doWork(){Context c=getApplicationContext();android.content.SharedPreferences p=prefs(c);boolean preview=getInputData().getBoolean("preview",false);if(!p.getBoolean("enabled",false)||!permitted(c))return Result.success();LocalDate today=LocalDate.now();int hour=LocalTime.now().getHour();if(!preview&&(hour<8||hour>=22||today.toString().equals(p.getString("last_day",""))))return Result.success();String category=p.getString("category","general");List<Story> stories=new ArrayList<>();try{String json;try(InputStream in=c.getAssets().open("headline-feeds.json")){ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=in.read(buffer))!=-1)bytes.write(buffer,0,count);json=new String(bytes.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);}JSONArray feeds=new JSONObject(json).getJSONArray(category);for(int i=0;i<feeds.length();i++){if(isStopped())return Result.success();String feed=feeds.getString(i);try{android.webkit.WebResourceResponse r=NativeNews.fetch(Uri.parse("https://appassets.androidplatform.net/native-news?url="+Uri.encode(feed)));if(r.getStatusCode()==200)try(InputStream in=r.getData()){stories.addAll(parse(in,Uri.parse(feed).getHost()));}}catch(Exception ignored){}}}catch(Exception e){return Result.retry();}
 long now=System.currentTimeMillis();stories.removeIf(s->s.time<=0||s.time>now+60000||now-s.time>72*3600000L);stories.sort((a,b)->Long.compare(b.time,a.time));if(stories.isEmpty())return Result.success();Story s=stories.get(0);if(!preview&&s.link.equals(p.getString("last_link","")))return Result.success();if(!p.getBoolean("enabled",false)||!permitted(c))return Result.success();post(c,s,category);if(!preview)p.edit().putString("last_day",today.toString()).putString("last_link",s.link).putString("last_time",Instant.now().toString()).apply();return Result.success();}
}
