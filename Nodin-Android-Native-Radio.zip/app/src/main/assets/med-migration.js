/* Official Mediterranean migration reports. Data is fetched, never bundled as current. */
(function(){
  'use strict';
  const SOURCES = {
    it:{name:['ایتالیا','Italy'], stats:'https://libertaciviliimmigrazione.dlci.interno.gov.it/documentazione/dati-e-statistiche/cruscotto-statistico-giornaliero', links:[['وزارت کشور ایتالیا / Italian Interior Ministry','https://libertaciviliimmigrazione.dlci.interno.gov.it/documentazione/dati-e-statistiche/cruscotto-statistico-giornaliero']], news:[['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]},
    tr:{name:['ترکیه','Türkiye'],stats:'https://www.goc.gov.tr/duzensiz-goc-istatistikler',links:[['ادارهٔ مهاجرت / Migration Management','https://www.goc.gov.tr/duzensiz-goc-istatistikler'],['گارد ساحلی / Coast Guard','https://www.sg.gov.tr/haberler'],['پلیس / Police','https://www.egm.gov.tr/']],news:[['ادارهٔ مهاجرت ترکیه','https://www.goc.gov.tr/haberler','cards'],['گارد ساحلی ترکیه','https://www.sg.gov.tr/haberler','cards'],['وزارت کشور ترکیه','https://www.icisleri.gov.tr/haberler','cards'],['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]},
    gr:{name:['یونان','Greece'],stats:'https://migration.gov.gr/en/statistika/',links:[['وزارت مهاجرت و پناهندگی / Migration Ministry','https://migration.gov.gr/en/statistika/'],['پلیس یونان / Hellenic Police','https://www.astynomia.gr/'],['گارد ساحلی / Hellenic Coast Guard','https://www.hcg.gr/el/']],news:[['پلیس یونان','https://www.astynomia.gr/','greek'],['گارد ساحلی یونان','https://www.hcg.gr/el/epikairothta/','greek'],['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]}
  };
  const TURKEY_TYPES={irregular:'https://www.goc.gov.tr/duzensiz-goc-istatistikler',residence:'https://www.goc.gov.tr/ikamet-izinleri',temporary:'https://www.goc.gov.tr/gecici-koruma'};
  const HOSTS=new Set(Object.values(SOURCES).flatMap(s=>[s.stats,...s.links.map(x=>x[1]),...s.news.map(x=>x[1])]).map(u=>new URL(u).hostname));
  const lastStats={}, lastNews={};
  let api, wired=false, statsGeneration=0, newsGeneration=0, report=null, objectUrls=[];
  const $=id=>document.getElementById(id);
  const fa=()=>!api || api.lang==='fa';
  const txt=(a,b)=>fa()?a:b;
  const country=()=>$('regionCountry').value;
  const number=n=>Number(n).toLocaleString(fa()?'fa-IR':'en-GB');
  function node(tag,text,cls){const el=document.createElement(tag);if(text!=null)el.textContent=text;if(cls)el.className=cls;return el;}
  function safeUrl(value,base){try{const u=new URL(value,base);return u.protocol==='https:'&&HOSTS.has(u.hostname)&&!u.username&&!u.password?u.href:'';}catch(e){return '';}}
  function link(label,url){const a=node('a',label);a.href=url;a.target='_blank';a.rel='noopener';return a;}
  function parsePage(html){return new DOMParser().parseFromString(html,'text/html');}
  function linksFrom(html,base){return Array.from(parsePage(html).querySelectorAll('a[href]')).map(a=>({title:a.textContent.replace(/\s+/g,' ').trim(),url:safeUrl(a.getAttribute('href'),base)})).filter(a=>a.url);}
  function latestItalianReport(html,base){return linksFrom(html,base).find(a=>/cruscotto statistico giornaliero/i.test(a.title)&&/\.pdf(?:$|\?)/i.test(a.url));}
  function latestGreekReport(html,base){
    const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
    return linksFrom(html,base).filter(a=>/International.Protection/i.test(a.title+' '+a.url)&&!/appendix/i.test(a.title+' '+a.url)&&/\.pdf(?:$|\?)/i.test(a.url)).map(a=>{
      const t=decodeURIComponent(a.url).toLowerCase(),year=a.title.match(/\b(?:19|20)\d{2}\b/)||t.split('/').pop().match(/(?:19|20)\d{2}/);
      const month=months.findIndex(m=>t.includes(m));return Object.assign(a,{rank:Number(year?year[0]:0)*12+month});
    }).sort((a,b)=>b.rank-a.rank)[0];
  }
  function turkishCharts(html,base){return Array.from(parsePage(html).querySelectorAll('img[src]')).map(img=>safeUrl(img.getAttribute('src'),base)).filter(u=>u&&/\/Istatistikler\/.*\.(?:png|jpe?g)/i.test(u)).filter((u,i,a)=>a.indexOf(u)===i).slice(0,8);}
  function chartDate(url){const m=decodeURIComponent(url).match(/Istatistikler\/(20\d{2})\/[^/]+\/(\d{1,2})-([^/]+)/i);if(!m)return txt('تاریخ در نمودار رسمی درج شده است.','See the date on the official chart.');const months={Ocak:'01',Subat:'02',Mart:'03',Nisan:'04',Mayis:'05',Haziran:'06',Temmuz:'07',Agustos:'08',Eylul:'09',Ekim:'10',Kasim:'11',Aralik:'12'};return m[2]+'/'+(months[m[3]]||m[3])+'/'+m[1];}
  function italianNationalities(lines){
    const names={Bangladesh:'بنگلادش',Algeria:'الجزایر',Somalia:'سومالی',Sudan:'سودان',Eritrea:'اریتره',Pakistan:'پاکستان',Egitto:'مصر',Tunisia:'تونس',Mali:'مالی',Nigeria:'نیجریه',Etiopia:'اتیوپی',"Costa d’Avorio":'ساحل عاج',"Costa d'Avorio":'ساحل عاج',Iran:'ایران',Guinea:'گینه','Sud Sudan':'سودان جنوبی',Altre:'سایر',Totale:'مجموع'};
    const rows=[];
    for(const line of lines){const m=line.trim().match(/^([\p{L} ’'\-]+?)\s*\*{0,2}\s+(\d[\d.,]*)\s*$/u);if(m)rows.push({name:m[1],fa:names[m[1]]||m[1],count:Number(m[2].replace(/[.,]/g,''))});}
    return rows;
  }
  async function pdfLines(pdf,pageNumber){const content=await (await pdf.getPage(pageNumber)).getTextContent();const rows=new Map();for(const item of content.items){const y=Math.round(item.transform[5]);if(!rows.has(y))rows.set(y,[]);rows.get(y).push(item);}return [...rows.entries()].sort((a,b)=>b[0]-a[0]).map(([,items])=>items.sort((a,b)=>a.transform[4]-b.transform[4]).map(i=>i.str).join(' ').replace(/\s+/g,' ').trim());}
  async function loadPdf(url){const lib=window['pdfjs-dist/build/pdf'];if(!lib)throw new Error('PDF reader unavailable');lib.GlobalWorkerOptions.workerSrc='pdf.worker.min.js';const blob=await api.fetchBlob(url);return lib.getDocument({data:new Uint8Array(await blob.arrayBuffer())}).promise;}
  function table(rows){const el=node('table',null,'migrant-region-table');const head=node('tr');head.append(node('th',txt('تابعیت اعلام‌شده','Declared nationality')),node('th',txt('تعداد ورود دریایی','Sea arrivals')));const thead=node('thead');thead.append(head);el.append(thead);const body=node('tbody');rows.forEach(r=>{const tr=node('tr');tr.append(node('td',fa()?r.fa:r.name),node('td',number(r.count)));body.append(tr);});el.append(body);return el;}
  async function pdfViewer(pdf,host,url,generation,firstPage){
    const controls=node('div',null,'fetch-row'),label=node('label',txt('صفحهٔ گزارش: ','Report page: ')),select=node('select'),status=node('span'),canvas=node('canvas');
    canvas.style.cssText='display:block;width:100%;height:auto;background:white;';
    for(let p=1;p<=pdf.numPages;p++){const option=node('option',txt('صفحهٔ ','Page ')+number(p));option.value=String(p);select.append(option);}select.value=String(firstPage);label.append(select);controls.append(label,link(txt('بازکردن گزارش اصلی','Open original report'),url),status);host.append(controls,canvas);
    let drawing=0;
    async function draw(){const epoch=++drawing;status.textContent=txt('در حال نمایش…','Rendering…');try{const page=await pdf.getPage(Number(select.value));if(epoch!==drawing||generation!==statsGeneration)return;const viewport=page.getViewport({scale:Math.min(2,1300/page.getViewport({scale:1}).width)});const tmp=document.createElement('canvas');tmp.width=viewport.width;tmp.height=viewport.height;await page.render({canvasContext:tmp.getContext('2d'),viewport}).promise;if(epoch!==drawing||generation!==statsGeneration)return;canvas.width=tmp.width;canvas.height=tmp.height;canvas.getContext('2d').drawImage(tmp,0,0);status.textContent='';}catch(e){if(epoch===drawing)status.textContent=txt('نمایش گزارش ممکن نشد؛ لینک اصلی را باز کنید.','Cannot render; open the original report.');}}
    select.addEventListener('change',draw);await draw();
  }
  function fetchedLabel(){return txt('دریافت در: ','Retrieved: ')+new Date().toLocaleString(fa()?'fa-IR':'en-GB');}
  async function refreshStats(){
    const key=country(),source=SOURCES[key],generation=++statsGeneration,host=$('regionStatsContent'),status=$('regionStatsStatus');
    $('regionStatsBtn').disabled=true;host.replaceChildren();status.textContent=txt('در حال دریافت آمار رسمی…','Loading official statistics…');
    objectUrls.forEach(url=>URL.revokeObjectURL(url));objectUrls=[];if(report){report.destroy();report=null;}
    try{
      const statsUrl=key==='tr'?TURKEY_TYPES[$('regionStatsType').value]:source.stats;
      const html=await api.fetchText(statsUrl);if(generation!==statsGeneration)return;
      if(key==='tr'){
        const charts=turkishCharts(html,statsUrl);if(!charts.length)throw new Error('Statistics charts unavailable');
        host.append(link(txt('صفحهٔ رسمی این آمار','Official statistics page'),statsUrl));
        if($('regionStatsType').value==='irregular')host.append(node('p',txt('آمار رسمی مهاجرت نامنظم و افراد شناسایی‌شده؛ این ارقام جمع کل مهاجران مقیم ترکیه نیست.','Official irregular migration and apprehension charts; these are not the total resident migrant population.')));
        host.append(node('p',txt('تاریخ نمودار منبع: ','Source chart date: ')+chartDate(charts[0])));
        const labels=[];
        const select=node('select');charts.forEach((u,i)=>{const o=node('option',fa()?(labels[i]||'نمودار رسمی '+(i+1)):'Official chart '+(i+1));o.value=u;select.append(o);});const chartHost=node('div'),chartStatus=node('p');host.append(select,chartStatus,chartHost);let imageGeneration=0;
        async function display(){const epoch=++imageGeneration;chartStatus.textContent=txt('در حال دریافت نمودار…','Loading chart…');chartHost.replaceChildren();try{const blob=await api.fetchBlob(select.value);if(generation!==statsGeneration||epoch!==imageGeneration)return;const url=URL.createObjectURL(blob);objectUrls.push(url);const image=node('img');image.src=url;image.alt=select.selectedOptions[0].textContent;image.style.cssText='width:100%;height:auto;background:white';chartHost.append(link(txt('نمایش نمودار در اندازهٔ اصلی','Open full-size chart'),select.value),image);chartStatus.textContent='';}catch(e){if(epoch===imageGeneration)chartStatus.textContent=txt('دریافت نمودار ناموفق؛ لینک منبع را باز کنید.','Chart unavailable; open the source.');}}
        select.addEventListener('change',display);await display();
      }else{
        const selected=key==='it'?latestItalianReport(html,source.stats):latestGreekReport(html,source.stats);if(!selected)throw new Error('Report link unavailable');
        const pdf=await loadPdf(selected.url);if(generation!==statsGeneration){pdf.destroy();return;}report=pdf;
        if(key==='it'){
          let rows=[],lines=[];
          for(let p=1;p<=Math.min(pdf.numPages,8);p++){const candidate=await pdfLines(pdf,p);if(candidate.join(' ').includes('Nazionalità')){rows=italianNationalities(candidate);lines=candidate;break;}}
          if(generation!==statsGeneration)return;
          const period=lines.find(l=>/periodo dal/i.test(l));host.append(node('p',txt('دورهٔ آمار: ','Reporting period: ')+(period||decodeURIComponent(selected.url.split('/').pop()))));
          host.append(node('p',txt('این جدول، تابعیت اعلام‌شده هنگام ورود دریایی را نشان می‌دهد؛ کشور محل سوارشدن به قایق یا کل مهاجران مقیم ایتالیا را نشان نمی‌دهد.','Declared nationality at sea arrival, not boat departure country or total resident migrants.')));
          if(rows.length){const total=rows.find(r=>r.name==='Totale');if(total)host.append(node('h4',txt('مجموع ورود دریایی: ','Total sea arrivals: ')+number(total.count)));host.append(table(rows));}
          else host.append(node('p',txt('جدول عددی قابل استخراج نبود؛ آمار و تابعیت‌ها را در گزارش زیر ببینید.','The table could not be extracted; see arrivals and nationalities in the report below.')));
          await pdfViewer(pdf,host,selected.url,generation,Math.min(4,pdf.numPages));
        }else{
          host.append(node('h4',selected.title),node('p',txt('گزارش رسمی شامل ورودها، متقاضیان پناهندگی، ظرفیت و جمعیت مراکز است. از انتخاب صفحه برای دیدن جدول‌ها و نمودارها استفاده کنید. آمار ورود با تعداد مهاجران مقیم متفاوت است.','Official report of arrivals, asylum applicants and reception populations. Select a page for tables and charts; arrivals differ from resident population.')));
          const legal=linksFrom(html,source.stats).filter(a=>/\.pdf$/i.test(a.url)&&/Νόμιμη Μετανάστευση/i.test(a.title)&&!/Παράρτημα/i.test(a.title)).sort((a,b)=>b.url.localeCompare(a.url));if(legal.length)host.append(link(txt('گزارش مهاجرت قانونی و اقامت','Legal migration and residence report')+' — '+legal[0].title,legal[0].url));
          await pdfViewer(pdf,host,selected.url,generation,Math.min(2,pdf.numPages));
        }
      }
      if(generation===statsGeneration){lastStats[key]=Date.now();status.textContent=fetchedLabel()+txt(' — تاریخ آمار در گزارش منبع درج شده است.',' — Data period is shown in the source report.');}
    }catch(e){if(generation===statsGeneration){host.replaceChildren();status.textContent=txt('دریافت آمار ناموفق بود. دوباره تلاش کنید یا منبع رسمی را باز کنید.','Statistics unavailable. Retry or open the official source.');}}
    finally{if(generation===statsGeneration)$('regionStatsBtn').disabled=false;}
  }
  function dateFrom(text){const m=text.match(/\b(\d{1,2})[.\/-](\d{1,2})[.\/-]((?:20)?\d{2})\b/);return m?(m[3].length===2?'20'+m[3]:m[3])+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0'):'';}
  function parseNews(html,source,kind,key){
    const doc=new DOMParser().parseFromString(html,kind==='rss'?'text/xml':'text/html');let articles=[];
    if(kind==='rss')articles=Array.from(doc.querySelectorAll('item')).map(it=>({title:it.querySelector('title')?.textContent||'',desc:it.querySelector('description')?.textContent||'',link:safeUrl(it.querySelector('link')?.textContent,source),published:it.querySelector('pubDate')?.textContent||''}));
    else if(kind==='cards')articles=Array.from(doc.querySelectorAll('a.news-card-horizontal')).map(a=>({title:a.querySelector('.card-title')?.textContent.trim()||'',desc:a.querySelector('.card-text')?.textContent.trim()||'',link:safeUrl(a.getAttribute('href'),source),published:dateFrom(a.textContent)}));
    else articles=Array.from(doc.querySelectorAll('a[href]')).map(a=>({title:a.textContent.replace(/\s+/g,' ').trim(),desc:'',link:safeUrl(a.getAttribute('href'),source),published:dateFrom(a.textContent)||dateFrom(a.closest('.ipost,article,.entry')?.textContent||'')||dateFrom(a.getAttribute('href')||'')}));
    const patterns={it:/\b(Italy|Italian|Lampedusa)\b|ایتالیا|لامپدوسا/i,tr:/göç|goc|gocmen|göçmen|sınır dışı|sinir-disi|migrant|refugee|asylum|پناه|مهاجر/i,gr:/μεταναστ|παράνομ.*(?:αλλοδαπ|είσοδ)|εντοπισμ.*αλλοδαπ|διακινητ|migrant|refugee|asylum|پناه|مهاجر/i};
    return articles.filter(a=>a.title.length>15&&a.link&&patterns[key].test(a.title+' '+a.desc+' '+decodeURIComponent(a.link))).filter(a=>kind!=='rss'||new RegExp(key==='it'?'Italy|Italian|Lampedusa|ایتالیا':key==='tr'?'Turkey|Turkish|Türkiye|ترکیه':'Greece|Greek|یونان','i').test(a.title+' '+a.desc));
  }
  async function refreshNews(){
    const key=country(),generation=++newsGeneration,host=$('regionNewsContent'),status=$('regionNewsStatus');$('regionNewsBtn').disabled=true;host.replaceChildren();status.textContent=txt('در حال دریافت اخبار…','Loading news…');
    const results=await Promise.allSettled(SOURCES[key].news.map(async([name,url,kind])=>parseNews(await api.fetchText(url),url,kind,key).map(a=>Object.assign(a,{source:name}))));
    if(generation!==newsGeneration)return;
    let items=results.filter(r=>r.status==='fulfilled').flatMap(r=>r.value);const seen=new Set();items=items.filter(a=>{if(seen.has(a.link))return false;seen.add(a.link);return true;}).sort((a,b)=>(Date.parse(b.published)||0)-(Date.parse(a.published)||0)).slice(0,20);
    if(!items.length)status.textContent=txt('خبر مرتبطی از منابع قابل دسترس دریافت نشد؛ دوباره تلاش کنید.','No relevant reports received from available sources; please retry.');
    else{lastNews[key]=Date.now();status.textContent=fetchedLabel()+' • '+number(items.length)+txt(' خبر',' reports')+(results.some(r=>r.status==='rejected')?txt(' — بعضی منابع در دسترس نبودند.',' — Some sources were unavailable.'):'');
      const translations=[];
      items.forEach(a=>{const card=node('div',null,'migrant-news-card'),date=a.published&&Date.parse(a.published)?new Date(a.published).toLocaleDateString(fa()?'fa-IR':'en-GB'):txt('تاریخ انتشار در منبع','Publication date at source');card.append(node('div',a.source+' • '+date,'src'),link(a.title,a.link));if(fa()&&!/[\u0600-\u06ff]/.test(a.title)){const translation=node('p',txt('در حال ترجمهٔ تیتر…','Translating headline…'),'dsc');card.append(translation);translations.push([a.title,translation]);}host.append(card);});
      (async()=>{for(const [title,el]of translations){if(generation!==newsGeneration)return;try{const text=await api.translate(title);if(generation===newsGeneration)el.textContent=text?txt('ترجمهٔ ماشینی: ','Machine translation: ')+text:txt('ترجمه در دسترس نیست.','Translation unavailable.');}catch(e){if(generation===newsGeneration)el.textContent=txt('ترجمه در دسترس نیست.','Translation unavailable.');}}})();
    }
    $('regionNewsBtn').disabled=false;
  }
  function selectCountry(){
    const source=SOURCES[country()];$('regionStatsTypeLabel').hidden=country()!=='tr';$('regionSources').replaceChildren();source.links.forEach(([label,url])=>{$('regionSources').append(link(label,url),document.createTextNode(' · '));});
    $('regionScope').textContent=txt('آمار ورود، بازداشت، اقامت و پناهندگی معیارهای متفاوتی هستند. تاریخ آمار ممکن است از امروز عقب‌تر باشد؛ تاریخ دریافت به معنی تاریخ آمار نیست.','Arrivals, apprehensions, residence and asylum measure different things. Retrieval time is not the data reporting date.');
    $('regionNewsHeading').textContent=country()==='it'?txt('📰 اخبار مهاجرت ایتالیا','📰 Italy migration news'):txt('📰 اخبار بازداشت، کنترل مهاجرت و نجات — ','📰 Apprehensions, migration controls and rescues — ')+source.name[fa()?0:1];
    refreshStats();refreshNews();
  }
  window.MigrantRegion={open(options){api=options;if(!wired){wired=true;$('regionStatsType').addEventListener('change',refreshStats);$('regionCountry').addEventListener('change',selectCountry);$('regionStatsBtn').addEventListener('click',refreshStats);$('regionNewsBtn').addEventListener('click',refreshNews);selectCountry();}else{const key=country();if(!lastStats[key]||Date.now()-lastStats[key]>300000)refreshStats();if(!lastNews[key]||Date.now()-lastNews[key]>300000)refreshNews();}},
    // Pure parsers are exposed for source-format regression checks.
    parsers:{latestItalianReport,latestGreekReport,turkishCharts,italianNationalities,parseNews,chartDate},sources:SOURCES};
})();
