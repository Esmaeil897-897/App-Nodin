/* Official Mediterranean migration reports. Data is fetched, never bundled as current. */
(function(){
  'use strict';
  const COMMON_NEWS=[['BBC Europe','https://feeds.bbci.co.uk/news/world/europe/rss.xml','rss'],['The Guardian','https://www.theguardian.com/world/migration/rss','rss'],['Euronews','https://www.euronews.com/rss?level=vertical&name=news','rss'],['ANSA English','https://www.ansa.it/english/news/english_rss.xml','rss']];

  const SOURCES = {
    it:{name:['ایتالیا','Italy'], stats:'https://libertaciviliimmigrazione.dlci.interno.gov.it/documentazione/dati-e-statistiche/cruscotto-statistico-giornaliero', links:[['وزارت کشور ایتالیا / Italian Interior Ministry','https://libertaciviliimmigrazione.dlci.interno.gov.it/documentazione/dati-e-statistiche/cruscotto-statistico-giornaliero']], news:[['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]},
    tr:{name:['ترکیه','Türkiye'],stats:'https://www.goc.gov.tr/duzensiz-goc-istatistikler',links:[['ادارهٔ مهاجرت / Migration Management','https://www.goc.gov.tr/duzensiz-goc-istatistikler'],['گارد ساحلی / Coast Guard','https://www.sg.gov.tr/haberler'],['پلیس / Police','https://www.egm.gov.tr/']],news:[['ادارهٔ مهاجرت ترکیه','https://www.goc.gov.tr/haberler','cards'],['گارد ساحلی ترکیه','https://www.sg.gov.tr/haberler','cards'],['وزارت کشور ترکیه','https://www.icisleri.gov.tr/haberler','cards'],['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]},
    gr:{name:['یونان','Greece'],stats:'https://migration.gov.gr/en/statistika/',links:[['وزارت مهاجرت و پناهندگی / Migration Ministry','https://migration.gov.gr/en/statistika/'],['پلیس یونان / Hellenic Police','https://www.astynomia.gr/'],['گارد ساحلی / Hellenic Coast Guard','https://www.hcg.gr/el/']],news:[['پلیس یونان','https://www.astynomia.gr/','greek'],['گارد ساحلی یونان','https://www.hcg.gr/el/epikairothta/','greek'],['InfoMigrants','https://www.infomigrants.net/en/rss/all.xml','rss']]}
  };
  Object.values(SOURCES).forEach(s=>s.news.push(...COMMON_NEWS));
  Object.entries({it:'italy',tr:'turkey',gr:'greece'}).forEach(([key,tag])=>SOURCES[key].news.push(['The Guardian — '+SOURCES[key].name[1],'https://www.theguardian.com/world/'+tag,'archive'],['Euronews — '+SOURCES[key].name[1],'https://www.euronews.com/tag/'+tag,'archive'],['Euronews migration','https://www.euronews.com/tag/migration','archive']));
  SOURCES.it.news.push(['ANSA Sicilia','https://www.ansa.it/sicilia/notizie/sicilia_rss.xml','rss']);
  SOURCES.tr.news.push(['Daily Sabah','https://www.dailysabah.com/tags?query=irregular-migration','archive']);SOURCES.gr.news.push(['GreekReporter','https://greekreporter.com/society/immigration/','archive']);
  const TURKEY_TYPES={irregular:'https://www.goc.gov.tr/duzensiz-goc-istatistikler',residence:'https://www.goc.gov.tr/ikamet-izinleri',temporary:'https://www.goc.gov.tr/gecici-koruma5638'};
  const EXTRA_HOSTS=['www.ansa.it','www.dailysabah.com','greekreporter.com','www.bbc.co.uk','www.bbc.com','asylumineurope.org','data.unhcr.org','www.unhcr.org'];
  const HOSTS=new Set(Object.values(SOURCES).flatMap(s=>[s.stats,...s.links.map(x=>x[1]),...s.news.map(x=>x[1])]).map(u=>new URL(u).hostname).concat(EXTRA_HOSTS));
  const lastStats={}, lastNews={};
  let extraPdfs=[];
  let api, wired=false, statsGeneration=0, newsGeneration=0, report=null, objectUrls=[];
  const $=id=>document.getElementById(id);
  const fa=()=>!api || api.lang==='fa';
  const txt=(a,b)=>fa()?a:b;
  const country=()=>$('regionCountry').value;
  const number=n=>Number(n).toLocaleString(fa()?'fa-IR':'en-GB');
  function node(tag,text,cls){const el=document.createElement(tag);if(text!=null)el.textContent=text;if(cls)el.className=cls;return el;}
  function safeUrl(value,base){try{const u=new URL(value,base);return u.protocol==='https:'&&HOSTS.has(u.hostname)&&!u.username&&!u.password?u.href:'';}catch(e){return '';}}
  function link(label,url){const a=node('a',label);a.href=url;a.target='_blank';a.rel='noopener';return a;}
  function parsePage(html){return new DOMParser().parseFromString(html,'text/html');}
  function linksFrom(html,base){return Array.from(parsePage(html).querySelectorAll('a[href]')).map(a=>({title:a.textContent.replace(/\s+/g,' ').trim(),url:safeUrl(a.getAttribute('href'),base)})).filter(a=>a.url);}
  function latestItalianReport(html,base){return linksFrom(html,base).find(a=>/cruscotto statistico giornaliero/i.test(a.title)&&/\.pdf(?:$|\?)/i.test(a.url));}
  function latestGreekReport(html,base){
    const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
    return linksFrom(html,base).filter(a=>/International.Protection/i.test(a.title+' '+a.url)&&!/appendix/i.test(a.title+' '+a.url)&&/\.pdf(?:$|\?)/i.test(a.url)).map(a=>{
      const t=decodeURIComponent(a.url).toLowerCase(),year=a.title.match(/\b(?:19|20)\d{2}\b/)||t.split('/').pop().match(/(?:19|20)\d{2}/);
      const month=months.findIndex(m=>t.includes(m));return Object.assign(a,{rank:Number(year?year[0]:0)*12+month});
    }).sort((a,b)=>b.rank-a.rank)[0];
  }
  function turkishCharts(html,base){return Array.from(parsePage(html).querySelectorAll('img[src]')).map(img=>safeUrl(img.getAttribute('src'),base)).filter(u=>u&&/\/Istatistikler\/.*\.(?:png|jpe?g)/i.test(u)).filter((u,i,a)=>a.indexOf(u)===i).slice(0,8);}
  function chartDate(url){const m=decodeURIComponent(url).match(/Istatistikler\/(20\d{2})\/[^/]+\/(\d{1,2})-([^/]+)/i);if(!m)return txt('تاریخ در نمودار رسمی درج شده است.','See the date on the official chart.');const months={Ocak:'01',Subat:'02',Mart:'03',Nisan:'04',Mayis:'05',Haziran:'06',Temmuz:'07',Agustos:'08',Eylul:'09',Ekim:'10',Kasim:'11',Aralik:'12'};return m[2]+'/'+(months[m[3]]||m[3])+'/'+m[1];}
  function italianNationalities(lines){
    const names={Bangladesh:'بنگلادش',Algeria:'الجزایر',Somalia:'سومالی',Sudan:'سودان',Eritrea:'اریتره',Pakistan:'پاکستان',Egitto:'مصر',Tunisia:'تونس',Mali:'مالی',Nigeria:'نیجریه',Etiopia:'اتیوپی',"Costa d’Avorio":'ساحل عاج',"Costa d'Avorio":'ساحل عاج',Iran:'ایران',Guinea:'گینه','Sud Sudan':'سودان جنوبی',Altre:'سایر',Totale:'مجموع'};
    const rows=[];
    for(const line of lines){const m=line.trim().match(/^([\p{L} ’'\-]+?)\s*\*{0,2}\s+(\d[\d.,]*)\s*$/u);if(m)rows.push({name:m[1],fa:names[m[1]]||m[1],count:Number(m[2].replace(/[.,]/g,''))});}
    return rows;
  }
  async function pdfLines(pdf,pageNumber){const content=await (await pdf.getPage(pageNumber)).getTextContent();const rows=new Map();for(const item of content.items){const y=Math.round(item.transform[5]);if(!rows.has(y))rows.set(y,[]);rows.get(y).push(item);}return [...rows.entries()].sort((a,b)=>b[0]-a[0]).map(([,items])=>items.sort((a,b)=>a.transform[4]-b.transform[4]).map(i=>i.str).join(' ').replace(/\s+/g,' ').trim());}
  async function loadPdf(url){const lib=window['pdfjs-dist/build/pdf'];if(!lib)throw new Error('PDF reader unavailable');lib.GlobalWorkerOptions.workerSrc='pdf.worker.min.js';const blob=await api.fetchBlob(url);return lib.getDocument({data:new Uint8Array(await blob.arrayBuffer())}).promise;}
  function table(rows){const el=node('table',null,'migrant-region-table');const head=node('tr');head.append(node('th',txt('تابعیت اعلام‌شده','Declared nationality')),node('th',txt('تعداد ورود دریایی','Sea arrivals')));const thead=node('thead');thead.append(head);el.append(thead);const body=node('tbody');rows.forEach(r=>{const tr=node('tr');tr.append(node('td',fa()?r.fa:r.name),node('td',number(r.count)));body.append(tr);});el.append(body);return el;}
  async function pdfViewer(pdf,host,url,generation,firstPage){
    const controls=node('div',null,'fetch-row'),label=node('label',txt('صفحهٔ گزارش: ','Report page: ')),select=node('select'),status=node('span'),canvas=node('canvas');
    canvas.style.cssText='display:block;width:100%;height:auto;background:white;';
    for(let p=1;p<=pdf.numPages;p++){const option=node('option',txt('صفحهٔ ','Page ')+number(p));option.value=String(p);select.append(option);}select.value=String(firstPage);label.append(select);controls.append(label,link(txt('بازکردن گزارش اصلی','Open original report'),url),status);host.append(controls,canvas);
    let drawing=0;
    async function draw(){const epoch=++drawing;status.textContent=txt('در حال نمایش…','Rendering…');try{const page=await pdf.getPage(Number(select.value));if(epoch!==drawing||generation!==statsGeneration)return;const viewport=page.getViewport({scale:Math.min(2,1300/page.getViewport({scale:1}).width)});const tmp=document.createElement('canvas');tmp.width=viewport.width;tmp.height=viewport.height;await page.render({canvasContext:tmp.getContext('2d'),viewport}).promise;if(epoch!==drawing||generation!==statsGeneration)return;canvas.width=tmp.width;canvas.height=tmp.height;canvas.getContext('2d').drawImage(tmp,0,0);status.textContent='';}catch(e){if(epoch===drawing)status.textContent=txt('نمایش گزارش ممکن نشد؛ لینک اصلی را باز کنید.','Cannot render; open the original report.');}}
    select.addEventListener('change',draw);await draw();
  }
  function fetchedLabel(){return txt('دریافت در: ','Retrieved: ')+new Date().toLocaleString(fa()?'fa-IR':'en-GB');}
  async function refreshStats(){
    const key=country(),source=SOURCES[key],generation=++statsGeneration,host=$('regionStatsContent'),status=$('regionStatsStatus');
    $('regionStatsBtn').disabled=true;host.replaceChildren();status.textContent=txt('در حال دریافت آمار رسمی…','Loading official statistics…');
    objectUrls.forEach(url=>URL.revokeObjectURL(url));objectUrls=[];if(report){report.destroy();report=null;}
    try{
      const statsUrl=key==='tr'?TURKEY_TYPES[$('regionStatsType').value]:source.stats;
      const html=await api.fetchText(statsUrl);if(generation!==statsGeneration)return;
      if(key==='tr'){
        const charts=turkishCharts(html,statsUrl);if(!charts.length)throw new Error('Statistics charts unavailable');
        host.append(link(txt('صفحهٔ رسمی این آمار','Official statistics page'),statsUrl));
        if($('regionStatsType').value==='irregular')host.append(node('p',txt('آمار رسمی مهاجرت نامنظم و افراد شناسایی‌شده؛ این ارقام جمع کل مهاجران مقیم ترکیه نیست.','Official irregular migration and apprehension charts; these are not the total resident migrant population.')));
        host.append(node('p',txt('تاریخ نمودار منبع: ','Source chart date: ')+chartDate(charts[0])));
        const labels=[];
        const select=node('select');charts.forEach((u,i)=>{const o=node('option',fa()?(labels[i]||'نمودار رسمی '+(i+1)):'Official chart '+(i+1));o.value=u;select.append(o);});const chartHost=node('div'),chartStatus=node('p');host.append(select,chartStatus,chartHost);let imageGeneration=0;
        async function display(){const epoch=++imageGeneration;chartStatus.textContent=txt('در حال دریافت نمودار…','Loading chart…');chartHost.replaceChildren();try{const blob=await api.fetchBlob(select.value);if(generation!==statsGeneration||epoch!==imageGeneration)return;const url=URL.createObjectURL(blob);objectUrls.push(url);const image=node('img');image.src=url;image.alt=select.selectedOptions[0].textContent;image.style.cssText='width:100%;height:auto;background:white';chartHost.append(link(txt('نمایش نمودار در اندازهٔ اصلی','Open full-size chart'),select.value),image);chartStatus.textContent='';}catch(e){if(epoch===imageGeneration)chartStatus.textContent=txt('دریافت نمودار ناموفق؛ لینک منبع را باز کنید.','Chart unavailable; open the source.');}}
        select.addEventListener('change',display);await display();
      }else{
        const selected=key==='it'?latestItalianReport(html,source.stats):latestGreekReport(html,source.stats);if(!selected)throw new Error('Report link unavailable');
        const pdf=await loadPdf(selected.url);if(generation!==statsGeneration){pdf.destroy();return;}report=pdf;
        if(key==='it'){
          await renderItalianOverview(pdf,host,generation);if(generation!==statsGeneration)return;
          let rows=[],lines=[];
          for(let p=1;p<=Math.min(pdf.numPages,8);p++){const candidate=await pdfLines(pdf,p);if(candidate.join(' ').includes('Nazionalità')){rows=italianNationalities(candidate);lines=candidate;break;}}
          if(generation!==statsGeneration)return;
          const period=lines.find(l=>/periodo dal/i.test(l));host.append(node('p',txt('دورهٔ آمار: ','Reporting period: ')+(period||decodeURIComponent(selected.url.split('/').pop()))));
          host.append(node('p',txt('این جدول، تابعیت اعلام‌شده هنگام ورود دریایی را نشان می‌دهد؛ کشور محل سوارشدن به قایق یا کل مهاجران مقیم ایتالیا را نشان نمی‌دهد.','Declared nationality at sea arrival, not boat departure country or total resident migrants.')));
          if(rows.length){const total=rows.find(r=>r.name==='Totale');if(total)host.append(node('h4',txt('مجموع ورود دریایی: ','Total sea arrivals: ')+number(total.count)));host.append(table(rows));}
          else host.append(node('p',txt('جدول عددی قابل استخراج نبود؛ آمار و تابعیت‌ها را در گزارش زیر ببینید.','The table could not be extracted; see arrivals and nationalities in the report below.')));
          await pdfViewer(pdf,host,selected.url,generation,Math.min(4,pdf.numPages));
        }else{
          host.append(node('h4',selected.title),node('p',txt('گزارش رسمی شامل ورودها، متقاضیان پناهندگی، ظرفیت و جمعیت مراکز است. از انتخاب صفحه برای دیدن جدول‌ها و نمودارها استفاده کنید. آمار ورود با تعداد مهاجران مقیم متفاوت است.','Official report of arrivals, asylum applicants and reception populations. Select a page for tables and charts; arrivals differ from resident population.')));
          const legal=linksFrom(html,source.stats).filter(a=>/\.pdf$/i.test(a.url)&&/Νόμιμη Μετανάστευση/i.test(a.title)&&!/Παράρτημα/i.test(a.title)).sort((a,b)=>b.url.localeCompare(a.url));if(legal.length)host.append(link(txt('گزارش مهاجرت قانونی و اقامت','Legal migration and residence report')+' — '+legal[0].title,legal[0].url));
          await pdfViewer(pdf,host,selected.url,generation,Math.min(2,pdf.numPages));
        }
      }
      if(generation===statsGeneration){lastStats[key]=Date.now();status.textContent=fetchedLabel()+txt(' — تاریخ آمار در گزارش منبع درج شده است.',' — Data period is shown in the source report.');}
    }catch(e){if(generation===statsGeneration){host.replaceChildren();status.textContent=txt('دریافت آمار ناموفق بود. دوباره تلاش کنید یا منبع رسمی را باز کنید.','Statistics unavailable. Retry or open the official source.');}}
    finally{if(generation===statsGeneration)$('regionStatsBtn').disabled=false;}
  }
  function urlDate(value){const months=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];const m=value.match(/\/(20\d{2})\/(\d{2}|[a-z]{3})\/(\d{2})\//);return m?m[1]+'-'+(/^\d/.test(m[2])?m[2]:String(months.indexOf(m[2])+1).padStart(2,'0'))+'-'+m[3]:'';}
  function dateFrom(text){const m=text.match(/\b(\d{1,2})[.\/-](\d{1,2})[.\/-]((?:20)?\d{2})\b/);return m?(m[3].length===2?'20'+m[3]:m[3])+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0'):'';}
  function parseNews(html,source,kind,key){
    const doc=new DOMParser().parseFromString(html,kind==='rss'?'text/xml':'text/html');let articles=[];
    if(kind==='rss')articles=Array.from(doc.querySelectorAll('item')).map(it=>({title:it.querySelector('title')?.textContent||'',desc:it.querySelector('description')?.textContent||'',link:safeUrl(it.querySelector('link')?.textContent,source),published:it.querySelector('pubDate')?.textContent||it.getElementsByTagName('dc:date')[0]?.textContent||''}));
    else if(kind==='cards')articles=Array.from(doc.querySelectorAll('a.news-card-horizontal')).map(a=>({title:a.querySelector('.card-title')?.textContent.trim()||'',desc:a.querySelector('.card-text')?.textContent.trim()||'',link:safeUrl(a.getAttribute('href'),source),published:dateFrom(a.textContent)}));
    else articles=Array.from(doc.querySelectorAll('a[href]')).map(a=>({title:a.textContent.replace(/\s+/g,' ').trim(),desc:'',link:safeUrl(a.getAttribute('href'),source),published:dateFrom(a.textContent)||dateFrom(a.closest('.ipost,article,.entry')?.textContent||'')||urlDate(a.getAttribute('href')||'')||dateFrom(a.getAttribute('href')||'')}));
    const patterns={it:/migrant|refugee|asylum|immigra|sbarch|naufrag|rifugiat|accoglienza|لامپدوسا|مهاجر|پناه/i,tr:/göç|goc|gocmen|göçmen|sınır dışı|sinir-disi|migrant|refugee|asylum|پناه|مهاجر/i,gr:/μεταναστ|παράνομ.*(?:αλλοδαπ|είσοδ)|εντοπισμ.*αλλοδαπ|διακινητ|migrant|refugee|asylum|پناه|مهاجر/i};
    return articles.filter(a=>a.title.length>15&&a.link&&patterns[key].test(a.title+' '+a.desc+' '+decodeURIComponent(a.link))).filter(a=>(kind!=='rss'&&kind!=='archive')||(kind==='archive'&&/(?:theguardian\.com\/world\/(?:italy|turkey|greece)$|greekreporter\.com\/society\/immigration)/.test(source))||(key==='it'&&/sicilia_rss/.test(source))||new RegExp(key==='it'?'Italy|Italian|Lampedusa|Sicily|Sicilia|Italia|ایتالیا':key==='tr'?'Turkey|Turkish|Türkiye|Aegean|ترکیه':'Greece|Greek|یونان','i').test(a.title+' '+a.desc));
  }
  let newsItems=[],newsIndex=0,newsFilter='all';
  function category(a){const t=a.title+' '+a.desc;return /arrest|detain|apprehen|yakalan|sınır dışı|συλλ|συνελή|بازداشت|دستگیر/i.test(t)?'arrests':/rescu|save|soccors|kurtar|διάσω|نجات/i.test(t)?'rescue':/camp|centre|center|reception|accoglien|merkez|δομή|κέντρ|مرکز/i.test(t)?'centres':'policy';}
  function renderCurrentNews(){
    const filtered=newsItems.filter(a=>newsFilter==='all'||category(a)===newsFilter);newsIndex=Math.max(0,Math.min(newsIndex,filtered.length-1));
    const host=$('regionNewsContent');host.replaceChildren();$('regionNewsPrev').disabled=newsIndex===0||!filtered.length;$('regionNewsNext').disabled=newsIndex>=filtered.length-1;
    $('regionNewsPosition').textContent=filtered.length?number(newsIndex+1)+' / '+number(filtered.length):txt('خبری در این دسته نیست.','No reports in this category.');
    if(!filtered.length)return;
    const a=filtered[newsIndex],card=node('article',null,'migrant-news-card'),generation=newsGeneration,index=newsIndex,filter=newsFilter;
    const date=a.published&&Date.parse(a.published)?new Date(a.published).toLocaleDateString(fa()?'fa-IR':'en-GB'):txt('تاریخ انتشار در منبع','Publication date at source');
    const plain=parsePage(a.desc||'').body.textContent.replace(/\s+/g,' ').trim().slice(0,220);
    card.append(node('div',a.source+' • '+date,'src'),link(a.title,a.link));if(plain)card.append(node('p',plain,'dsc'));
    card.append(link(txt('خواندن خبر کامل در منبع','Read full report at source'),a.link));
    const translation=node('p',null,'dsc');card.append(translation);host.append(card);
    if(fa()&&!/[\u0600-\u06ff]/.test(a.title)){
      translation.textContent=txt('در حال ترجمهٔ تیتر و گزیده…','Translating headline and excerpt…');
      const original=a.title+(plain?' — '+plain:'');
      Promise.resolve(a.translation||api.translate(original)).then(text=>{a.translation=text;if(generation===newsGeneration&&index===newsIndex&&filter===newsFilter&&card.isConnected)translation.textContent=text?txt('ترجمهٔ ماشینی تیتر و گزیده: ','Machine-translated headline and excerpt: ')+text:txt('ترجمه در دسترس نیست.','Translation unavailable.');}).catch(()=>{if(card.isConnected)translation.textContent=txt('ترجمه در دسترس نیست.','Translation unavailable.');});
    }
  }
  async function refreshNews(){
    const key=country(),generation=++newsGeneration,status=$('regionNewsStatus');$('regionNewsBtn').disabled=true;newsItems=[];newsIndex=0;renderCurrentNews();status.textContent=txt('در حال دریافت اخبار…','Loading news…');
    const sources=SOURCES[key].news;
    $('regionNewsSources').replaceChildren();sources.forEach(([name,url])=>$('regionNewsSources').append(link(name,url),document.createTextNode(' · ')));
    const results=await Promise.allSettled(sources.map(async([name,url,kind])=>parseNews(await api.fetchText(url),url,kind,key).map(a=>Object.assign(a,{source:name}))));
    if(generation!==newsGeneration)return;
    const seen=new Set();newsItems=results.filter(r=>r.status==='fulfilled').flatMap(r=>r.value).filter(a=>{const id=a.title.trim().toLowerCase();if(seen.has(id)||Date.parse(a.published)>Date.now()+86400000)return false;seen.add(id);return true;}).sort((a,b)=>(Date.parse(b.published)||0)-(Date.parse(a.published)||0)).slice(0,60);
    if(!newsItems.length)status.textContent=txt('خبر مرتبطی دریافت نشد؛ منابع زیر را باز کنید یا دوباره تلاش کنید.','No relevant reports received; open the sources below or retry.');
    else{lastNews[key]=Date.now();status.textContent=fetchedLabel()+' • '+number(newsItems.length)+txt(' خبر',' reports');}
    const unavailable=results.map((r,i)=>r.status==='rejected'||!r.value.length?sources[i][0]:'').filter(Boolean);
    if(unavailable.length)status.textContent+=txt(' — بدون خبر مرتبط یا دریافت ناموفق: ',' — No matching reports or unavailable: ')+unavailable.join('، ');
    renderCurrentNews();$('regionNewsBtn').disabled=false;
  }
  const EXTRA_URLS={
    itAsylum:'https://asylumineurope.org/reports/country/italy/statistics/',
    itReception:'https://asylumineurope.org/reports/country/italy/reception-conditions/housing/types-accommodation/',
    unhcr:'https://data.unhcr.org/en/situations/europe-sea-arrivals',
    trCoast:'https://www.sg.gov.tr/duzensiz-goc-istatistikleri',
    trCentres:'https://www.goc.gov.tr/geri-gonderme-merkezleri-iletisim',
    trReception:'https://asylumineurope.org/reports/country/turkiye/reception-conditions/housing/types-accommodation/',
    trTemporary:'https://asylumineurope.org/reports/country/turkiye/content-temporary-protection/housing/',
    grCentres:'https://migration.gov.gr/en/ris/perifereiakes-monades/domes/',
    grRIC:'https://migration.gov.gr/en/ris/perifereiakes-monades/kyt-domes/',
    grDetention:'https://asylumineurope.org/reports/country/greece/detention-asylum-seekers/general/'
  };
  let extraGeneration=0;
  function rowsOf(table){return Array.from(table.querySelectorAll('tr')).map(r=>Array.from(r.querySelectorAll('th,td')).map(c=>c.textContent.replace(/\s+/g,' ').trim()));}
  function dynamicTables(html){return Array.from(parsePage(html).querySelectorAll('.icerik .custom-table')).map(t=>{const rows=Array.from(t.querySelectorAll('.custom-table-row')).map(r=>Array.from(r.querySelectorAll('.custom-table-cell')).map(c=>c.textContent.trim()));const first=t.querySelector('.custom-table-row');return {headers:first?Array.from(first.children).map(c=>c.getAttribute('data-header')||''):[],rows};});}
  const LABELS={'Aylar':'ماه','Ocak':'ژانویه','Şubat':'فوریه','Mart':'مارس','Nisan':'آوریل','Mayıs':'مه','Haziran':'ژوئن','Temmuz':'ژوئیه','Ağustos':'اوت','Eylül':'سپتامبر','Ekim':'اکتبر','Toplam**':'مجموع گزارش','Total':'مجموع','Hotspots':'مراکز ورود اولیه','Governmental centres':'مراکز دولتی','Refugee status':'وضعیت پناهندگی','Subsidiary protection':'حمایت فرعی','Special protection* (4)':'حمایت ویژه','Total number of asylum seekers detained in PRDCs':'تعداد پناهجویان بازداشت‌شده در مراکز پیش از اخراج در طول سال','Total number of persons detained in PRDCs':'تعداد کل افراد بازداشت‌شده در مراکز پیش از اخراج در طول سال','Geri Gönderme Merkezi':'مرکز بازگرداندن','Telefon':'تلفن','Adres':'نشانی'};
  function translateCell(s){if(!fa())return s;if(LABELS[s])return LABELS[s];return s.replace(/Applicants in (\d{4}) \(1\)/,'متقاضیان در $1 (۱)').replace(/Pending applications at the end of (\d{4})\[1\]/,'درخواست‌های در انتظار در پایان $1').replace(/Total decisions in (\d{4}) \(2\)/,'کل تصمیم‌های مرحلهٔ اول در $1 (۲)').replace(/Total rejection \(3\)/,'کل رد درخواست (۳)').replace(/Special protection/,'حمایت ویژه').replace(/Administrative detention: /,'بازداشت اداری: ').replace(/Occupancy of the reception system: /,'تعداد افراد ساکن سیستم پذیرش: ');}
  function dataTable(rows){const wrap=node('div',null,'region-table-scroll'),t=node('table',null,'migrant-region-table');rows.forEach((r,i)=>{const tr=node('tr');r.forEach(c=>tr.append(node(i===0?'th':'td',translateCell(c))));t.append(tr);});wrap.append(t);return wrap;}
  function section(title,url){const box=node('section',null,'region-extra-card');box.append(node('h4',title),link(txt('منبع و گزارش اصلی','Source and original report'),url));return box;}
  function docPeriod(doc){const p=Array.from(doc.querySelectorAll('p')).find(p=>/Last updated:/.test(p.textContent));return p?p.textContent.trim():txt('دورهٔ آمار در عنوان جدول درج شده است.','Data period appears in the table heading.');}
  function uniqueNames(names){return [...new Set(names.map(x=>x.trim()).filter(Boolean))];}
  function centreNames(html,key){const d=parsePage(html);if(key==='tr')return uniqueNames(dynamicTables(html).flatMap(t=>t.rows.filter(r=>r.length===3).map(r=>r[0])));if(key==='gr')return uniqueNames(Array.from(d.querySelectorAll('h2,h3,h4,h5')).map(x=>x.textContent.trim()).filter(x=>/^Controlled Access Facility for Temporary Accommodation of Asylum Seekers /.test(x)).map(x=>x.replace(/^Controlled Access Facility for Temporary Accommodation of Asylum Seekers /,'')));return uniqueNames(Array.from(d.querySelectorAll('.elementor-tab-title')).map(x=>x.textContent.trim()).filter(x=>/^(?:RIC|CCAC|CAFTAAS)\b/.test(x)));}
  function latestUnhcrItaly(html){return linksFrom(html,EXTRA_URLS.unhcr).filter(a=>/Italy (?:monthly sea arrivals update|Sea Arrivals Dashboard)/i.test(a.title)&&/\/documents\/details\/\d+/.test(a.url)).sort((a,b)=>Number(b.url.match(/\d+$/)[0])-Number(a.url.match(/\d+$/)[0]))[0];}
  async function refreshExtraStats(){
    const key=country(),generation=++extraGeneration,host=$('regionExtraStats');extraPdfs.forEach(p=>p.destroy());extraPdfs=[];host.replaceChildren();
    const jobs=key==='it'?[
      [txt('درخواست پناهندگی و تصمیم‌ها — گزارش سالانه','Asylum applications and decisions — annual report'),EXTRA_URLS.itAsylum,'itAsylum'],
      [txt('مراکز و جمعیت پذیرش — گزارش سالانه','Reception centres and population — annual report'),EXTRA_URLS.itReception,'itReception'],
      [txt('کشور حرکت قایق‌ها و مسیرها — UNHCR','Boat departure countries and routes — UNHCR'),EXTRA_URLS.unhcr,'unhcr']
    ]:key==='tr'?[
      [txt('شناسایی و بازداشت گارد ساحلی — مقایسهٔ سالانه و ماهانه','Coast Guard apprehensions — annual and monthly comparison'),EXTRA_URLS.trCoast,'trCoast'],
      [txt('مراکز بازگرداندن ترکیه','Türkiye removal centres'),EXTRA_URLS.trCentres,'trCentres'],
      [txt('پذیرش و اسکان متقاضیان حمایت بین‌المللی','Reception and accommodation for international protection applicants'),EXTRA_URLS.trReception,'trReception'],
      [txt('اردوگاه‌های اسکان حمایت موقت — گزارش با دورهٔ مشخص','Temporary-protection accommodation camps — dated report'),EXTRA_URLS.trTemporary,'trTemporary']
    ]:[
      [txt('بازداشت اداری در مراکز پیش از اخراج — گزارش سالانه','Administrative detention in pre-removal centres — annual report'),EXTRA_URLS.grDetention,'grDetention'],
      [txt('مراکز پذیرش موقت یونان','Greece temporary reception facilities'),EXTRA_URLS.grCentres,'grCentres'],
      [txt('مراکز ثبت اولیه و مراکز بستهٔ یونان','Greece reception/identification and closed centres'),EXTRA_URLS.grRIC,'grRIC']
    ];
    await Promise.all(jobs.map(async([title,url,type])=>{
      const box=section(title,url),status=node('p',txt('در حال دریافت…','Loading…'));box.append(status);host.append(box);
      try{
        const html=await api.fetchText(url);if(generation!==extraGeneration)return;const d=parsePage(html);
        if(type==='itAsylum'){
          const tables=Array.from(d.querySelectorAll('table')).filter(t=>/Applicants in|Overall protection rate/.test(t.textContent));if(!tables.length)throw new Error('No asylum tables');
          box.append(node('p',txt('آمار سالانه، نه آمار امروز. تعداد متقاضیان، تصمیم‌ها و درصد پذیرش، معیارهای جداگانه‌اند؛ یادداشت‌ها و تعریف‌های جدول را در منبع بخوانید.','Annual data, not today’s figures. Applications, decisions and protection rates are separate measures; see source definitions and notes.')));
          tables.slice(0,2).forEach(t=>box.append(dataTable(rowsOf(t))));
        }else if(type==='itReception'){
          const tables=Array.from(d.querySelectorAll('table'));const occ=tables.find(t=>/Occupancy of the reception system/.test(t.textContent));if(!occ)throw new Error('Reception table unavailable');box.append(dataTable(rowsOf(occ)));
          const text=(d.querySelector('main')||d.body).textContent.replace(/\s+/g,' ');const m=text.match(/(?:end of|end-) (20\d{2}).{0,25}?(\d+) hotspots were operating/i);if(m)box.append(node('p',txt('تعداد مراکز ورود اولیه در پایان ','Hotspot centres at the end of ')+m[1]+': '+number(m[2])));
          if(/did not communicate the number of facilities/i.test(text))box.append(node('p',txt('تعداد کل همهٔ مراکز در گزارش اخیر اعلام نشده؛ تعداد ساکنان با تعداد مراکز متفاوت است.','The recent report does not disclose the total number of all facilities; residents and facilities are different counts.')));
        }else if(type==='unhcr'){
          const selected=latestUnhcrItaly(html);if(!selected)throw new Error('UNHCR report unavailable');box.append(node('h5',selected.title),node('p',txt('تابعیت افراد با کشور حرکت قایق متفاوت است. گزارش ماهانهٔ زیر کشورهای حرکت، تعداد ورودها و مسیرها را نشان می‌دهد.','Nationality differs from boat departure country. This monthly report shows departure countries, arrivals and routes.')));
          const download=selected.url.replace('/details/','/download/'),pdf=await loadPdf(download);if(generation!==extraGeneration){pdf.destroy();return;}
          extraPdfs.push(pdf);
          if(pdf.numPages>=2){const content=await (await pdf.getPage(2)).getTextContent();const left=content.items.filter(i=>i.transform[4]<300).sort((a,b)=>b.transform[5]-a.transform[5]||a.transform[4]-b.transform[4]).map(i=>i.str).join(' ').replace(/\s+/g,' ');const start=left.indexOf('Country of embarkation'),end=left.indexOf('Sea arrivals by country',start);const paragraph=left.slice(start,end>start?end:start+600);const rows=[];for(const[name,persian]of [['Libya','لیبی'],['Algeria','الجزایر'],['Tunisia','تونس'],['Türkiye','ترکیه']]){const pattern=new RegExp(name+'[^0-9]{0,120}(\\d{1,3})\\s*per cent','i'),m=paragraph.match(pattern);if(m)rows.push([fa()?persian:name,m[1]+'%']);}if(generation!==extraGeneration)return;if(rows.length)box.append(node('h5',txt('سهم کشورهای حرکت در ماه گزارش','Departure-country shares in the report month')),dataTable([[txt('کشور حرکت','Departure country'),txt('درصد','Share')],...rows]),node('p',txt('درصدهای گرد‌شده ممکن است دقیقاً ۱۰۰ نشوند. دورهٔ این جدول همان ماه عنوان گزارش است.','Rounded percentages may not sum to 100. This table covers the month in the report title.')));}
          await pdfViewer(pdf,box,download,statsGeneration,Math.min(2,pdf.numPages));
        }else if(type==='trReception'||type==='trTemporary'){
          const paragraphs=Array.from(d.querySelectorAll('p')).map(p=>p.textContent.replace(/\s+/g,' ').trim());
          const selected=paragraphs.find(p=>type==='trReception'?/only one remaining Reception and Accommodation Centre/i.test(p):/As of 20\d{2}.*large-scale camps.*total of/i.test(p));
          if(!selected)throw new Error('Accommodation figures unavailable');
          const update=(d.body.textContent.match(/Last updated:\s*\d{2}\/\d{2}\/\d{2,4}/)||[])[0];if(update)box.append(node('p',update));
          const words={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
          if(type==='trReception'){const capacity=selected.match(/capacity of ([\d,]+) places/i);if(capacity)box.append(dataTable([[txt('نوع','Type'),txt('تعداد مراکز طبق گزارش','Centres according to the report'),txt('ظرفیت نفر','Capacity (places)')],[txt('مرکز پذیرش حمایت بین‌المللی — یوزگات','International-protection reception centre — Yozgat'),'1',capacity[1]]]));}
          else{const m=selected.match(/As of (20\d{2}),?\s+(\w+) large-scale camps.*?total of ([\d,]+)/i);if(m&&(words[m[2].toLowerCase()]||/^\d+$/.test(m[2])))box.append(dataTable([[txt('سال آمار','Data year'),txt('تعداد اردوگاه‌های اسکان موقت','Temporary accommodation camps'),txt('افراد ساکن','Residents')],[m[1],String(words[m[2].toLowerCase()]||Number(m[2])),m[3]]]));}
          box.append(node('p',txt('این داده از گزارش دوره‌ای AIDA است؛ به‌روزرسانی صفحه به معنی آمار روز نیست. مراکز پذیرش حمایت بین‌المللی، اردوگاه‌های حمایت موقت و مراکز بازگرداندن سه دستهٔ متفاوت‌اند.','This is a periodic AIDA report, not live daily data. International-protection reception, temporary-protection camps and removal centres are separate categories.')));
        }else if(type==='trCoast'){
          const tables=dynamicTables(html);if(tables.length<4)throw new Error('Coast Guard tables unavailable');
          const content=d.querySelector('.icerik')?.textContent.replace(/\s+/g,' ')||'';const date=content.match(/Veriler\s+(.{1,40}?)\s+tarihine/);if(date)box.append(node('p',txt('دورهٔ منبع تا: ','Source data through: ')+date[1]));
          box.append(node('p',txt('این ارقام عملیات گارد ساحلی هستند، نه کل بازداشت‌های ترکیه. بازداشت/شناسایی مهاجر، نجات و بازداشت قاچاقچی متفاوت‌اند؛ ردیف‌های روزانه و ماهانه را جمع نزنید.','These cover Coast Guard operations, not all Türkiye arrests. Apprehension, rescue and smuggler arrests are different; do not sum daily and monthly rows.')));
          [[1,txt('مهاجران شناسایی‌شده توسط گارد ساحلی','Migrants apprehended by the Coast Guard')],[3,txt('افراد بازداشت‌شده به اتهام سازمان‌دهی قاچاق','Alleged migrant-smuggling organisers apprehended')]].forEach(([i,label])=>{box.append(node('h5',label),dataTable([tables[i].headers,...tables[i].rows]));});
        }else if(type==='grDetention'){
          const t=Array.from(d.querySelectorAll('table')).find(t=>/Administrative detention:/.test(t.textContent));if(!t)throw new Error('Detention table unavailable');box.append(dataTable(rowsOf(t)),node('p',txt('تعداد افرادی که در طول هر سال وارد بازداشت اداری مراکز پیش از اخراج شده‌اند؛ نه تعداد بازداشت‌شدگان امروز یا کل دستگیری‌های پلیس.','Persons held in administrative pre-removal detention during each year, not today’s detainees or all police arrests.')));
        }else{
          const names=centreNames(html,type==='trCentres'?'tr':type==='grCentres'?'gr':'ric');if(!names.length)throw new Error('Centre directory unavailable');
          box.append(node('h5',txt('تعداد نام‌های درج‌شده در فهرست منبع: ','Named entries in the source directory: ')+number(names.length)),node('p',txt('این شمارشِ فهرست وب‌سایت است؛ تأیید فعال‌بودن همهٔ مراکز نیست. مراکز بازگرداندن/بسته با اقامتگاه پذیرش موقت متفاوت‌اند. تاریخ دریافت، تاریخ افتتاح یا ظرفیت مرکز نیست.','This counts directory entries; it does not confirm that every centre is operating. Removal/closed centres differ from temporary reception. Retrieval date is not opening date or capacity.')));
          const details=node('details'),summary=node('summary',txt('نمایش نام مراکز','Show centre names')),list=node('ul');names.forEach(n=>list.append(node('li',n)));details.append(summary,list);box.append(details);
        }
        if(generation===extraGeneration)status.textContent=fetchedLabel()+' — '+docPeriod(d);
      }catch(e){if(generation===extraGeneration)status.textContent=txt('دریافت این منبع ناموفق بود؛ آمار صفر محسوب نمی‌شود. لینک منبع را باز کنید یا دوباره بروزرسانی کنید.','This source could not be loaded; this does not mean zero. Open the source or refresh again.');}
    }));
  }
  function italianComparison(lines){return lines.map(l=>l.match(/^(20\d{2})\s+(\d[\d.]*)$/)).filter(Boolean).map(m=>[m[1],number(Number(m[2].replace(/\./g,'')))]);}
  function italianMonths(lines){return lines.map(l=>l.match(/^(20\d{2})\s+((?:\d[\d.]*\s*){6,12})$/)).filter(Boolean).map(m=>[m[1],...m[2].trim().split(/\s+/).map(n=>number(Number(n.replace(/\./g,''))))]);}
  async function renderItalianOverview(pdf,host,generation){
    const first=await pdfLines(pdf,1);if(generation!==statsGeneration)return;const comparison=italianComparison(first);if(comparison.length>=2){host.append(node('h4',txt('ورود دریایی — مقایسهٔ دورهٔ مشابه','Sea arrivals — same-period comparison')),node('p',first.find(l=>/dal 1/.test(l))||''),dataTable([[txt('سال','Year'),txt('ورود دریایی','Sea arrivals')],...comparison]));}
    if(pdf.numPages>=2){const lines=await pdfLines(pdf,2);if(generation!==statsGeneration)return;const yearRow=lines.find(l=>/^(?:20\d{2}\s+){3,}/.test(l));if(yearRow){const index=lines.indexOf(yearRow),values=lines[index+1]?.split(/\s+/),years=yearRow.split(/\s+/);if(values?.length===years.length&&values.every(v=>/^\d[\d.]*$/.test(v)))host.append(node('h4',txt('کل ورود دریایی سال‌های کامل','Full-year sea arrivals')),dataTable([[txt('سال','Year'),txt('کل ورود','Total arrivals')],...years.map((y,i)=>[y,number(Number(values[i].replace(/\./g,'')))])]));}}
    if(pdf.numPages>=3){const rows=italianMonths(await pdfLines(pdf,3));if(generation!==statsGeneration)return;if(rows.length)host.append(node('h4',txt('ورود دریایی ماهانه','Monthly sea arrivals')),node('p',txt('خانهٔ خالی یعنی رقمی در این جدول منتشر نشده است؛ صفر نیست.','Blank cells mean no value is published in this table, not zero.')),dataTable([[txt('سال','Year'),'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],...rows]));}
  }

  function selectCountry(){
    const source=SOURCES[country()];$('regionStatsTypeLabel').hidden=country()!=='tr';$('regionSources').replaceChildren();source.links.forEach(([label,url])=>{$('regionSources').append(link(label,url),document.createTextNode(' · '));});
    $('regionScope').textContent=txt('آمار ورود، بازداشت، اقامت و پناهندگی معیارهای متفاوتی هستند. تاریخ آمار ممکن است از امروز عقب‌تر باشد؛ تاریخ دریافت به معنی تاریخ آمار نیست.','Arrivals, apprehensions, residence and asylum measure different things. Retrieval time is not the data reporting date.');
    $('regionNewsHeading').textContent=country()==='it'?txt('📰 اخبار مهاجرت ایتالیا','📰 Italy migration news'):txt('📰 اخبار بازداشت، کنترل مهاجرت و نجات — ','📰 Apprehensions, migration controls and rescues — ')+source.name[fa()?0:1];
    refreshStats();refreshNews();refreshExtraStats();
  }
  window.MigrantRegion={open(options){api=options;if(!wired){wired=true;$('regionStatsType').addEventListener('change',refreshStats);$('regionCountry').addEventListener('change',selectCountry);$('regionStatsBtn').addEventListener('click',()=>{refreshStats();refreshExtraStats();});$('regionNewsNext').addEventListener('click',()=>{newsIndex++;renderCurrentNews();});$('regionNewsPrev').addEventListener('click',()=>{newsIndex--;renderCurrentNews();});$('regionNewsFilter').addEventListener('change',()=>{newsFilter=$('regionNewsFilter').value;newsIndex=0;renderCurrentNews();});$('regionNewsBtn').addEventListener('click',refreshNews);selectCountry();}else{const key=country();if(!lastStats[key]||Date.now()-lastStats[key]>300000){refreshStats();refreshExtraStats();}if(!lastNews[key]||Date.now()-lastNews[key]>300000)refreshNews();}},
    // Pure parsers are exposed for source-format regression checks.
    parsers:{latestItalianReport,latestGreekReport,turkishCharts,italianNationalities,parseNews,chartDate,dynamicTables,centreNames,latestUnhcrItaly,italianComparison,italianMonths,category},sources:SOURCES};
})();
