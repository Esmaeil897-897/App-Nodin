/* Shared, dated headline cache and bounded English-to-Persian translation. */
(function(){
 'use strict';
 const CACHE='nodin:headlines:v1',TRANS='nodin:headline-translations:v1';
 function read(k){try{return JSON.parse(localStorage.getItem(k)||'{}');}catch(e){return {};}}
 function safe(u){try{const a=new URL(u);return /^https?:$/.test(a.protocol)&&!a.username&&!a.password?a.href:'';}catch(e){return '';}}
 function plain(s){return String(s||'').replace(/\s+/g,' ').trim();}
 function clean(a){return {title:plain(a.title).slice(0,500),desc:plain(a.desc).slice(0,260),link:safe(a.link),published:plain(a.published),source:plain(a.source),feedUrl:safe(a.feedUrl),translation:plain(a.translation),tags:plain(a.tags)};}
 function normalize(items){const seen=new Set();return items.map(clean).filter(a=>{const id=a.title.toLowerCase();if(!id||seen.has(id)||Date.parse(a.published)>Date.now()+86400000)return false;seen.add(id);return true;}).sort((a,b)=>(Date.parse(b.published)||0)-(Date.parse(a.published)||0)).slice(0,120);}
 function cached(k){const c=read(CACHE)[k];return c&&Array.isArray(c.items)?{items:normalize(c.items),fetched:c.fetched}:null;}
 function save(k,items){const c=read(CACHE);c[k]={items:normalize(items),fetched:Date.now()};try{localStorage.setItem(CACHE,JSON.stringify(c));}catch(e){}}
 function filtered(items,v){if(v==='all')return items;return items.filter(a=>{const t=a.title+' '+a.desc+' '+a.tags+' '+a.source;if(v==='ps')return /PlayStation|\bPS[45]\b|PSVR|State of Play/i.test(t);if(v==='xbox')return /Xbox|Game Pass|Microsoft Gaming/i.test(t);if(v==='pc')return /PC Gamer|\bPC\b|Steam|Epic Games|Windows/i.test(t);return /announc|launch|release|reveal|showcase|State of Play|Game Pass|PlayStation Plus|update|trailer/i.test(a.title);});}
 function chunks(s){const out=[];let current='';for(const c of s){if(new TextEncoder().encode(current+c).length>450){out.push(current);current='';}current+=c;}if(current)out.push(current);return out;}
 let queue=Promise.resolve();const active=new Map();
 function translate(s){s=plain(s);if(!s)return Promise.resolve('');const saved=read(TRANS);if(saved[s])return Promise.resolve(saved[s]);if(active.has(s))return active.get(s);const p=queue.then(async()=>{const result=[];for(const q of chunks(s)){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);try{const r=await fetch('https://api.mymemory.translated.net/get?q='+encodeURIComponent(q)+'&langpair=en%7Cfa',{signal:controller.signal});if(!r.ok)throw Error();const d=await r.json(),t=plain(d.responseData?.translatedText);if(Number(d.responseStatus)!==200||!/[\u0600-\u06ff]/.test(t)||/MYMEMORY WARNING|QUOTA|INVALID LANGUAGE/i.test(t))throw Error();result.push(t);}finally{clearTimeout(timer);}}const text=result.join(' '),c=read(TRANS);c[s]=text;Object.keys(c).slice(0,Math.max(0,Object.keys(c).length-350)).forEach(k=>delete c[k]);try{localStorage.setItem(TRANS,JSON.stringify(c));}catch(e){}return text;});queue=p.catch(()=>{});active.set(s,p);p.finally(()=>active.delete(s)).catch(()=>{});return p;}
 window.HeadlineSupport={safe,normalize,cached,save,filtered,translate,chunks};
})();
