(function(){
 'use strict';
 const $=id=>document.getElementById(id),countries={uk:'بریتانیا',it:'ایتالیا',gr:'یونان',tr:'ترکیه'};
 window.NodinMigrationNotifications={
  cache(country,items){if(window.NodinNative&&countries[country])NodinNative.postMessage(JSON.stringify({cmd:'migrationStories',country,items:items.slice(0,30).map(a=>Object.fromEntries(['title','desc','link','source','published'].map(k=>[k,String(a[k]||'').slice(0,k==='desc'?500:600)])))}));},
  open(item){
   if(!countries[item.country])return;
   document.querySelector('.tab[data-tab="news"]')?.click();
   document.querySelector('[data-nsub="migrant"]')?.click();
   document.querySelector('[data-msub="'+(item.country==='uk'?'news':'region')+'"]')?.click();
   if(item.country!=='uk'){
    $('regionCountry').value=item.country;
    $('regionCountry').dispatchEvent(new Event('change',{bubbles:true}));
    window.RegionHub?.view('news');
   }
   // Keep the exact selected article visible even when the live feed refreshes.
   let card=$('migrationNotificationStory');if(card)card.remove();
   card=document.createElement('article');card.id='migrationNotificationStory';card.className='migrant-news-card';card.style.fontSize='calc(var(--font-size-base,16px) + 2px)';
   for(const [tag,text] of [['small','خبرِ اعلان • '+countries[item.country]+' • '+(item.source||'')],['h3',item.displayTitle||item.title],['p',item.displayBody||item.desc],['p',item.title]]){const e=document.createElement(tag);e.textContent=text||'';card.append(e);}
   try{const u=new URL(item.link);if(u.protocol==='https:'&&!u.username&&!u.password){const link=document.createElement('a');link.href=u.href;link.rel='noopener';link.target='_blank';link.textContent='خواندن خبر کامل از منبع';card.append(link);}}catch(e){}
   const close=document.createElement('button');close.type='button';close.textContent='بستن خبر اعلان';close.onclick=()=>card.remove();card.append(close);
   const host=item.country==='uk'?$('migrantSub-news'):$('rhPane-news');host?.prepend(card);
   card.scrollIntoView?.({block:'nearest'});
  }
 };
 function init(){
  const native=!!window.NodinNative;
  function countryState(){$('dailyNewsCountry').disabled=$('dailyNewsCategory').value!=='migration';}
  function send(cmd,enabled){countryState();if(native)NodinNative.postMessage(JSON.stringify({cmd,enabled,category:$('dailyNewsCategory').value,country:$('dailyNewsCountry').value,language:$('dailyNewsLanguage').value}));}
  window.onDailyNewsState=s=>{
   $('dailyNewsCategory').value=s.category;$('dailyNewsCountry').value=s.country||'all';$('dailyNewsLanguage').value=s.language||'fa';countryState();
   $('dailyNewsStatus').textContent=s.enabled?(s.permitted?'اعلان اخبار فعال است.':'اعلان انتخاب شده است؛ اجازهٔ نمایش در تنظیمات گوشی غیرفعال است.'):'اعلان اخبار خاموش است.';
  };
  $('dailyNewsEnable').onclick=()=>send('newsEnable',true);$('dailyNewsDisable').onclick=()=>send('newsEnable',false);$('dailyNewsSystem').onclick=()=>send('newsSystemSettings');$('dailyNewsTest').onclick=()=>send('newsPreview');
  ['dailyNewsCategory','dailyNewsCountry','dailyNewsLanguage'].forEach(k=>$(k).onchange=()=>send('newsCategory'));
  countryState();
  if(!native){$('dailyNewsStatus').textContent='اعلانِ پس‌زمینه در نسخهٔ اندروید فعال می‌شود. انتخاب‌ها در این پیش‌نمایش برای بررسی ظاهر هستند.';['dailyNewsEnable','dailyNewsDisable','dailyNewsSystem','dailyNewsTest'].forEach(k=>$(k).disabled=true);}else send('newsStatus');
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
