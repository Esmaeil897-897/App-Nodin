/* Keep the UK migrant news reader usable on a small screen. */
(function(){
 'use strict';
 function wire(){
  const host=document.getElementById('migrantNewsList');if(!host)return;
  const toolbar=document.createElement('div');toolbar.className='fetch-row region-news-controls';
  const prev=document.createElement('button'),next=document.createElement('button'),position=document.createElement('span');prev.type=next.type='button';prev.textContent='خبر قبلی';next.textContent='رد شدن / خبر بعدی';position.setAttribute('role','status');position.setAttribute('aria-live','polite');toolbar.append(prev,position,next);host.before(toolbar);
  let index=0;
  function render(){const cards=Array.from(host.children).filter(c=>c.classList.contains('migrant-news-card'));index=Math.max(0,Math.min(index,cards.length-1));cards.forEach((c,i)=>{c.hidden=i!==index;c.style.display=i===index?'':'none';if(i===index)c.dispatchEvent(new CustomEvent('nodin:article-visible'));});toolbar.hidden=!cards.length;prev.disabled=index===0;next.disabled=index>=cards.length-1;position.textContent=cards.length?(index+1)+' / '+cards.length:'';}
  prev.addEventListener('click',()=>{index--;render();});next.addEventListener('click',()=>{index++;render();});
  new MutationObserver(()=>{index=0;render();}).observe(host,{childList:true});render();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wire,{once:true});else wire();
})();
