package com.nodin.english;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry;
import androidx.test.runner.lifecycle.Stage;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.media3.session.*;
import android.content.*;
import android.view.*;
import android.webkit.WebView;
import android.os.SystemClock;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import com.google.common.util.concurrent.ListenableFuture;
import static org.junit.Assert.*;

@androidx.media3.common.util.UnstableApi
@RunWith(AndroidJUnit4.class)
public class StartupTest {

 @Test public void migrationScopeFreshnessAndTranslation() throws Exception {
  DailyNews.Story s=new DailyNews.Story();s.title="Italy rescues 40 migrants near Lampedusa";s.desc="Refugees reach Italy.";s.link="https://www.infomigrants.net/en/test";s.time=System.currentTimeMillis();
  assertTrue(DailyNews.migration(s,"it"));assertFalse(DailyNews.migration(s,"tr"));assertFalse(DailyNews.migration(s,"uk"));
  s.title="Greek football wins in Greece";s.desc="Sports match";assertFalse(DailyNews.migration(s,"gr"));
  for(String[] example:new String[][]{{"uk","UK asylum policy changes"},{"gr","Greece rescues refugees"},{"tr","Türkiye arrests irregular migrants"}}){s.title=example[1];s.desc="";assertTrue(DailyNews.migration(s,example[0]));}
  assertTrue(DailyNews.date(java.time.LocalDate.now().toString())>0);assertEquals(0,DailyNews.date("Unknown"));assertTrue(DailyNews.recent(s,System.currentTimeMillis()));s.time=System.currentTimeMillis()-73*3600000L;assertFalse(DailyNews.recent(s,System.currentTimeMillis()));s.time=0;assertFalse(DailyNews.recent(s,System.currentTimeMillis()));
  java.util.Set<Integer> ids=new java.util.HashSet<>();for(String country:DailyNews.COUNTRIES)ids.add(DailyNews.id(country));assertEquals(4,ids.size());
  s.title="Turkey migration news";s.desc="A short news excerpt.";s.source="InfoMigrants";s.country="tr";
  NewsTranslation.Translator translator=(value,from,to)->to.equals("fa")?"خبر مهاجرت تازه":value;
  NewsTranslation.Display fa=NewsTranslation.display(s,"fa",translator),en=NewsTranslation.display(s,"en",translator),both=NewsTranslation.display(s,"both",translator);
  assertEquals("خبر مهاجرت تازه",fa.title);assertFalse(fa.body.contains(s.title));assertEquals(s.title,en.title);assertTrue(both.body.contains(s.title));assertTrue(both.body.contains("خبر مهاجرت تازه"));
  assertTrue(NewsTranslation.display(s,"fa",(v,f,t)->{throw new java.io.IOException("offline");}).body.contains("متن اصلی"));
  assertEquals("tr",NewsTranslation.language("Göçmenler sınırda yakalandı"));assertEquals("el",NewsTranslation.language("Πρόσφυγες στην Ελλάδα"));
  String input="مهاجر 😀".repeat(200);assertEquals(input,String.join("",NewsTranslation.chunks(input)));for(String chunk:NewsTranslation.chunks(input))assertTrue(chunk.getBytes(java.nio.charset.StandardCharsets.UTF_8).length<=450);
 }

 private static String eval(android.app.Instrumentation instr,WebView web,String script) throws Exception {
  CountDownLatch latch=new CountDownLatch(1);
  AtomicReference<String> result=new AtomicReference<>("");
  instr.runOnMainSync(()->web.evaluateJavascript(script,value->{result.set(value);latch.countDown();}));
  assertTrue("WebView callback",latch.await(15,TimeUnit.SECONDS));
  return result.get();
 }

 @Test public void launchLoadsWebUiAndNativeRadioConnects() throws Exception {
  android.app.Instrumentation instr=InstrumentationRegistry.getInstrumentation();
  Context target=instr.getTargetContext();
  try(android.os.ParcelFileDescriptor shell=instr.getUiAutomation().executeShellCommand("settings put secure tts_default_synth com.nodin.english.test")){
   java.io.FileInputStream input=new java.io.FileInputStream(shell.getFileDescriptor());while(input.read()!=-1){}
  }
  instr.runOnMainSync(()->target.startActivity(new Intent(target,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
  AtomicReference<MainActivity> activity=new AtomicReference<>();
  for(int i=0;i<40 && activity.get()==null;i++){
   instr.runOnMainSync(()->{
    for(android.app.Activity a:ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED))
     if(a instanceof MainActivity)activity.set((MainActivity)a);
   });
   if(activity.get()==null)SystemClock.sleep(250);
  }
  assertNotNull("Activity must reach RESUMED",activity.get());
  try {
   boolean loaded=false;
   for(int i=0;i<60 && !loaded;i++){
    CountDownLatch latch=new CountDownLatch(1);
    AtomicReference<String> result=new AtomicReference<>("");
    instr.runOnMainSync(()->{
     MainActivity a=activity.get();
     WebView web=(WebView)((ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);
     web.evaluateJavascript("Boolean(document.getElementById('radioStationGrid') && window.AndroidRadio && typeof window.onNativeRadioState==='function')",
      value->{result.set(value);latch.countDown();});
    });
    assertTrue("WebView callback timed out",latch.await(15,TimeUnit.SECONDS));
    loaded="true".equals(result.get());
    if(!loaded)SystemClock.sleep(500);
   }
   assertTrue("Educational UI and native bridge must load",loaded);
   AtomicReference<WebView> webRef=new AtomicReference<>();
   instr.runOnMainSync(()->{
    WebView web=(WebView)((ViewGroup)activity.get().findViewById(android.R.id.content)).getChildAt(0);
    assertEquals("App controls its own text scale",100,web.getSettings().getTextZoom());
    webRef.set(web);
   });
   WebView web=webRef.get();
   assertEquals("Font starts at 16", "16", eval(instr,web,"Number(document.getElementById('fontRange').value)"));
   assertEquals("Regional migration module loads", "true", eval(instr,web,"Boolean(window.MigrantRegion && document.querySelector('[data-msub=region]') && document.getElementById('regionCountry').options.length===3)"));
   assertEquals("Three separate country tabs", "3", eval(instr,web,"document.querySelectorAll('[data-rh-country]').length"));
   assertEquals("Seven country sections", "7", eval(instr,web,"document.querySelectorAll('[data-rh-view]').length"));
   assertEquals("Regional text is two sizes larger", "18", eval(instr,web,"parseFloat(getComputedStyle(document.getElementById('migrantSub-region')).fontSize)"));
   assertTrue("Eurostat source allowed", NativeNews.allowed(new java.net.URL("https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/migr_asyappctzm")));
   assertFalse("No arbitrary native fetch destinations", NativeNews.allowed(new java.net.URL("https://localhost/private")));
   assertFalse("No HTTP downgrade", NativeNews.allowed(new java.net.URL("http://www.goc.gov.tr/duzensiz-goc-istatistikler")));
   assertFalse("No credentials in source URLs", NativeNews.allowed(new java.net.URL("https://name:secret@www.goc.gov.tr/")));
   assertTrue("Official Greek report source", NativeNews.allowed(new java.net.URL("https://migration.gov.gr/en/statistika/")));
   eval(instr,web,"window.originalFont=document.getElementById('fontRange').value;document.getElementById('settingsPanel').classList.remove('hidden');document.getElementById('fontRange').value=14;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));true");
   SystemClock.sleep(700);
   double previous=Double.parseDouble(eval(instr,web,"parseFloat(getComputedStyle(document.querySelector('#settingsPanel .field label')).fontSize)"));
   eval(instr,web,"document.getElementById('fontRange').value=10;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));true");
   SystemClock.sleep(700);
   String metrics=eval(instr,web,"(()=>{const probe=document.createElement('span');probe.style.fontSize='1rem';document.body.appendChild(probe);const result={min:document.getElementById('fontRange').min,root:getComputedStyle(document.documentElement).fontSize,label:parseFloat(getComputedStyle(document.querySelector('#settingsPanel .field label')).fontSize),probe:getComputedStyle(probe).fontSize,saved:JSON.parse(localStorage.getItem('fse:settings')||'{}').fontSize,inline:document.documentElement.getAttribute('style'),updatedSource:Array.from(document.scripts).some(s=>s.textContent.includes('document.body.style.fontSize = size'))};probe.remove();return result;})()");
   org.json.JSONObject m=new org.json.JSONObject(metrics);
   assertEquals(metrics,"10",m.getString("min"));
   assertEquals(metrics,"10px",m.getString("root"));
   assertEquals(metrics,"10px",m.getString("probe"));
   assertTrue(metrics,m.getDouble("label")<previous);
   assertEquals(metrics,10,m.getInt("saved"));
   assertEquals("Only the actual clock is larger", "true", eval(instr,web,"parseFloat(getComputedStyle(document.getElementById('landmarkLondonTime')).fontSize)===parseFloat(getComputedStyle(document.querySelector('.bb-time-label')).fontSize)+2"));
   assertEquals("Only the actual date is larger", "true", eval(instr,web,"parseFloat(getComputedStyle(document.getElementById('landmarkUkDate')).fontSize)===parseFloat(getComputedStyle(document.querySelector('.bb-time-label')).fontSize)+2"));
   eval(instr,web,"document.getElementById('fontRange').value=window.originalFont;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));document.getElementById('settingsPanel').classList.add('hidden');true");
   assertTrue("Selected Big Ben launcher icon exists", target.getApplicationInfo().icon != 0);
   eval(instr,web,"window.nodinFeed=\"<rss><channel><item><title>Italy arrests 32 migrant smugglers</title><link>https://www.ansa.it/test/arrests</link><pubDate>Sun, 04 Oct 2026 09:00:00 GMT</pubDate></item><item><title>Italy rescues 48 refugees near Lampedusa</title><link>https://www.ansa.it/test/rescue</link><pubDate>Sat, 03 Oct 2026 09:00:00 GMT</pubDate></item></channel></rss>\";MigrantRegion.open({lang:'en',fetchText:async(u)=>{if(u.includes('rss'))return window.nodinFeed;throw new Error('offline test');},fetchBlob:async()=>{throw new Error('offline test');},translate:async(t)=>t});true");
   boolean newsReady=false;
   for(int i=0;i<40&&!newsReady;i++){newsReady="true".equals(eval(instr,web,"document.getElementById('regionNewsContent').textContent.includes('Italy arrests')"));if(!newsReady)SystemClock.sleep(100);}
   assertTrue("Regional news reader loads",newsReady);
   assertEquals("Next report works", "true", eval(instr,web,"document.getElementById('regionNewsNext').click();document.getElementById('regionNewsContent').textContent.includes('Italy rescues') && document.getElementById('regionNewsNext').disabled"));
   assertEquals("Previous report works", "true", eval(instr,web,"document.getElementById('regionNewsPrev').click();document.getElementById('regionNewsContent').textContent.includes('Italy arrests')"));
   assertEquals("Arrest category works", "true", eval(instr,web,"document.getElementById('regionNewsFilter').value='arrests';document.getElementById('regionNewsFilter').dispatchEvent(new Event('change'));document.getElementById('regionNewsContent').textContent.includes('Italy arrests') && document.getElementById('regionNewsNext').disabled"));
   assertTrue("Official PlayStation feed allowed",NativeNews.allowed(new java.net.URL("https://blog.playstation.com/feed/")));
   assertTrue("Official Xbox feed allowed",NativeNews.allowed(new java.net.URL("https://news.xbox.com/en-us/feed/")));
   eval(instr,web,"window.originalNewsFetch=window.fetch;window.fetch=async(u)=>{u=String(u);if(u.includes('/native-news?')){const feed=new URL(u,location.href).searchParams.get('url');let title=feed.includes('news.xbox.com')?'Xbox Game Pass adds new games':feed.includes('pcgamer.com')?'Steam PC update arrives':'PlayStation PS5 reveals new game';return new Response('<rss><channel><item><title>'+title+'</title><description>Latest release details.</description><link>https://blog.playstation.com/test/'+encodeURIComponent(title)+'</link><pubDate>'+new Date(Date.now()-60000*(feed.includes('xbox')?2:feed.includes('pcgamer')?3:1)).toUTCString()+'</pubDate></item></channel></rss>');}if(u.includes('api.mymemory'))return new Response(JSON.stringify({responseStatus:200,responseData:{translatedText:'خبر تازه درباره بازی'}}));return window.originalNewsFetch(u);};document.querySelector('[data-cat=gaming]').click();true");
   boolean gamesReady=false;
   for(int i=0;i<40&&!gamesReady;i++){gamesReady="true".equals(eval(instr,web,"NodinHeadlinesApi.items().length===3 && !document.getElementById('fetchHeadlineBtn').disabled"));if(!gamesReady)SystemClock.sleep(100);}
   assertTrue("Gaming feeds deduplicate and load: "+eval(instr,web,"JSON.stringify({count:window.NodinHeadlinesApi?.items().length,status:document.getElementById('headlineStatus').textContent,feeds:document.getElementById('headlineFeedStatus').textContent})"),gamesReady);
   assertEquals("Games use the existing tab theme","true",eval(instr,web,"document.querySelector('[data-cat=gaming]').classList.contains('cat-btn') && document.querySelector('[data-cat=gaming]').classList.contains('active')"));
   assertEquals("Gaming next story", "true",eval(instr,web,"document.getElementById('anotherHeadlineBtn').click();document.getElementById('headlineEn').textContent.includes('Xbox Game Pass')"));
   assertEquals("Gaming previous story", "true",eval(instr,web,"document.getElementById('previousHeadlineBtn').click();document.getElementById('headlineEn').textContent.includes('PlayStation PS5')"));
   assertEquals("Xbox filter and end boundary", "true",eval(instr,web,"document.getElementById('gamingFilter').value='xbox';document.getElementById('gamingFilter').dispatchEvent(new Event('change'));NodinHeadlinesApi.items().length===1 && document.getElementById('anotherHeadlineBtn').disabled && document.getElementById('headlineEn').textContent.includes('Xbox')"));
   eval(instr,web,"document.getElementById('gamingFilter').value='all';document.getElementById('gamingFilter').dispatchEvent(new Event('change'));window.fetch=async(u)=>{if(String(u).includes('/native-news?'))throw Error('offline test');return new Response(JSON.stringify({responseStatus:200,responseData:{translatedText:'خبر تازه درباره بازی'}}));};NodinHeadlinesApi.load();true");
   boolean offlineReady=false;for(int i=0;i<40&&!offlineReady;i++){offlineReady="true".equals(eval(instr,web,"!document.getElementById('fetchHeadlineBtn').disabled && NodinHeadlinesApi.items().length===3 && document.getElementById('headlineStatus').textContent.includes('نسخهٔ ذخیره')"));if(!offlineReady)SystemClock.sleep(100);}assertTrue("Cached gaming news is dated and labelled after failure",offlineReady);
   eval(instr,web,"NodinHeadlinesApi.openNotification({category:'gaming',title:'Notification PS5 story',desc:'Short news excerpt',link:'https://blog.playstation.com/test/notification',source:'PlayStation Blog',published:new Date().toUTCString()});true");
   assertEquals("Notification opens the exact story", "true",eval(instr,web,"document.getElementById('headlineEn').textContent.includes('Notification PS5 story') && document.querySelector('[data-cat=gaming]').classList.contains('active')"));
   eval(instr,web,"window.fetch=window.originalNewsFetch;true");
   assertTrue("Notification configuration contains gaming feeds",new org.json.JSONObject(new String(target.getAssets().open("headline-feeds.json").readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getJSONArray("gaming").length()>=5);
   try(android.os.ParcelFileDescriptor shell=instr.getUiAutomation().executeShellCommand("pm grant com.nodin.english android.permission.POST_NOTIFICATIONS")){java.io.FileInputStream input=new java.io.FileInputStream(shell.getFileDescriptor());while(input.read()!=-1){}}
   DailyNews.Story notification=new DailyNews.Story();notification.title="PlayStation test headline";notification.desc="A short excerpt in the expanded daily news notification.";notification.link="https://blog.playstation.com/test/notification";notification.source="PlayStation Blog";notification.published=java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC).format(java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME);notification.time=System.currentTimeMillis();DailyNews.post(target,notification,"gaming");
   android.app.NotificationManager notifications=target.getSystemService(android.app.NotificationManager.class);boolean noticeFound=false;
   for(int i=0;i<20&&!noticeFound;i++){for(android.service.notification.StatusBarNotification n:notifications.getActiveNotifications()){if(n.getId()==DailyNews.NOTIFICATION){noticeFound=true;assertEquals("PlayStation test headline",n.getNotification().extras.getString(android.app.Notification.EXTRA_TITLE));assertTrue(n.getNotification().extras.getString(android.app.Notification.EXTRA_BIG_TEXT).contains("short excerpt"));assertNotNull(n.getNotification().contentIntent);}}if(!noticeFound)SystemClock.sleep(100);}
   assertTrue("Daily news notification appears",noticeFound);assertEquals(android.app.NotificationManager.IMPORTANCE_HIGH,notifications.getNotificationChannel(DailyNews.CHANNEL).getImportance());DailyNews.schedule(target,false,"gaming");assertFalse("Disable stops news",DailyNews.prefs(target).getBoolean("enabled",true));notifications.cancel(DailyNews.NOTIFICATION);

   eval(instr,web,"document.getElementById('dailyNewsCategory').value='migration';document.getElementById('dailyNewsCountry').value='all';document.getElementById('dailyNewsLanguage').value='both';document.getElementById('dailyNewsCategory').dispatchEvent(new Event('change'));true");
   boolean settingsSaved=false;for(int i=0;i<30&&!settingsSaved;i++){settingsSaved="both".equals(DailyNews.prefs(target).getString("language",""))&&"migration".equals(DailyNews.prefs(target).getString("category",""));if(!settingsSaved)SystemClock.sleep(100);}assertTrue("Country and notification language persist through the native bridge",settingsSaved);
   assertEquals("all",DailyNews.status(target).getString("country"));assertEquals("both",DailyNews.status(target).getString("language"));
   assertEquals("Country selector enabled for migration", "true",eval(instr,web,"!document.getElementById('dailyNewsCountry').disabled && document.getElementById('dailyNewsLanguage').value==='both'"));
   notification.country="tr";notification.title="Turkey arrests irregular migrants";notification.desc="Detentions reported by Turkish authorities.";
   DailyNews.post(target,notification,"migration",NewsTranslation.display(notification,"both",(value,from,to)->to.equals("fa")?"خبر تازه درباره مهاجران ترکیه":value));
   android.app.PendingIntent migrantOpen=null;for(android.service.notification.StatusBarNotification n:notifications.getActiveNotifications()){if(n.getId()==DailyNews.id("tr")){assertEquals("خبر تازه درباره مهاجران ترکیه",n.getNotification().extras.getString(android.app.Notification.EXTRA_TITLE));assertTrue(n.getNotification().extras.getString(android.app.Notification.EXTRA_BIG_TEXT).contains(notification.title));migrantOpen=n.getNotification().contentIntent;}}
   assertNotNull("Bilingual migration notice is posted",migrantOpen);migrantOpen.send();
   boolean migrationOpened=false;for(int i=0;i<40&&!migrationOpened;i++){migrationOpened="true".equals(eval(instr,web,"document.getElementById('regionCountry').value==='tr' && !!document.getElementById('migrationNotificationStory') && document.getElementById('migrationNotificationStory').textContent.includes('Turkey arrests irregular migrants') && !document.getElementById('rhPane-news').hidden"));if(!migrationOpened)SystemClock.sleep(100);}assertTrue("Tapping the notice opens its exact story in the Turkey news tab",migrationOpened);
   eval(instr,web,"NodinMigrationNotifications.open({category:'migration',country:'uk',title:'UK asylum test story',desc:'Excerpt',link:'https://www.theguardian.com/test',source:'Guardian'});true");
   assertEquals("UK notification routes to UK migrant news", "true",eval(instr,web,"!document.getElementById('migrantSub-news').classList.contains('hidden') && document.getElementById('migrationNotificationStory').textContent.includes('UK asylum test story')"));
   DailyNews.schedule(target,false,"migration");for(android.service.notification.StatusBarNotification n:notifications.getActiveNotifications())assertTrue("Disable removes all country news notices",n.getId()<DailyNews.NOTIFICATION||n.getId()>DailyNews.id("tr"));

   instr.runOnMainSync(()->{
    try{
     java.lang.reflect.Field field=MainActivity.class.getDeclaredField("nativeSpeech");field.setAccessible(true);
     ((NativeSpeech)field.get(activity.get())).close();
     field.set(activity.get(),new NativeSpeech(activity.get(),web,"com.nodin.english.test"));
    }catch(Exception e){throw new RuntimeException(e);}
   });
   boolean hasVoices=false;
   for(int i=0;i<40&&!hasVoices;i++){
    hasVoices="true".equals(eval(instr,web,"speechSynthesis.getVoices().some(v=>v.lang==='en-GB')"));
    if(!hasVoices)SystemClock.sleep(250);
   }
   assertTrue("Native English voices discovered: "+eval(instr,web,"JSON.stringify({voices:speechSynthesis.getVoices(),diag:document.getElementById('voiceDiag').textContent})"),hasVoices);
   for(String accent:new String[]{"en-GB","en-US"}){
    eval(instr,web,"window.ttsEvents=[];var u=new SpeechSynthesisUtterance('Hello from Nodin');u.lang='"+accent+"';u.onstart=()=>ttsEvents.push('start');u.onend=()=>ttsEvents.push('end');u.onerror=e=>ttsEvents.push('error:'+e.error);speechSynthesis.speak(u);true");
    boolean ended=false;
    for(int i=0;i<60&&!ended;i++){ended="true".equals(eval(instr,web,"ttsEvents.includes('end')"));if(!ended)SystemClock.sleep(200);}
    assertTrue("Speech completed "+accent+" "+eval(instr,web,"JSON.stringify(ttsEvents)"),ended);
    assertEquals("Speech started", "true",eval(instr,web,"ttsEvents.includes('start')"));
   }
   eval(instr,web,"document.getElementById('ttsTestBtn').click();true");SystemClock.sleep(150);
   eval(instr,web,"document.getElementById('ttsStopBtn').click();true");
   assertEquals("Stop clears speech", "false",eval(instr,web,"speechSynthesis.speaking || speechSynthesis.pending"));
   AtomicReference<ListenableFuture<MediaController>> ref=new AtomicReference<>();
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{
    Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
    SessionToken token=new SessionToken(c,new ComponentName(c,RadioService.class));
    ref.set(new MediaController.Builder(c,token).buildAsync());
   });
   MediaController controller=ref.get().get(15,TimeUnit.SECONDS);
   assertNotNull("Native service connection",controller);
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->MediaController.releaseFuture(ref.get()));
  } finally { instr.runOnMainSync(()->activity.get().finish()); }
 }
}
