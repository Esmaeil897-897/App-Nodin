package com.nodin.english;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry;
import androidx.test.runner.lifecycle.Stage;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.media3.session.*;
import android.content.*;
import android.view.*;
import android.webkit.WebView;
import android.os.SystemClock;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import com.google.common.util.concurrent.ListenableFuture;
import static org.junit.Assert.*;

@androidx.media3.common.util.UnstableApi
@RunWith(AndroidJUnit4.class)
public class StartupTest {
 private static String eval(android.app.Instrumentation instr,WebView web,String script) throws Exception {
  CountDownLatch latch=new CountDownLatch(1);
  AtomicReference<String> result=new AtomicReference<>("");
  instr.runOnMainSync(()->web.evaluateJavascript(script,value->{result.set(value);latch.countDown();}));
  assertTrue("WebView callback",latch.await(15,TimeUnit.SECONDS));
  return result.get();
 }

 @Test public void launchLoadsWebUiAndNativeRadioConnects() throws Exception {
  android.app.Instrumentation instr=InstrumentationRegistry.getInstrumentation();
  Context target=instr.getTargetContext();
  try(android.os.ParcelFileDescriptor shell=instr.getUiAutomation().executeShellCommand("settings put secure tts_default_synth com.nodin.english.test")){
   java.io.FileInputStream input=new java.io.FileInputStream(shell.getFileDescriptor());while(input.read()!=-1){}
  }
  instr.runOnMainSync(()->target.startActivity(new Intent(target,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
  AtomicReference<MainActivity> activity=new AtomicReference<>();
  for(int i=0;i<40 && activity.get()==null;i++){
   instr.runOnMainSync(()->{
    for(android.app.Activity a:ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED))
     if(a instanceof MainActivity)activity.set((MainActivity)a);
   });
   if(activity.get()==null)SystemClock.sleep(250);
  }
  assertNotNull("Activity must reach RESUMED",activity.get());
  try {
   boolean loaded=false;
   for(int i=0;i<60 && !loaded;i++){
    CountDownLatch latch=new CountDownLatch(1);
    AtomicReference<String> result=new AtomicReference<>("");
    instr.runOnMainSync(()->{
     MainActivity a=activity.get();
     WebView web=(WebView)((ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);
     web.evaluateJavascript("Boolean(document.getElementById('radioStationGrid') && window.AndroidRadio && typeof window.onNativeRadioState==='function')",
      value->{result.set(value);latch.countDown();});
    });
    assertTrue("WebView callback timed out",latch.await(15,TimeUnit.SECONDS));
    loaded="true".equals(result.get());
    if(!loaded)SystemClock.sleep(500);
   }
   assertTrue("Educational UI and native bridge must load",loaded);
   AtomicReference<WebView> webRef=new AtomicReference<>();
   instr.runOnMainSync(()->{
    WebView web=(WebView)((ViewGroup)activity.get().findViewById(android.R.id.content)).getChildAt(0);
    assertEquals("App controls its own text scale",100,web.getSettings().getTextZoom());
    webRef.set(web);
   });
   WebView web=webRef.get();
   assertEquals("Font starts at 16", "16", eval(instr,web,"Number(document.getElementById('fontRange').value)"));
   assertEquals("Regional migration module loads", "true", eval(instr,web,"Boolean(window.MigrantRegion && document.querySelector('[data-msub=region]') && document.getElementById('regionCountry').options.length===3)"));
   assertFalse("No arbitrary native fetch destinations", NativeNews.allowed(new java.net.URL("https://localhost/private")));
   assertFalse("No HTTP downgrade", NativeNews.allowed(new java.net.URL("http://www.goc.gov.tr/duzensiz-goc-istatistikler")));
   assertFalse("No credentials in source URLs", NativeNews.allowed(new java.net.URL("https://name:secret@www.goc.gov.tr/")));
   assertTrue("Official Greek report source", NativeNews.allowed(new java.net.URL("https://migration.gov.gr/en/statistika/")));
   eval(instr,web,"window.originalFont=document.getElementById('fontRange').value;document.getElementById('settingsPanel').classList.remove('hidden');document.getElementById('fontRange').value=14;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));true");
   SystemClock.sleep(700);
   double previous=Double.parseDouble(eval(instr,web,"parseFloat(getComputedStyle(document.querySelector('#settingsPanel .field label')).fontSize)"));
   eval(instr,web,"document.getElementById('fontRange').value=10;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));true");
   SystemClock.sleep(700);
   String metrics=eval(instr,web,"(()=>{const probe=document.createElement('span');probe.style.fontSize='1rem';document.body.appendChild(probe);const result={min:document.getElementById('fontRange').min,root:getComputedStyle(document.documentElement).fontSize,label:parseFloat(getComputedStyle(document.querySelector('#settingsPanel .field label')).fontSize),probe:getComputedStyle(probe).fontSize,saved:JSON.parse(localStorage.getItem('fse:settings')||'{}').fontSize,inline:document.documentElement.getAttribute('style'),updatedSource:Array.from(document.scripts).some(s=>s.textContent.includes('document.body.style.fontSize = size'))};probe.remove();return result;})()");
   org.json.JSONObject m=new org.json.JSONObject(metrics);
   assertEquals(metrics,"10",m.getString("min"));
   assertEquals(metrics,"10px",m.getString("root"));
   assertEquals(metrics,"10px",m.getString("probe"));
   assertTrue(metrics,m.getDouble("label")<previous);
   assertEquals(metrics,10,m.getInt("saved"));
   assertEquals("Only the actual clock is larger", "true", eval(instr,web,"parseFloat(getComputedStyle(document.getElementById('landmarkLondonTime')).fontSize)===parseFloat(getComputedStyle(document.querySelector('.bb-time-label')).fontSize)+2"));
   assertEquals("Only the actual date is larger", "true", eval(instr,web,"parseFloat(getComputedStyle(document.getElementById('landmarkUkDate')).fontSize)===parseFloat(getComputedStyle(document.querySelector('.bb-time-label')).fontSize)+2"));
   eval(instr,web,"document.getElementById('fontRange').value=window.originalFont;document.getElementById('fontRange').dispatchEvent(new Event('input',{bubbles:true}));document.getElementById('settingsPanel').classList.add('hidden');true");
   instr.runOnMainSync(()->{
    try{
     java.lang.reflect.Field field=MainActivity.class.getDeclaredField("nativeSpeech");field.setAccessible(true);
     ((NativeSpeech)field.get(activity.get())).close();
     field.set(activity.get(),new NativeSpeech(activity.get(),web,"com.nodin.english.test"));
    }catch(Exception e){throw new RuntimeException(e);}
   });
   boolean hasVoices=false;
   for(int i=0;i<40&&!hasVoices;i++){
    hasVoices="true".equals(eval(instr,web,"speechSynthesis.getVoices().some(v=>v.lang==='en-GB')"));
    if(!hasVoices)SystemClock.sleep(250);
   }
   assertTrue("Native English voices discovered: "+eval(instr,web,"JSON.stringify({voices:speechSynthesis.getVoices(),diag:document.getElementById('voiceDiag').textContent})"),hasVoices);
   for(String accent:new String[]{"en-GB","en-US"}){
    eval(instr,web,"window.ttsEvents=[];var u=new SpeechSynthesisUtterance('Hello from Nodin');u.lang='"+accent+"';u.onstart=()=>ttsEvents.push('start');u.onend=()=>ttsEvents.push('end');u.onerror=e=>ttsEvents.push('error:'+e.error);speechSynthesis.speak(u);true");
    boolean ended=false;
    for(int i=0;i<60&&!ended;i++){ended="true".equals(eval(instr,web,"ttsEvents.includes('end')"));if(!ended)SystemClock.sleep(200);}
    assertTrue("Speech completed "+accent+" "+eval(instr,web,"JSON.stringify(ttsEvents)"),ended);
    assertEquals("Speech started", "true",eval(instr,web,"ttsEvents.includes('start')"));
   }
   eval(instr,web,"document.getElementById('ttsTestBtn').click();true");SystemClock.sleep(150);
   eval(instr,web,"document.getElementById('ttsStopBtn').click();true");
   assertEquals("Stop clears speech", "false",eval(instr,web,"speechSynthesis.speaking || speechSynthesis.pending"));
   AtomicReference<ListenableFuture<MediaController>> ref=new AtomicReference<>();
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{
    Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
    SessionToken token=new SessionToken(c,new ComponentName(c,RadioService.class));
    ref.set(new MediaController.Builder(c,token).buildAsync());
   });
   MediaController controller=ref.get().get(15,TimeUnit.SECONDS);
   assertNotNull("Native service connection",controller);
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->MediaController.releaseFuture(ref.get()));
  } finally { instr.runOnMainSync(()->activity.get().finish()); }
 }
}
