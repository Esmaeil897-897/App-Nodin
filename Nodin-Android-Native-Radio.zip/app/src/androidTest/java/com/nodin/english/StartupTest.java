package com.nodin.english;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry;
import androidx.test.runner.lifecycle.Stage;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.media3.session.*;
import android.content.*;
import android.view.*;
import android.webkit.WebView;
import android.os.SystemClock;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import com.google.common.util.concurrent.ListenableFuture;
import static org.junit.Assert.*;

@androidx.media3.common.util.UnstableApi
@RunWith(AndroidJUnit4.class)
public class StartupTest {
 @Test public void launchLoadsWebUiAndNativeRadioConnects() throws Exception {
  android.app.Instrumentation instr=InstrumentationRegistry.getInstrumentation();
  Context target=instr.getTargetContext();
  instr.runOnMainSync(()->target.startActivity(new Intent(target,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
  AtomicReference<MainActivity> activity=new AtomicReference<>();
  for(int i=0;i<40 && activity.get()==null;i++){
   instr.runOnMainSync(()->{
    for(android.app.Activity a:ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED))
     if(a instanceof MainActivity)activity.set((MainActivity)a);
   });
   if(activity.get()==null)SystemClock.sleep(250);
  }
  assertNotNull("Activity must reach RESUMED",activity.get());
  try {
   boolean loaded=false;
   for(int i=0;i<60 && !loaded;i++){
    CountDownLatch latch=new CountDownLatch(1);
    AtomicReference<String> result=new AtomicReference<>("");
    instr.runOnMainSync(()->{
     MainActivity a=activity.get();
     WebView web=(WebView)((ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);
     web.evaluateJavascript("Boolean(document.getElementById('radioStationGrid') && window.AndroidRadio && typeof window.onNativeRadioState==='function')",
      value->{result.set(value);latch.countDown();});
    });
    assertTrue("WebView callback timed out",latch.await(3,TimeUnit.SECONDS));
    loaded="true".equals(result.get());
    if(!loaded)SystemClock.sleep(500);
   }
   assertTrue("Educational UI and native bridge must load",loaded);
   CountDownLatch fontLatch=new CountDownLatch(1);
   AtomicReference<String> fontResult=new AtomicReference<>("");
   instr.runOnMainSync(()->{
    WebView web=(WebView)((ViewGroup)activity.get().findViewById(android.R.id.content)).getChildAt(0);
    assertEquals("App controls its own text scale",100,web.getSettings().getTextZoom());
    web.evaluateJavascript("(()=>{const r=document.getElementById('fontRange');const original=r.value;"+
     "const label=document.querySelector('#settingsPanel .field label');"+
     "const probe=document.createElement('span');probe.style.fontSize='1rem';document.body.appendChild(probe);"+
     "r.value=14;r.dispatchEvent(new Event('input',{bubbles:true}));const previous=parseFloat(getComputedStyle(label).fontSize);"+
     "r.value=10;r.dispatchEvent(new Event('input',{bubbles:true}));"+
     "const detail=JSON.stringify({min:r.min,root:getComputedStyle(document.documentElement).fontSize,label:getComputedStyle(label).fontSize,previous,probe:getComputedStyle(probe).fontSize,saved:localStorage.getItem('fse:settings')});const ok=r.min==='10' && getComputedStyle(document.documentElement).fontSize==='10px' && " +
     "parseFloat(getComputedStyle(label).fontSize)<previous && getComputedStyle(probe).fontSize==='10px' && " +
     "JSON.parse(localStorage.getItem('fse:settings')||'{}').fontSize===10;"+
     "probe.remove();r.value=original;r.dispatchEvent(new Event('input',{bubbles:true}));return ok?'PASS':detail;})()",
     value->{fontResult.set(value);fontLatch.countDown();});
   });
   assertTrue("Font test callback",fontLatch.await(5,TimeUnit.SECONDS));
   assertEquals("Font control shrinks labels and rem text to 10px and saves preference","\"PASS\"",fontResult.get());
   AtomicReference<ListenableFuture<MediaController>> ref=new AtomicReference<>();
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{
    Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
    SessionToken token=new SessionToken(c,new ComponentName(c,RadioService.class));
    ref.set(new MediaController.Builder(c,token).buildAsync());
   });
   MediaController controller=ref.get().get(15,TimeUnit.SECONDS);
   assertNotNull("Native service connection",controller);
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->MediaController.releaseFuture(ref.get()));
  } finally { instr.runOnMainSync(()->activity.get().finish()); }
 }
}
