package com.nodin.english;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.core.app.ActivityScenario;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.media3.session.*;
import android.content.*;
import android.view.*;
import android.webkit.WebView;
import android.os.SystemClock;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import com.google.common.util.concurrent.ListenableFuture;
import static org.junit.Assert.*;

@androidx.media3.common.util.UnstableApi
@RunWith(AndroidJUnit4.class)
public class StartupTest {
 @Test public void launchLoadsWebUiAndNativeRadioConnects() throws Exception {
  try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)){
   boolean loaded=false;
   for(int i=0;i<60 && !loaded;i++){
    CountDownLatch latch=new CountDownLatch(1);
    AtomicReference<String> result=new AtomicReference<>("");
    scenario.onActivity(a->{
     WebView web=(WebView)((ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);
     web.evaluateJavascript("Boolean(document.getElementById('radioStationGrid') && window.AndroidRadio && typeof window.onNativeRadioState==='function')",
      value->{result.set(value);latch.countDown();});
    });
    assertTrue("WebView callback timed out",latch.await(3,TimeUnit.SECONDS));
    loaded="true".equals(result.get());
    if(!loaded)SystemClock.sleep(500);
   }
   assertTrue("Educational UI and native bridge must load",loaded);
   AtomicReference<ListenableFuture<MediaController>> ref=new AtomicReference<>();
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{
    Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
    SessionToken token=new SessionToken(c,new ComponentName(c,RadioService.class));
    ref.set(new MediaController.Builder(c,token).buildAsync());
   });
   MediaController controller=ref.get().get(15,TimeUnit.SECONDS);
   assertNotNull("Native service connection",controller);
   InstrumentationRegistry.getInstrumentation().runOnMainSync(()->MediaController.releaseFuture(ref.get()));
  }
 }
}
