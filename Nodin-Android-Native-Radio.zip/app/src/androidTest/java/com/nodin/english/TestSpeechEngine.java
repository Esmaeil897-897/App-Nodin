package com.nodin.english;
import android.speech.tts.*;
import android.media.AudioFormat;
import java.util.*;
public class TestSpeechEngine extends TextToSpeechService {
 private volatile boolean stopped;
 protected String[] onGetLanguage(){return new String[]{"eng","GBR",""};}
 protected int onIsLanguageAvailable(String l,String c,String v){return l.equals("eng")?TextToSpeech.LANG_COUNTRY_AVAILABLE:TextToSpeech.LANG_NOT_SUPPORTED;}
 protected int onLoadLanguage(String l,String c,String v){return onIsLanguageAvailable(l,c,v);}
 protected void onStop(){stopped=true;}
 public java.util.List<Voice> onGetVoices(){return Arrays.asList(new Voice("test-GB",Locale.UK,300,100,false,new HashSet<>()),new Voice("test-US",Locale.US,300,100,false,new HashSet<>()));}
 public int onLoadVoice(String name){return TextToSpeech.SUCCESS;}
 public int onIsValidVoiceName(String name){return TextToSpeech.SUCCESS;}
 public String onGetDefaultVoiceNameFor(String l,String c,String v){return c.equals("USA")?"test-US":"test-GB";}
 protected void onSynthesizeText(SynthesisRequest request,SynthesisCallback cb){
  stopped=false;cb.start(16000,AudioFormat.ENCODING_PCM_16BIT,1);
  byte[] audio=new byte[3200];
  for(int k=0;k<10&&!stopped;k++){for(int i=0;i<1600;i++){short x=(short)(Math.sin((k*1600+i)*2*Math.PI*440/16000)*3000);audio[i*2]=(byte)x;audio[i*2+1]=(byte)(x>>8);}cb.audioAvailable(audio,0,audio.length);}
  cb.done();
 }
}
