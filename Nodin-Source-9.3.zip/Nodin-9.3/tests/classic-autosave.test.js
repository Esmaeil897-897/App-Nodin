const vm=require('node:vm'),assert=require('node:assert/strict'),fs=require('node:fs');
const source=fs.readFileSync(__dirname+'/../app/src/main/assets/classic-autosave.js','utf8');
function boot(saved,initial={}){
 class Storage {
  get length(){return Object.keys(this).length;} key(i){return Object.keys(this)[i]??null;}
  getItem(k){return Object.hasOwn(this,k)?this[k]:null;} setItem(k,v){this[k]=String(v);}
  removeItem(k){delete this[k];} clear(){for(const k of Object.keys(this))delete this[k];}
 }
 const store=new Storage();Object.assign(store,initial);const messages=[];
 const ctx={Storage,localStorage:store,location:{origin:'https://appassets.androidplatform.net'},console,
  document:{addEventListener(){},getElementById(){return null;}},XMLHttpRequest:class{open(){}send(){this.status=200;this.responseText=JSON.stringify(saved);}},
  NodinNative:{postMessage(s){messages.push(JSON.parse(s));}}};ctx.window=ctx;vm.runInNewContext(source,ctx);return {ctx,store,messages};
}
const saved={initialized:true,epoch:'e',values:{fse_learn_path_v2:'{"stage":7}','fse:quiz-stats':'{"asked":9}'}};
let b=boot(saved,{fse_learn_path_v2:'{"stage":1}',fse_oxford_path_v1:'stale',unrelated:'keep'});
assert.equal(b.store.getItem('fse_learn_path_v2'),'{"stage":7}');assert.equal(b.store.getItem('fse_oxford_path_v1'),null);assert.equal(b.store.getItem('unrelated'),'keep');
b.store.setItem('fse_learn_path_v2','{"stage":1}');assert.equal(b.messages.at(-1).value,'{"stage":1}');
b.store.removeItem('fse:quiz-stats');assert.equal(b.messages.at(-1).op,'remove');
const n=b.messages.length;b.store.setItem('nodin:news-hub:v2','cache');assert.equal(b.messages.length,n);
b.store.clear();assert.equal(b.messages.at(-1).op,'clear');
b=boot({initialized:true,epoch:'e',values:{}},{'fse_learn_path_v2':'old'});assert.equal(b.store.getItem('fse_learn_path_v2'),null);assert.equal(b.ctx.NodinClassic.authoritative,true);
b=boot({initialized:false,epoch:'e',values:{}},{'fse_learn_path_v2':'existing'});assert.equal(b.messages[0].op,'seed');assert.equal(b.messages[0].values.fse_learn_path_v2,'existing');assert.equal(b.ctx.NodinClassic.authoritative,false);
assert.throws(()=>b.ctx.NodinClassic.replace({unrelated:'bad'}));
console.log('Classic autosave: restore, reset, deletion, cache exclusion, clear, empty snapshot, initial migration passed');
