package com.nodin.english;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;
import androidx.webkit.*;
import androidx.media3.common.*;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Collections;
import java.util.Arrays;

@androidx.media3.common.util.UnstableApi
public class MainActivity extends Activity {
    private WebView web;
    private ClassicProgressStore classicProgress;
    private NativeSpeech nativeSpeech;
    private NativeListening nativeListening;
    private PracticeRecorder practiceRecorder;
    private boolean pendingPracticeRecord=false;
    private NativeRadioCheck nativeRadioCheck;
    private String pendingListenLanguage;
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private JSONObject pendingPlay;
    private android.content.SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady;
    private GeolocationPermissions.Callback locationCallback;
    private String locationOrigin;
    private java.io.ByteArrayOutputStream exportBuffer;
    private byte[] saveBytes;

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onEvents(Player player, Player.Events events) { publish(); }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("native",MODE_PRIVATE);
        classicProgress=ClassicProgressStore.get(this);
        web=new WebView(this);
        setContentView(web);
        // Edge-to-edge in Android 15: protect controls from status/navigation bars.
        web.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
        });
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setGeolocationEnabled(true);
        web.getSettings().setTextZoom(100);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
                Uri uri=req.getUrl();
                if("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()) && "/classic-progress".equals(uri.getPath()) && "GET".equals(req.getMethod()))
                    return new WebResourceResponse("application/json","UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-store"),new java.io.ByteArrayInputStream(classicProgress.snapshot().toString().getBytes(java.nio.charset.StandardCharsets.UTF_8)));
                if("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())
                    && "/native-news".equals(uri.getPath()) && "GET".equals(req.getMethod()))
                    return NativeNews.fetch(uri);
                if("https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost())&&"GET".equals(req.getMethod())&&Arrays.asList("/news-hub","/news-rss").contains(uri.getPath())){
                    try{NewsRepository repository=NewsRepository.get(MainActivity.this);boolean rss="/news-rss".equals(uri.getPath());long since=-1;try{since=Long.parseLong(uri.getQueryParameter("since"));}catch(Exception ignored){}String body=rss?repository.rss():repository.snapshot(since).toString();return new WebResourceResponse(rss?"application/rss+xml":"application/json","UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-store"),new java.io.ByteArrayInputStream(body.getBytes(java.nio.charset.StandardCharsets.UTF_8)));}catch(Exception e){return new WebResourceResponse("application/json","UTF-8",500,"Unavailable",Collections.emptyMap(),new java.io.ByteArrayInputStream("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8)));}
                }
                return loader.shouldInterceptRequest(uri);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
                if(!req.isForMainFrame()) return false;
                Uri u=req.getUrl();
                if(u.toString().equals("https://appassets.androidplatform.net/assets/index.html")) return false;
                if("https".equals(u.getScheme()) || "http".equals(u.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView v,String url){pageReady=true;DailyNews.bootstrap(MainActivity.this);publish();if(nativeSpeech!=null)nativeSpeech.publishVoices();publishNewsState();openNotificationNews();publishClassicStatus();offerClassicFolder();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
                if(!"https://appassets.androidplatform.net".equals(origin.replaceAll("/$",""))){callback.invoke(origin,false,false);return;}
                if(checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)==android.content.pm.PackageManager.PERMISSION_GRANTED || checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)==android.content.pm.PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);return;}
                if(locationCallback!=null){callback.invoke(origin,false,false);return;}
                locationCallback=callback;locationOrigin=origin;
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION},44);
            }
            @Override public void onGeolocationPermissionsHidePrompt(){locationCallback=null;locationOrigin=null;}

            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                try{startActivityForResult(p.createIntent(),40);return true;}
                catch(Exception e){fileCallback=null;return false;}
            }
        });
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
            WebViewCompat.addWebMessageListener(web,"NodinNative",
                Collections.singleton("https://appassets.androidplatform.net"),
                (view,message,origin,mainFrame,reply)->{
                    if(!mainFrame) return;
                    try{command(new JSONObject(message.getData()));}catch(Exception e){toast("درخواست نامعتبر");}
                });
        }else toast("Android System WebView را به‌روز کنید تا پلیر بومی فعال شود.");
        nativeSpeech=new NativeSpeech(this,web);
        practiceRecorder=new PracticeRecorder(this,web);nativeListening=new NativeListening(this,web);nativeRadioCheck=new NativeRadioCheck(this,web);
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        try {
        SessionToken token=new SessionToken(this,new ComponentName(this,RadioService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try{
                controller=future.get();
                controller.addListener(listener);
                if(pendingPlay!=null){JSONObject p=pendingPlay;pendingPlay=null;play(p);}
                publish();
            }catch(Exception e){toast("اتصال به پلیر ممکن نشد");}
        },command->runOnUiThread(command));
        } catch(Exception e) {
            android.util.Log.e("Nodin", "Radio controller initialization failed", e);
            toast("اتصال به رادیو ممکن نشد؛ بخش آموزشی در دسترس است.");
        }
        keepScreen();
    }
    private boolean pendingNewsTest=false;
    private void command(JSONObject data) {
        String cmd=data.optString("cmd");
        if(cmd.equals("classicProgress")){classicProgress.mutate(data,()->runOnUiThread(()->{publishClassicStatus();if("replace".equals(data.optString("op")) && classicProgress.status().optString("error").isEmpty())web.reload();}));}
        else if(cmd.equals("classicFolder")){chooseClassicFolder();}
        else if(cmd.equals("classicStatus")){publishClassicStatus();}
        else if(cmd.equals("layersHome")){finish();}
        else if(cmd.equals("practiceRecordStart")){
            nativeListening.stop();
            if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){pendingPracticeRecord=true;requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},46);}else practiceRecorder.start();
        }else if(cmd.equals("practiceRecordStop")){
            pendingPracticeRecord=false;
            if(practiceRecorder.finish()){try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/mp4").putExtra(Intent.EXTRA_TITLE,"Nodin-recording-"+System.currentTimeMillis()+".m4a"),47);}catch(Exception e){practiceRecorder.cancel();practiceRecorder.event("انتخاب محل ذخیره ممکن نشد.");}}
        }else if(cmd.equals("practiceRecordCancel")){pendingPracticeRecord=false;practiceRecorder.cancel();}
        else if(cmd.equals("listenStart")){practiceRecorder.cancel();
            String lang=data.optString("language","en-GB");
            if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){pendingListenLanguage=lang;requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},45);}else nativeListening.start(lang);
        }else if(cmd.equals("listenStop")){pendingListenLanguage=null;nativeListening.stop();}
        else if(cmd.equals("radioCheck")){nativeRadioCheck.check(data);}
        else if(cmd.equals("newsRules")){
            NewsRules.save(this,data.optJSONArray("rules"));boolean enabled=NewsRules.active(this);DailyNews.schedule(this,enabled,"all");
            if(enabled&&Build.VERSION.SDK_INT>=33&&!DailyNews.permitted(this))requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},43);
            else if(enabled&&DailyNews.permitted(this))DailyNews.now(this,false);
            publishNewsState();toast("تنظیمات مستقل بخش‌ها ذخیره شد.");
        }else if(cmd.equals("newsTestNotice")){
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){pendingNewsTest=true;requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},43);}
            else if(!DailyNews.permitted(this)){startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
            else {DailyNews.testNotice(this);toast("اعلان آزمایشی ارسال شد.");}publishNewsState();
        }else if(cmd.equals("newsRuleNow")){
            if(!DailyNews.prefs(this).getBoolean("enabled",false)||!DailyNews.permitted(this))toast("ابتدا تنظیمات اعلان را ذخیره و اجازهٔ اعلان را فعال کنید.");
            else{DailyNews.nowForRules(this,data.optString("keys","[]"));toast("بررسی و ارسال بخش‌های انتخاب‌شده آغاز شد.");}
        }else if(cmd.equals("ttsSpeak")){nativeSpeech.speak(data);}
        else if(cmd.equals("ttsStop")){nativeSpeech.stop();}
        else if(cmd.equals("ttsVoices")){nativeSpeech.publishVoices();}
        else if(cmd.equals("ttsSettings")){startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}
        else if(cmd.equals("newsStatus")){publishNewsState();}
        else if(cmd.equals("newsEnable")){
            boolean enabled=data.optBoolean("enabled");if(data.optBoolean("legacy"))NewsRules.save(this,new JSONArray());DailyNews.configure(this,data);DailyNews.schedule(this,enabled,data.optString("category","general"));
            if(enabled && Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},43);
            else if(enabled){DailyNews.now(this,false);toast("اعلان با فاصلهٔ انتخاب‌شدهٔ "+DailyNews.interval(this)+" دقیقه فعال شد؛ زمان نمایش به تنظیمات گوشی بستگی دارد.");}
            publishNewsState();
        }else if(cmd.equals("newsCategory")){if(data.optBoolean("legacy"))NewsRules.save(this,new JSONArray());DailyNews.configure(this,data);DailyNews.schedule(this,DailyNews.prefs(this).getBoolean("enabled",false),data.optString("category","general"));publishNewsState();}
        else if(cmd.equals("newsArchive")){NewsRepository.get(this).ingest(data);}
        else if(cmd.equals("newsRefresh")){DailyNews.now(this,false);toast("به‌روزرسانی همهٔ منابع آغاز شد.");}
        else if(cmd.equals("newsRssExport")){try{saveBytes=NewsRepository.get(this).rss().getBytes(java.nio.charset.StandardCharsets.UTF_8);Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/rss+xml").putExtra(Intent.EXTRA_TITLE,"Nodin-news-10-days.xml");startActivityForResult(save,42);}catch(Exception e){toast("ساخت فایل RSS ممکن نشد.");}}
        else if(cmd.equals("migrationStories")){DailyNews.cacheStories(this,data);}
        else if(cmd.equals("newsPreview")){if(!DailyNews.prefs(this).getBoolean("enabled",false)||!DailyNews.permitted(this))toast("ابتدا اعلان و اجازهٔ نمایش آن را فعال کنید.");else {DailyNews.now(this,true);toast("در حال بررسی خبرهای ارسال‌نشده با تنظیمات انتخاب‌شده.");}}
        else if(cmd.equals("newsSystemSettings")){startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
        else if(cmd.equals("play")){ if(controller==null) pendingPlay=data; else play(data); }
        else if(cmd.equals("stop")){
            pendingPlay=null;
            if(controller!=null){controller.pause();controller.stop();controller.clearMediaItems();}
        }else if(cmd.equals("settings")) settingsDialog();
        else if(cmd.equals("overlay")) requestOverlay();
        else if(cmd.equals("exportStart")){
            exportBuffer=new java.io.ByteArrayOutputStream();
        }else if(cmd.equals("exportChunk")){
            if(exportBuffer==null)return;
            byte[] bytes=android.util.Base64.decode(data.optString("data"),android.util.Base64.DEFAULT);
            if(exportBuffer.size()+bytes.length>32*1024*1024){exportBuffer=null;toast("فایل خروجی بیش از ۳۲ مگابایت است.");return;}
            exportBuffer.write(bytes,0,bytes.length);
        }else if(cmd.equals("exportEnd")){
            if(exportBuffer==null)return;
            saveBytes=exportBuffer.toByteArray();exportBuffer=null;
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,data.optString("name","Nodin-export.json"));
            startActivityForResult(save,42);
        }
    }
    private void publishNewsState(){if(pageReady&&web!=null)web.evaluateJavascript("window.onDailyNewsState && window.onDailyNewsState("+DailyNews.status(this)+");",null);}
    private void openNotificationNews(){Intent intent=getIntent();if(!pageReady||intent==null||!intent.hasExtra("news_title"))return;try{JSONObject o=new JSONObject();for(String key:new String[]{"id","category","title","link","source","published","country","displayTitle","displayBody"})o.put(key,DailyNews.shorten(intent.getStringExtra("news_"+key)==null?"":intent.getStringExtra("news_"+key),600));o.put("desc",DailyNews.shorten(intent.getStringExtra("news_description")==null?"":intent.getStringExtra("news_description"),260));intent.removeExtra("news_title");web.evaluateJavascript("("+o+").category === 'migration' ? window.NodinMigrationNotifications?.open("+o+") : window.NodinHeadlinesApi?.openNotification("+o+");",null);}catch(Exception ignored){}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);openNotificationNews();}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] results){super.onRequestPermissionsResult(req,permissions,results);
        if(req==46){if(pendingPracticeRecord&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==android.content.pm.PackageManager.PERMISSION_GRANTED)practiceRecorder.start();else practiceRecorder.event("اجازه میکروفن داده نشده است.");pendingPracticeRecord=false;}
        if(req==45){if(pendingListenLanguage!=null&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==android.content.pm.PackageManager.PERMISSION_GRANTED)nativeListening.start(pendingListenLanguage);else nativeListening.event("error","اجازهٔ میکروفن داده نشده است.");pendingListenLanguage=null;}
        if(req==44 && locationCallback!=null){boolean allowed=checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)==android.content.pm.PackageManager.PERMISSION_GRANTED || checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)==android.content.pm.PackageManager.PERMISSION_GRANTED;locationCallback.invoke(locationOrigin,allowed,false);locationCallback=null;locationOrigin=null;}
if(req==43){if(pendingNewsTest&&DailyNews.permitted(this)){DailyNews.testNotice(this);}pendingNewsTest=false;if(DailyNews.permitted(this)&&DailyNews.prefs(this).getBoolean("enabled",false))DailyNews.now(this,false);publishNewsState();}}
    private void play(JSONObject data){
        String url=data.optString("url");
        if(!url.startsWith("https://")){toast("این رادیو لینک امن HTTPS ندارد.");return;}
        MediaItem item=new MediaItem.Builder().setMediaId(data.optString("id"))
            .setUri(url).setMediaMetadata(new MediaMetadata.Builder()
            .setTitle(data.optString("title")).setArtist("English with Nodin").build()).build();
        controller.setMediaItem(item); controller.prepare();controller.play();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},41);
        if(prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();
    }
    private void publish(){
        if(!pageReady || controller==null) return;
        try{
            MediaItem item=controller.getCurrentMediaItem();
            JSONObject o=new JSONObject();
            o.put("id",item==null?"":item.mediaId);
            o.put("title",item==null?"":String.valueOf(item.mediaMetadata.title));
            String state=controller.getPlayerError()!=null?"error":
                item==null?"idle":controller.getPlaybackState()==Player.STATE_BUFFERING?"loading":
                controller.isPlaying()?"playing":"paused";
            o.put("state",state);
            web.evaluateJavascript("window.onNativeRadioState && window.onNativeRadioState("+o+");",null);
        }catch(Exception ignored){}
    }
    private void keepScreen(){
        if(prefs.getBoolean("screen",false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void publishClassicStatus(){
        if(web!=null && pageReady)web.evaluateJavascript("window.onClassicBackupStatus && window.onClassicBackupStatus("+classicProgress.status()+");",null);
    }
    private void offerClassicFolder(){
        if(!classicProgress.snapshot().optBoolean("folder") && !prefs.getBoolean("classicFolderOffered",false)){
            prefs.edit().putBoolean("classicFolderOffered",true).apply();
            new AlertDialog.Builder(this).setTitle("ذخیره یادگیری در bcnodin")
                .setMessage("در پنجره بعدی حافظه اصلی گوشی را باز کنید و پوشه bcnodin را انتخاب کنید. اگر وجود ندارد با گزینه پوشه جدید آن را بسازید. انتخاب پوشه یک‌بار لازم است؛ بعد از آن ذخیره و بازیابی خودکار خواهد بود. اطلاعات داخل نسخه‌های قدیمی فقط با پشتیبان همان نسخه قابل انتقال است.")
                .setPositiveButton("انتخاب bcnodin",(d,w)->chooseClassicFolder()).setNegativeButton("بعداً",null).show();
        }
    }
    private void chooseClassicFolder(){
        try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            .putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI,android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents","primary:bcnodin"))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION),49);}
        catch(Exception e){toast("پنجره انتخاب پوشه در دسترس نیست.");}
    }
    private void settingsDialog(){
        String[] names={"روشن نگه‌داشتن صفحه هنگام استفاده از برنامه","رادیوی شناور روی برنامه‌های دیگر"};
        boolean[] values={prefs.getBoolean("screen",false),prefs.getBoolean("overlay",false)};
        new AlertDialog.Builder(this).setTitle("تنظیمات اندروید")
            .setMultiChoiceItems(names,values,(d,n,checked)->{
                prefs.edit().putBoolean(n==0?"screen":"overlay",checked).apply();
                if(n==0) keepScreen();
                else if(checked) requestOverlay();
                else overlayCommand();
            }).setPositiveButton("بستن",null).show();
    }
    private void requestOverlay(){
        prefs.edit().putBoolean("overlay",true).apply();
        if(!Settings.canDrawOverlays(this)){
            new AlertDialog.Builder(this).setMessage("برای نمایش دکمهٔ رادیو روی برنامه‌های دیگر، اجازهٔ نمایش روی سایر برنامه‌ها را فعال کنید.")
                .setPositiveButton("بازکردن تنظیمات",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))))
                .setNegativeButton("فعلاً نه",(d,w)->prefs.edit().putBoolean("overlay",false).apply()).show();
        }else if(controller!=null && controller.getCurrentMediaItem()!=null) overlayCommand();
        else toast("ابتدا یک رادیو را پخش کنید؛ سپس دکمهٔ شناور ظاهر می‌شود.");
    }
    private void overlayCommand(){
        if(controller!=null && controller.getCurrentMediaItem()!=null)
            startService(new Intent(this,RadioService.class).setAction("overlay"));
    }
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();keepScreen();if(nativeSpeech!=null&&nativeSpeech.needsRetry()){nativeSpeech.close();nativeSpeech=new NativeSpeech(this,web);}if(web!=null){web.onResume();publish();publishNewsState();}if(prefs!=null && prefs.getBoolean("overlay",false) && Settings.canDrawOverlays(this)) overlayCommand();}
    @Override protected void onPause(){super.onPause();if(web!=null) web.onPause(); /* native radio stays in service */}
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==49){
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();
                try{getContentResolver().takePersistableUriPermission(uri,data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
                    web.stopLoading();classicProgress.bind(uri,ok->runOnUiThread(()->{if(ok){toast("bcnodin متصل شد؛ پیشرفت موجود خودکار بازخوانی می‌شود.");web.reload();}else{publishClassicStatus();toast(classicProgress.snapshot().optString("error"));}}));
                }catch(Exception e){toast("دسترسی پوشه ذخیره نشد؛ دوباره bcnodin را انتخاب کنید.");}
            }else toast("فعلاً فقط ذخیره داخلی فعال است.");return;
        }
        if(req==47){if(result==RESULT_OK&&data!=null&&data.getData()!=null)practiceRecorder.export(data.getData());else{practiceRecorder.cancel();practiceRecorder.event("ذخیره لغو شد.");}return;}
        if(req==42 && saveBytes!=null){
            byte[] bytes=saveBytes;saveBytes=null;
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();
                new Thread(()->{
                    try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){
                        if(out==null)throw new java.io.IOException();out.write(bytes);
                        runOnUiThread(()->toast("فایل ذخیره شد."));
                    }catch(Exception e){runOnUiThread(()->toast("ذخیرهٔ فایل انجام نشد."));}
                }).start();
            }
        }
        if(req==40 && fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}
    }
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onStop(){super.onStop();pendingPracticeRecord=false;if(practiceRecorder!=null)practiceRecorder.cancelActive();pendingListenLanguage=null;if(nativeListening!=null)nativeListening.stop();if(nativeRadioCheck!=null)nativeRadioCheck.cancel();}
    @Override protected void onDestroy(){
        if(nativeListening!=null)nativeListening.stop();if(nativeRadioCheck!=null)nativeRadioCheck.cancel();
        if(controller!=null)controller.removeListener(listener);
        if(future!=null)MediaController.releaseFuture(future);
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        if(nativeSpeech!=null)nativeSpeech.close();
        web.destroy();super.onDestroy();
    }
}
