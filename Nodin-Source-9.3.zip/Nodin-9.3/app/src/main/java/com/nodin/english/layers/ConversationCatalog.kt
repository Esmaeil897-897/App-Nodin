package com.nodin.english.layers
/** Original authored practice dialogues. Level labels are approximate, not certification. */
object ConversationCatalog {
 val dialogues=listOf(
  Dialogue("progressive_cafe_A1","سفارش ساده در کافه","A1",listOf(
   DialogueLine(DialogueRole.APP,"Hello.","سلام.","cafe"),
   DialogueLine(DialogueRole.USER,"Hello.","سلام.","cafe"),
   DialogueLine(DialogueRole.APP,"What would you like?","چه میل دارید؟","cafe"),
   DialogueLine(DialogueRole.USER,"A tea, please.","یک چای، لطفاً.","cafe"),
   DialogueLine(DialogueRole.APP,"Would you like milk?","شیر می‌خواهید؟","cafe"),
   DialogueLine(DialogueRole.USER,"Yes, please.","بله، لطفاً.","cafe"),
   DialogueLine(DialogueRole.APP,"That is two pounds.","دو پوند می‌شود.","cafe"),
   DialogueLine(DialogueRole.USER,"Here you are.","بفرمایید.","cafe")
  )),
  Dialogue("progressive_travel_A1","پرسیدن مسیر","A1",listOf(
   DialogueLine(DialogueRole.APP,"Can I help you?","می‌توانم کمک کنم؟","map"),
   DialogueLine(DialogueRole.USER,"Where is the station?","ایستگاه کجاست؟","map"),
   DialogueLine(DialogueRole.APP,"Go straight ahead.","مستقیم بروید.","map"),
   DialogueLine(DialogueRole.USER,"Is it far?","دور است؟","map"),
   DialogueLine(DialogueRole.APP,"No, it is near the park.","نه، نزدیک پارک است.","map"),
   DialogueLine(DialogueRole.USER,"Thank you for your help.","از کمکتان ممنونم.","map"),
   DialogueLine(DialogueRole.APP,"You are welcome.","خواهش می‌کنم.","map"),
   DialogueLine(DialogueRole.USER,"Have a nice day.","روز خوبی داشته باشید.","map")
  )),
  Dialogue("progressive_work_A1","معرفی در محل کار","A1",listOf(
   DialogueLine(DialogueRole.APP,"Hello, I am Sam.","سلام، من سم هستم.","work"),
   DialogueLine(DialogueRole.USER,"Hi, my name is Esmaeil.","سلام، نام من اسماعیل است.","work"),
   DialogueLine(DialogueRole.APP,"Is this your first day?","این اولین روز شماست؟","work"),
   DialogueLine(DialogueRole.USER,"Yes, it is.","بله.","work"),
   DialogueLine(DialogueRole.APP,"We start at nine.","ساعت نه شروع می‌کنیم.","work"),
   DialogueLine(DialogueRole.USER,"Where is the office?","دفتر کجاست؟","work"),
   DialogueLine(DialogueRole.APP,"It is on the left.","سمت چپ است.","work"),
   DialogueLine(DialogueRole.USER,"Thank you, Sam.","ممنونم، سم.","work")
  )),
  Dialogue("progressive_cafe_A2","تغییر سفارش","A2",listOf(
   DialogueLine(DialogueRole.APP,"What can I get you today?","امروز چه چیزی برایتان بیاورم؟","cafe"),
   DialogueLine(DialogueRole.USER,"I would like a coffee and a sandwich, please.","یک قهوه و یک ساندویچ می‌خواهم، لطفاً.","cafe"),
   DialogueLine(DialogueRole.APP,"Would you like your coffee hot or iced?","قهوه را گرم می‌خواهید یا سرد؟","cafe"),
   DialogueLine(DialogueRole.USER,"Hot, please, but without sugar.","گرم، لطفاً، اما بدون شکر.","cafe"),
   DialogueLine(DialogueRole.APP,"We have cheese or chicken sandwiches.","ساندویچ پنیر یا مرغ داریم.","cafe"),
   DialogueLine(DialogueRole.USER,"Can I have the cheese sandwich?","می‌توانم ساندویچ پنیر بگیرم؟","cafe"),
   DialogueLine(DialogueRole.APP,"Of course, would you like to eat here?","البته، می‌خواهید اینجا بخورید؟","cafe"),
   DialogueLine(DialogueRole.USER,"No, I would like to take it away.","نه، می‌خواهم آن را ببرم.","cafe")
  )),
  Dialogue("progressive_travel_A2","خرید بلیت رفت‌وبرگشت","A2",listOf(
   DialogueLine(DialogueRole.APP,"Where would you like to travel?","کجا می‌خواهید سفر کنید؟","train"),
   DialogueLine(DialogueRole.USER,"I need a return ticket to Birmingham.","یک بلیت رفت‌وبرگشت به بیرمنگام نیاز دارم.","train"),
   DialogueLine(DialogueRole.APP,"When are you coming back?","چه زمانی برمی‌گردید؟","train"),
   DialogueLine(DialogueRole.USER,"This evening, after six o’clock.","امشب، بعد از ساعت شش.","train"),
   DialogueLine(DialogueRole.APP,"The next train leaves in twenty minutes.","قطار بعدی بیست دقیقه دیگر حرکت می‌کند.","train"),
   DialogueLine(DialogueRole.USER,"Which platform does it leave from?","از کدام سکو حرکت می‌کند؟","train"),
   DialogueLine(DialogueRole.APP,"Platform three, next to the stairs.","سکوی سه، کنار پله‌ها.","train"),
   DialogueLine(DialogueRole.USER,"Can I pay by card?","می‌توانم با کارت پرداخت کنم؟","train")
  )),
  Dialogue("progressive_work_A2","هماهنگی شیفت","A2",listOf(
   DialogueLine(DialogueRole.APP,"Are you available on Saturday?","شنبه در دسترس هستید؟","clock"),
   DialogueLine(DialogueRole.USER,"Yes, but only in the afternoon.","بله، اما فقط بعدازظهر.","clock"),
   DialogueLine(DialogueRole.APP,"Can you start at two o’clock?","می‌توانید ساعت دو شروع کنید؟","clock"),
   DialogueLine(DialogueRole.USER,"Yes, what time does the shift finish?","بله، شیفت چه ساعتی تمام می‌شود؟","clock"),
   DialogueLine(DialogueRole.APP,"It finishes at seven.","ساعت هفت تمام می‌شود.","clock"),
   DialogueLine(DialogueRole.USER,"Do I need to bring anything?","لازم است چیزی بیاورم؟","clock"),
   DialogueLine(DialogueRole.APP,"Please bring your uniform and name badge.","لطفاً لباس کار و کارت نامتان را بیاورید.","clock"),
   DialogueLine(DialogueRole.USER,"All right, I will see you on Saturday.","بسیار خوب، شنبه می‌بینمتان.","clock")
  )),
  Dialogue("progressive_cafe_B1","حل اشتباه در سفارش","B1",listOf(
   DialogueLine(DialogueRole.APP,"Is everything all right with your order?","همه چیز در سفارشتان درست است؟","cafe"),
   DialogueLine(DialogueRole.USER,"I ordered a decaffeinated coffee, but this tastes different.","قهوه بدون کافئین سفارش دادم، اما طعم این متفاوت است.","cafe"),
   DialogueLine(DialogueRole.APP,"Let me check the receipt for you.","اجازه دهید رسید را برایتان بررسی کنم.","cafe"),
   DialogueLine(DialogueRole.USER,"Thank you, I cannot drink regular coffee in the evening.","ممنونم، عصرها نمی‌توانم قهوه معمولی بنوشم.","cafe"),
   DialogueLine(DialogueRole.APP,"You are right, we made a mistake.","حق با شماست، اشتباه کردیم.","cafe"),
   DialogueLine(DialogueRole.USER,"Could you replace it with a decaffeinated one?","می‌توانید آن را با قهوه بدون کافئین عوض کنید؟","cafe"),
   DialogueLine(DialogueRole.APP,"Certainly, it will only take a few minutes.","حتماً، فقط چند دقیقه زمان می‌برد.","cafe"),
   DialogueLine(DialogueRole.USER,"That is fine, I appreciate your help.","اشکالی ندارد، از کمکتان قدردانی می‌کنم.","cafe")
  )),
  Dialogue("progressive_travel_B1","تغییر برنامه سفر","B1",listOf(
   DialogueLine(DialogueRole.APP,"Your train has been cancelled because of a signalling problem.","قطارتان به دلیل مشکل علائم لغو شده است.","train"),
   DialogueLine(DialogueRole.USER,"I have a connection in Birmingham, so what are my options?","در بیرمنگام باید قطار عوض کنم، پس چه گزینه‌هایی دارم؟","train"),
   DialogueLine(DialogueRole.APP,"You could take the next service in forty minutes.","می‌توانید قطار بعدی را چهل دقیقه دیگر سوار شوید.","train"),
   DialogueLine(DialogueRole.USER,"Will my original ticket still be valid?","بلیت اصلی من همچنان معتبر است؟","train"),
   DialogueLine(DialogueRole.APP,"Yes, it will be accepted on the later service.","بله، در قطار بعدی پذیرفته می‌شود.","train"),
   DialogueLine(DialogueRole.USER,"Is there a faster route by bus?","مسیر سریع‌تری با اتوبوس هست؟","train"),
   DialogueLine(DialogueRole.APP,"The replacement bus takes longer than the train.","اتوبوس جایگزین از قطار بیشتر طول می‌کشد.","train"),
   DialogueLine(DialogueRole.USER,"In that case, I will wait for the next train.","در این صورت، منتظر قطار بعدی می‌مانم.","train")
  )),
  Dialogue("progressive_work_B1","بازخورد و درخواست آموزش","B1",listOf(
   DialogueLine(DialogueRole.APP,"How are you finding your new responsibilities?","مسئولیت‌های جدید را چطور می‌بینید؟","work"),
   DialogueLine(DialogueRole.USER,"I am comfortable with most tasks, but the booking system is difficult.","با بیشتر کارها راحت هستم، اما سیستم رزرو دشوار است.","work"),
   DialogueLine(DialogueRole.APP,"Which part is causing the problem?","کدام بخش مشکل ایجاد می‌کند؟","work"),
   DialogueLine(DialogueRole.USER,"I am not sure how to change a booking without deleting it.","مطمئن نیستم چگونه رزرو را بدون حذف کردن تغییر دهم.","work"),
   DialogueLine(DialogueRole.APP,"Would another training session help?","یک جلسه آموزشی دیگر کمک می‌کند؟","work"),
   DialogueLine(DialogueRole.USER,"Yes, especially if we could practise with a real example.","بله، به‌خصوص اگر با یک مثال واقعی تمرین کنیم.","work"),
   DialogueLine(DialogueRole.APP,"We can arrange that for tomorrow morning.","می‌توانیم آن را برای فردا صبح هماهنگ کنیم.","work"),
   DialogueLine(DialogueRole.USER,"Thank you, I think that would make a big difference.","ممنونم، فکر می‌کنم تأثیر زیادی خواهد داشت.","work")
  )),
  Dialogue("progressive_cafe_B2","رسیدگی مؤدبانه به شکایت","B2",listOf(
   DialogueLine(DialogueRole.APP,"I understand you would like to speak to the manager.","متوجه‌ام که می‌خواهید با مدیر صحبت کنید.","cafe"),
   DialogueLine(DialogueRole.USER,"Yes, the service has been slower than we expected.","بله، خدمات کندتر از انتظار ما بوده است.","cafe"),
   DialogueLine(DialogueRole.APP,"I apologise, we have had an unusually busy afternoon.","عذرخواهی می‌کنم، بعدازظهر به‌طور غیرمعمولی شلوغ بوده است.","cafe"),
   DialogueLine(DialogueRole.USER,"I appreciate that, but we were not told about the delay.","این را درک می‌کنم، اما درباره تأخیر به ما اطلاع داده نشد.","cafe"),
   DialogueLine(DialogueRole.APP,"What would be a fair way to put this right?","چه راه منصفانه‌ای برای جبران این مشکل وجود دارد؟","cafe"),
   DialogueLine(DialogueRole.USER,"A clear update and a refund for the missing item would help.","اطلاع‌رسانی روشن و بازپرداخت مبلغ کالای نرسیده کمک می‌کند.","cafe"),
   DialogueLine(DialogueRole.APP,"I can arrange both and check the rest of your order.","می‌توانم هر دو را انجام دهم و بقیه سفارش را بررسی کنم.","cafe"),
   DialogueLine(DialogueRole.USER,"Thank you for taking the complaint seriously.","ممنونم که شکایت را جدی گرفتید.","cafe")
  )),
  Dialogue("progressive_travel_B2","انتخاب میان هزینه و زمان","B2",listOf(
   DialogueLine(DialogueRole.APP,"The direct route is faster, but it costs considerably more.","مسیر مستقیم سریع‌تر است، اما هزینه بسیار بیشتری دارد.","map"),
   DialogueLine(DialogueRole.USER,"I would rather save money unless the slower route is unreliable.","ترجیح می‌دهم پول ذخیره کنم، مگر اینکه مسیر کندتر قابل اعتماد نباشد.","map"),
   DialogueLine(DialogueRole.APP,"It involves a transfer with a short connection time.","نیاز به تعویض وسیله با زمان اتصال کوتاه دارد.","map"),
   DialogueLine(DialogueRole.USER,"What happens if the first service is delayed?","اگر سرویس اول تأخیر کند چه می‌شود؟","map"),
   DialogueLine(DialogueRole.APP,"You may have to wait an hour for the following connection.","ممکن است یک ساعت برای اتصال بعدی منتظر بمانید.","map"),
   DialogueLine(DialogueRole.USER,"That risk seems too high because I have an appointment.","این ریسک زیاد به نظر می‌رسد، چون وقت ملاقات دارم.","map"),
   DialogueLine(DialogueRole.APP,"Would you prefer the more expensive direct ticket?","بلیت مستقیم گران‌تر را ترجیح می‌دهید؟","map"),
   DialogueLine(DialogueRole.USER,"Yes, the extra cost is worth the peace of mind.","بله، هزینه اضافی ارزش آرامش خاطر را دارد.","map")
  )),
  Dialogue("progressive_work_B2","مذاکره درباره مهلت پروژه","B2",listOf(
   DialogueLine(DialogueRole.APP,"Can your team deliver the full report by Friday?","تیم شما می‌تواند گزارش کامل را تا جمعه تحویل دهد؟","work"),
   DialogueLine(DialogueRole.USER,"We can deliver a draft, but the final analysis needs more time.","می‌توانیم پیش‌نویس را تحویل دهیم، اما تحلیل نهایی زمان بیشتری نیاز دارد.","work"),
   DialogueLine(DialogueRole.APP,"The client is expecting a complete version.","مشتری انتظار نسخه کامل را دارد.","work"),
   DialogueLine(DialogueRole.USER,"Could we agree on an interim summary followed by the full report?","می‌توانیم روی خلاصه موقت و سپس گزارش کامل توافق کنیم؟","work"),
   DialogueLine(DialogueRole.APP,"How would that affect the overall schedule?","این موضوع چگونه بر برنامه کلی تأثیر می‌گذارد؟","work"),
   DialogueLine(DialogueRole.USER,"The summary would meet the immediate need without compromising accuracy.","خلاصه نیاز فوری را برطرف می‌کند، بدون اینکه دقت کاهش یابد.","work"),
   DialogueLine(DialogueRole.APP,"That sounds reasonable, provided the final date is clear.","منطقی به نظر می‌رسد، به شرط اینکه تاریخ نهایی روشن باشد.","work"),
   DialogueLine(DialogueRole.USER,"I will confirm the revised milestones in writing today.","امروز مراحل اصلاح‌شده را به‌صورت کتبی تأیید می‌کنم.","work")
  )),
  Dialogue("progressive_cafe_C1","مدیریت خدمات و کیفیت","C1",listOf(
   DialogueLine(DialogueRole.APP,"How would you balance efficiency with a personalised customer experience?","چگونه سرعت کار را با تجربه شخصی مشتری متعادل می‌کنید؟","cafe"),
   DialogueLine(DialogueRole.USER,"I would standardise routine tasks while allowing staff discretion in unusual situations.","کارهای معمول را استاندارد می‌کنم و در شرایط غیرمعمول به کارکنان اختیار می‌دهم.","cafe"),
   DialogueLine(DialogueRole.APP,"Would that introduce inconsistency across different shifts?","این کار بین شیفت‌های مختلف ناهماهنگی ایجاد نمی‌کند؟","cafe"),
   DialogueLine(DialogueRole.USER,"Possibly, which is why clear principles matter more than rigid scripts.","ممکن است، به همین دلیل اصول روشن از متن‌های ثابت مهم‌ترند.","cafe"),
   DialogueLine(DialogueRole.APP,"How would you measure whether the approach was working?","چگونه میزان موفقیت این روش را اندازه می‌گیرید؟","cafe"),
   DialogueLine(DialogueRole.USER,"I would combine response times with customer feedback and repeat visits.","زمان پاسخ‌گویی را با بازخورد مشتری و مراجعات دوباره ترکیب می‌کنم.","cafe"),
   DialogueLine(DialogueRole.APP,"What if those indicators pointed in different directions?","اگر این شاخص‌ها نتایج متفاوتی نشان دهند چه می‌کنید؟","cafe"),
   DialogueLine(DialogueRole.USER,"I would investigate the underlying causes before drawing a firm conclusion.","پیش از نتیجه‌گیری قطعی، دلایل اصلی را بررسی می‌کنم.","cafe")
  )),
  Dialogue("progressive_travel_C1","گفت‌وگو درباره گردشگری پایدار","C1",listOf(
   DialogueLine(DialogueRole.APP,"Should cities limit visitor numbers to protect local communities?","آیا شهرها برای محافظت از مردم محلی باید تعداد گردشگران را محدود کنند؟","tree"),
   DialogueLine(DialogueRole.USER,"Restrictions may help, but they should be proportionate to the actual pressure on infrastructure.","محدودیت‌ها می‌توانند کمک کنند، اما باید متناسب با فشار واقعی بر زیرساخت باشند.","tree"),
   DialogueLine(DialogueRole.APP,"Would higher tourist taxes be a more effective alternative?","آیا مالیات بیشتر گردشگری جایگزین مؤثرتری است؟","tree"),
   DialogueLine(DialogueRole.USER,"Only if the revenue is transparently reinvested in services residents use.","فقط اگر درآمد به‌صورت شفاف در خدمات مورد استفاده ساکنان سرمایه‌گذاری شود.","tree"),
   DialogueLine(DialogueRole.APP,"How could policy avoid excluding visitors on modest incomes?","چگونه سیاست می‌تواند گردشگران کم‌درآمد را محروم نکند؟","tree"),
   DialogueLine(DialogueRole.USER,"Off-peak incentives could spread demand without relying entirely on higher prices.","مشوق‌های زمان خلوت می‌توانند تقاضا را پخش کنند، بدون اتکای کامل به قیمت بالاتر.","tree"),
   DialogueLine(DialogueRole.APP,"Is there enough evidence to support that approach?","آیا شواهد کافی برای حمایت از این روش وجود دارد؟","tree"),
   DialogueLine(DialogueRole.USER,"Pilot schemes would allow authorities to assess the impact before wider implementation.","طرح‌های آزمایشی به مسئولان اجازه می‌دهند پیش از اجرای گسترده تأثیر را ارزیابی کنند.","tree")
  )),
  Dialogue("progressive_work_C1","مدیریت اختلاف در جلسه","C1",listOf(
   DialogueLine(DialogueRole.APP,"Your recommendation differs substantially from the finance team’s proposal.","توصیه شما با پیشنهاد تیم مالی تفاوت زیادی دارد.","work"),
   DialogueLine(DialogueRole.USER,"I recognise their concerns, although our assessment gives greater weight to long-term resilience.","نگرانی‌هایشان را می‌پذیرم، هرچند ارزیابی ما به پایداری بلندمدت اهمیت بیشتری می‌دهد.","work"),
   DialogueLine(DialogueRole.APP,"Are you suggesting their assumptions are unreliable?","منظورتان این است که فرض‌های آن‌ها قابل اعتماد نیست؟","work"),
   DialogueLine(DialogueRole.USER,"Not necessarily, but some assumptions may no longer reflect current operating conditions.","لزوماً نه، اما بعضی فرض‌ها شاید دیگر شرایط عملیاتی فعلی را منعکس نکنند.","work"),
   DialogueLine(DialogueRole.APP,"How do you propose we resolve the disagreement?","چگونه پیشنهاد می‌کنید اختلاف را حل کنیم؟","work"),
   DialogueLine(DialogueRole.USER,"We could test both models against the same scenarios and make the trade-offs explicit.","می‌توانیم هر دو مدل را با سناریوهای یکسان آزمایش و بده‌بستان‌ها را روشن کنیم.","work"),
   DialogueLine(DialogueRole.APP,"Would you be willing to revise your recommendation?","حاضرید توصیه خود را تغییر دهید؟","work"),
   DialogueLine(DialogueRole.USER,"Absolutely, provided the revised evidence supports a different course of action.","حتماً، به شرط اینکه شواهد جدید از مسیر متفاوتی حمایت کنند.","work")
  )),
  Dialogue("progressive_cafe_C2","مذاکره حرفه‌ای قرارداد خدمات","C2",listOf(
   DialogueLine(DialogueRole.APP,"The proposed agreement places most of the operational risk on our side.","توافق پیشنهادی بیشتر ریسک عملیاتی را بر دوش ما می‌گذارد.","work"),
   DialogueLine(DialogueRole.USER,"I take your point, although the allocation reflects the degree of control each party retains.","نکته شما را می‌فهمم، هرچند تقسیم ریسک میزان کنترل هر طرف را منعکس می‌کند.","work"),
   DialogueLine(DialogueRole.APP,"Control alone does not account for circumstances beyond either party’s influence.","کنترل به‌تنهایی شرایط خارج از اختیار هر دو طرف را در نظر نمی‌گیرد.","work"),
   DialogueLine(DialogueRole.USER,"Then perhaps we should distinguish avoidable failures from genuinely exceptional disruptions.","پس شاید باید شکست‌های قابل پیشگیری را از اختلالات واقعاً استثنایی جدا کنیم.","work"),
   DialogueLine(DialogueRole.APP,"How would you express that distinction without creating ambiguous exceptions?","چگونه این تفاوت را بدون ایجاد استثناهای مبهم بیان می‌کنید؟","work"),
   DialogueLine(DialogueRole.USER,"We could define measurable thresholds and require independent verification before any exemption applies.","می‌توانیم حدهای قابل اندازه‌گیری تعریف کنیم و پیش از هر معافیت تأیید مستقل بخواهیم.","work"),
   DialogueLine(DialogueRole.APP,"That would be acceptable if the review process remained proportionate.","اگر فرایند بررسی متناسب باقی بماند، این پذیرفتنی است.","work"),
   DialogueLine(DialogueRole.USER,"Agreed, let us document the criteria and include a mechanism for resolving borderline cases.","موافقم، معیارها را ثبت کنیم و سازوکاری برای حل موارد مرزی بگنجانیم.","work")
  )),
  Dialogue("progressive_travel_C2","بحث پیشرفته درباره زیرساخت سفر","C2",listOf(
   DialogueLine(DialogueRole.APP,"Investment decisions often favour visible expansion over less conspicuous maintenance.","تصمیم‌های سرمایه‌گذاری اغلب توسعه قابل مشاهده را به نگهداری کمتر نمایان ترجیح می‌دهند.","train"),
   DialogueLine(DialogueRole.USER,"That tendency is understandable politically, but it can obscure the cumulative cost of deferred repairs.","این گرایش از نظر سیاسی قابل فهم است، اما هزینه تجمعی تعمیرات عقب‌افتاده را پنهان می‌کند.","train"),
   DialogueLine(DialogueRole.APP,"Would a separate maintenance budget prevent that distortion?","بودجه جداگانه نگهداری جلوی این انحراف را می‌گیرد؟","train"),
   DialogueLine(DialogueRole.USER,"It might protect essential spending, though a ring-fenced budget is no substitute for accountable planning.","ممکن است از هزینه‌های ضروری محافظت کند، اما بودجه اختصاصی جای برنامه‌ریزی پاسخ‌گو را نمی‌گیرد.","train"),
   DialogueLine(DialogueRole.APP,"How should uncertainty about future demand influence present commitments?","عدم قطعیت تقاضای آینده چگونه باید بر تعهدات فعلی اثر بگذارد؟","train"),
   DialogueLine(DialogueRole.USER,"A phased approach preserves flexibility while ensuring that critical bottlenecks are addressed promptly.","رویکرد مرحله‌ای انعطاف را حفظ می‌کند و رسیدگی سریع به گلوگاه‌های مهم را تضمین می‌کند.","train"),
   DialogueLine(DialogueRole.APP,"Critics might regard that as an excuse for indecision.","منتقدان شاید آن را بهانه‌ای برای بلاتکلیفی بدانند.","train"),
   DialogueLine(DialogueRole.USER,"Only if the phases lack explicit triggers, transparent evaluation and a credible timetable.","فقط وقتی مراحل فاقد محرک روشن، ارزیابی شفاف و جدول زمانی معتبر باشند.","train")
  )),
  Dialogue("progressive_work_C2","دفاع دقیق از تصمیم راهبردی","C2",listOf(
   DialogueLine(DialogueRole.APP,"The board is concerned that your strategy depends on an optimistic interpretation of the evidence.","هیئت‌مدیره نگران است که راهبرد شما به برداشتی خوش‌بینانه از شواهد وابسته باشد.","work"),
   DialogueLine(DialogueRole.USER,"The recommendation is conditional rather than categorical, and the downside scenarios are explicitly modelled.","توصیه مشروط است، نه مطلق، و سناریوهای نامطلوب صریحاً مدل‌سازی شده‌اند.","work"),
   DialogueLine(DialogueRole.APP,"Even so, the assumptions could reinforce one another and conceal systemic risk.","با این حال، فرض‌ها می‌توانند یکدیگر را تقویت کنند و ریسک سیستماتیک را پنهان سازند.","work"),
   DialogueLine(DialogueRole.USER,"That is why we stress-tested correlated failures instead of treating each variable in isolation.","به همین دلیل شکست‌های هم‌بسته را آزمودیم، به‌جای بررسی جداگانه هر متغیر.","work"),
   DialogueLine(DialogueRole.APP,"What would persuade you to abandon the proposal?","چه چیزی شما را به کنار گذاشتن پیشنهاد متقاعد می‌کند؟","work"),
   DialogueLine(DialogueRole.USER,"A sustained breach of the agreed indicators would trigger a reassessment before further capital was committed.","عبور پایدار از حدود شاخص‌های توافق‌شده، پیش از تخصیص سرمایه بیشتر بازبینی را فعال می‌کند.","work"),
   DialogueLine(DialogueRole.APP,"Can you state the central trade-off without relying on technical language?","می‌توانید بده‌بستان اصلی را بدون زبان تخصصی بیان کنید؟","work"),
   DialogueLine(DialogueRole.USER,"We are accepting a limited short-term exposure in exchange for greater adaptability, with clear conditions for withdrawal.","ریسک کوتاه‌مدت محدودی را در برابر سازگاری بیشتر می‌پذیریم، با شرایط روشن برای عقب‌نشینی.","work")
  ))
 )
}
