package com.nodin.english;

import android.content.Context;
import android.net.Uri;
import android.util.AtomicFile;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Private durable copy plus user-granted bcnodin copy. No broad storage permission. */
public final class ClassicProgressStore {
    private static ClassicProgressStore instance;
    public static synchronized ClassicProgressStore get(Context c) {
        if(instance==null) instance=new ClassicProgressStore(c.getApplicationContext());
        return instance;
    }
    private static final int MAX=32*1024*1024;
    private static final String[] FILES={"classic-progress-a.json","classic-progress-b.json"};
    private final Context context;
    private final AtomicFile file;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private JSONObject values=new JSONObject();
    private long revision=0;
    private boolean initialized=false;
    private String epoch=UUID.randomUUID().toString(),lineage=UUID.randomUUID().toString();
    private String error="",savedAt="";
    private Uri tree;
    ClassicProgressStore(Context c) {
        context=c;file=new AtomicFile(new File(c.getFilesDir(),"classic-progress.json"));
        JSONObject local=null;
        try{local=decode(read(file.openRead()));}catch(Exception ignored){}
        if(local!=null) adopt(local);
        String uri=c.getSharedPreferences("classic_backup",0).getString("tree","");
        if(!uri.isEmpty()) {
            tree=Uri.parse(uri);
            try {
                JSONObject shared=readShared();
                if(shared!=null && (!initialized || (lineage.equals(shared.getString("lineage")) && shared.getLong("revision")>revision))) {
                    adopt(shared);writePrivate();
                }
            } catch(Exception e){error="دسترسی به bcnodin برقرار نیست؛ نسخه داخلی حفظ شده است.";}
        }
    }
    public static boolean tracked(String k) {
        return k!=null && (k.startsWith("fse:") || k.startsWith("fse_") ||
            k.startsWith("thProgress") || k.startsWith("thDailyGoal") || k.startsWith("thSmartLearn") ||
            k.startsWith("nodin:heard:"));
    }
    public synchronized JSONObject snapshot() {
        JSONObject o=new JSONObject();try {
            o.put("initialized",initialized);o.put("epoch",epoch);o.put("values",new JSONObject(values.toString()));
            o.put("revision",revision);o.put("folder",tree!=null);o.put("savedAt",savedAt);o.put("error",error);
        }catch(Exception ignored){} return o;
    }
    public synchronized JSONObject status() {
        JSONObject o=new JSONObject();try {o.put("folder",tree!=null);o.put("savedAt",savedAt);o.put("error",error);}catch(Exception ignored){}return o;
    }
    public void mutate(JSONObject command,Runnable done) {
        io.execute(()->{
            try {
                synchronized(this) {
                    if(!epoch.equals(command.optString("epoch"))) return;
                    String op=command.optString("op");
                    if(op.equals("seed")) {
                        if(initialized)return;
                        values=validatedValues(command.getJSONObject("values"));initialized=true;
                    } else if(op.equals("replace")) {
                        values=validatedValues(command.getJSONObject("values"));initialized=true;
                    } else if(op.equals("set")) {
                        String key=command.getString("key");if(!tracked(key))return;
                        values.put(key,command.getString("value"));initialized=true;
                    } else if(op.equals("remove")) {
                        String key=command.getString("key");if(!tracked(key))return;
                        values.remove(key);initialized=true;
                    } else if(op.equals("clear")) {values=new JSONObject();initialized=true;}
                    else return;
                    revision++;savedAt=java.time.Instant.now().toString();
                    writePrivate();
                    if(tree!=null) writeShared();
                    error="";
                }
            }catch(Exception e){synchronized(this){error="ذخیره پشتیبان کامل نشد؛ فضای گوشی و دسترسی bcnodin را بررسی کنید.";}}
            finally {if(done!=null)done.run();}
        });
    }
    public void bind(Uri uri,java.util.function.Consumer<Boolean> done) {
        io.execute(()->{
            boolean ok=false;
            synchronized(this) {
                Uri old=tree;tree=uri;
                try {
                    DocumentFile folder=folder();
                    if(!"bcnodin".equals(folder.getName())) throw new IOException("Select bcnodin");
                    JSONObject existing=readShared();
                    // Existing folder data wins on first binding; never overwrite it with new defaults.
                    if(existing!=null && (!initialized || !lineage.equals(existing.getString("lineage")) || existing.getLong("revision")>revision)) {adopt(existing);epoch=UUID.randomUUID().toString();}
                    writePrivate();if(initialized)writeShared();
                    if(!context.getSharedPreferences("classic_backup",0).edit().putString("tree",uri.toString()).commit())throw new IOException();
                    error="";ok=true;
                }catch(Exception e){tree=old;error="پوشه bcnodin انتخاب نشد یا فایل آن معتبر نیست؛ اطلاعات موجود بازنویسی نشد.";}
            }
            done.accept(ok);
        });
    }
    private DocumentFile folder() throws IOException {
        DocumentFile f=tree==null?null:DocumentFile.fromTreeUri(context,tree);
        if(f==null || !f.exists() || !f.isDirectory() || !f.canRead() || !f.canWrite())throw new IOException();
        return f;
    }
    private JSONObject readShared() throws Exception {
        DocumentFile f=folder();JSONObject best=null;boolean present=false;
        for(String name:FILES) {
            DocumentFile d=f.findFile(name);if(d==null)continue;present=true;
            try(InputStream in=context.getContentResolver().openInputStream(d.getUri())) {
                JSONObject candidate=decode(read(in));
                if(best==null || candidate.getLong("revision")>best.getLong("revision"))best=candidate;
            }catch(Exception ignored){}
        }
        if(present && best==null)throw new IOException("Invalid backups");
        return best;
    }
    private void writeShared() throws Exception {
        DocumentFile f=folder();byte[] bytes=encode().toString().getBytes(StandardCharsets.UTF_8);
        // Both copies receive deletions/resets too. A validated copy remains if one write is interrupted.
        for(String name:FILES) {
            DocumentFile d=f.findFile(name);if(d==null)d=f.createFile("application/json",name);
            if(d==null)throw new IOException();
            try(OutputStream out=context.getContentResolver().openOutputStream(d.getUri(),"wt")) {
                if(out==null)throw new IOException();out.write(bytes);out.flush();
            }
        }
    }
    private void writePrivate() throws Exception {
        byte[] bytes=encode().toString().getBytes(StandardCharsets.UTF_8);if(bytes.length>MAX)throw new IOException("Too large");
        FileOutputStream out=null;
        try{out=file.startWrite();out.write(bytes);file.finishWrite(out);}
        catch(Exception e){if(out!=null)file.failWrite(out);throw e;}
    }
    private JSONObject encode() throws Exception {
        JSONObject data=new JSONObject().put("format","nodin-classic-v1").put("revision",revision)
            .put("lineage",lineage).put("initialized",initialized).put("savedAt",savedAt).put("values",values);
        return new JSONObject().put("payload",data.toString()).put("sha256",hash(data.toString()));
    }
    private static JSONObject decode(byte[] bytes) throws Exception {
        JSONObject envelope=new JSONObject(new String(bytes,StandardCharsets.UTF_8));String raw=envelope.getString("payload");
        if(!hash(raw).equals(envelope.getString("sha256")))throw new IOException("Checksum");
        JSONObject data=new JSONObject(raw);
        if(!"nodin-classic-v1".equals(data.getString("format")) || data.getLong("revision")<0 || data.getString("lineage").length()>80)throw new IOException("Format");
        validatedValues(data.getJSONObject("values"));return data;
    }
    private void adopt(JSONObject data) {
        try{values=validatedValues(data.getJSONObject("values"));revision=data.getLong("revision");
            lineage=data.getString("lineage");initialized=data.getBoolean("initialized");savedAt=data.optString("savedAt");}
        catch(Exception e){throw new IllegalArgumentException(e);}
    }
    private static JSONObject validatedValues(JSONObject source) throws Exception {
        JSONObject result=new JSONObject();Iterator<String> keys=source.keys();int count=0;
        while(keys.hasNext()) {String k=keys.next();if(++count>10000 || !tracked(k) || k.length()>300 || !(source.get(k) instanceof String))throw new IOException("Invalid key");result.put(k,source.getString(k));}
        if(result.toString().getBytes(StandardCharsets.UTF_8).length>MAX)throw new IOException("Too large");return result;
    }
    private static byte[] read(InputStream in) throws IOException {
        if(in==null)throw new IOException();try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192];int n;while((n=stream.read(buf))!=-1){if(out.size()+n>MAX)throw new IOException("Too large");out.write(buf,0,n);}return out.toByteArray();
        }
    }
    private static String hash(String raw) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
        StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return s.toString();
    }
}
