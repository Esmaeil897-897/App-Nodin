package com.nodin.english.layers

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun DialogueStudio(
 layer:Layer,store:DialogueStore,input:String,onInput:(String)->Unit,status:String,listening:Boolean,talking:Boolean,energy:Float,
 onSpeak:(String)->Boolean,onStop:()->Unit,onMic:()->Unit,onSystem:()->Unit,
 bindFinal:(((String)->Unit)?)->Unit,bindDone:(((Boolean)->Unit)?)->Unit
){
 val mint=Color(0xFF63E6C5);val muted=Color(0xFFACB9D0);val lilac=Color(0xFFB2ACFF)
 var revision by remember{mutableIntStateOf(0)}
 val all=remember(revision){DialogueCatalog.builtIn+store.customs()}
 var selected by remember(layer){mutableStateOf(store.selection(layer))}
 val dialogue=all.find{it.id==selected}?:all.first()
 var progress by remember(layer,dialogue.id,revision){mutableStateOf(store.load(layer,dialogue.id).let{it.copy(position=it.position.coerceAtMost(dialogue.lines.size))})}
 var library by remember(layer){mutableStateOf(false)};var importDialog by remember{mutableStateOf(false)}
 var filter by remember{mutableStateOf("همه")};var search by remember{mutableStateOf("")}
 var showScript by remember{mutableStateOf(false)};var autoNext by remember{mutableStateOf(true)};var autoMic by remember{mutableStateOf(false)}
 var recorded by remember(dialogue.id,progress.position){mutableStateOf<String?>(null)}
 var pendingSpeech by remember{mutableStateOf<Int?>(null)}
 var repeatConfirm by remember{mutableStateOf(false)}
 val line=dialogue.lines.getOrNull(progress.position)
 val list=rememberLazyListState();val focus=LocalFocusManager.current
 fun persist(p:DialogueProgress){progress=p;store.save(layer,dialogue.id,p)}
 fun move(to:Int){onStop();pendingSpeech=null;onInput("");recorded=null;persist(progress.copy(position=to.coerceIn(0,dialogue.lines.size)))}
 fun evaluate(text:String,spoken:Boolean){if(line?.role!=DialogueRole.USER||text.isBlank())return;focus.clearFocus();persist(progress.record(progress.position,text,Shadowing.compare(line.en,text).percent,spoken))}
 val finalCallback by rememberUpdatedState<(String)->Unit>({text->recorded=text;evaluate(text,true)})
 val doneCallback by rememberUpdatedState<(Boolean)->Unit>({ok->val p=pendingSpeech;pendingSpeech=null;if(ok&&p==progress.position&&line?.role==DialogueRole.APP&&autoNext){val next=progress.position+1;move(next);if(autoMic&&dialogue.lines.getOrNull(next)?.role==DialogueRole.USER)onMic()}})
 DisposableEffect(layer,dialogue.id){bindFinal{finalCallback(it)};bindDone{doneCallback(it)};onDispose{bindFinal(null);bindDone(null);onStop()}}
 LaunchedEffect(dialogue.id,progress.position,library){if(!library)list.scrollToItem(0)}
 @Composable fun English(text:String,size:Int=20){CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr){Text(text,fontSize=size.sp,modifier=Modifier.fillMaxWidth())}}
 @Composable fun Panel(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF19243A)),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)}}
 fun select(d:Dialogue){onStop();pendingSpeech=null;selected=d.id;store.select(layer,d.id);onInput("");library=false;showScript=false}
 LazyColumn(state=list,modifier=Modifier.fillMaxSize().padding(horizontal=16.dp).testTag("dialogue_studio"),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Row(Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text("مکالمهٔ نوبتی",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("${dialogue.title} • ${dialogue.level}",color=mint)};TextButton(onClick={onStop();pendingSpeech=null;library=!library},modifier=Modifier.testTag("dialogue_library")){Text(if(library)"بازگشت" else "انتخاب مکالمه")}}}
  if(library){
   item{OutlinedTextField(search,{search=it},label={Text("جست‌وجوی مکالمه")},modifier=Modifier.fillMaxWidth());Row(Modifier.horizontalScroll(rememberScrollState())){(listOf("همه")+DialogueCatalog.levels).forEach{l->FilterChip(filter==l,{filter=l},label={Text(l)},modifier=Modifier.padding(end=6.dp).testTag("dialogue_level_$l"))}};Text("${all.size} مکالمه • سطح‌ها راهنمای تقریبی تمرین‌اند",color=muted);Button(onClick={importDialog=true},modifier=Modifier.testTag("dialogue_import")){Text("متن مکالمهٔ خودم")}}
   val filtered=all.filter{(filter=="همه"||it.level==filter)&&(search.isBlank()||it.title.contains(search)||it.lines.any{l->l.en.contains(search,true)})}
   items(filtered.size){i->val d=filtered[i];Card(onClick={select(d)},modifier=Modifier.fillMaxWidth().testTag("dialogue_${d.id}"),colors=CardDefaults.cardColors(containerColor=Color(0xFF19243A))){Column(Modifier.padding(16.dp)){Text(d.title,fontSize=20.sp);Text("${d.level} • ${d.lines.size} جمله • ${d.lines.count{it.role==DialogueRole.USER}} نوبت شما",color=mint);val saved=store.load(layer,d.id);Text("${saved.assessed(d)} نوبت سنجیده‌شده • امتیاز کل ${saved.average(d)}٪",color=muted);if(d.custom)TextButton(onClick={store.delete(d.id);revision++}){Text("حذف مکالمه دلخواه")}}}}
   if(filtered.isEmpty())item{Text("مکالمه‌ای در این جست‌وجو پیدا نشد.")}
  }else{
   item{LinearProgressIndicator(progress={progress.position.toFloat()/dialogue.lines.size},modifier=Modifier.fillMaxWidth());Text(if(line==null)"پایان مکالمه" else "جمله ${progress.position+1} از ${dialogue.lines.size} • ${if(line.role==DialogueRole.APP)"نوبت برنامه" else "نوبت شما"}",color=mint,modifier=Modifier.testTag("dialogue_position"));Text("${progress.assessed(dialogue)} از ${dialogue.lines.count{it.role==DialogueRole.USER}} نوبت شما سنجیده شده • ${progress.spokenCount(dialogue)} پاسخ گفتاری",color=muted,fontSize=12.sp)}
   if(line!=null){
    item{Panel{
     when(layer){Layer.VISUAL->SceneArt(line.visual,Modifier.height(150.dp));Layer.AVATAR->{AvatarArt(talking,energy,Modifier.height(150.dp));SceneArt(line.visual,Modifier.height(70.dp))};Layer.VOICE->VoiceWave(listening,energy,Modifier.height(80.dp));else->{}}
     Text(if(line.role==DialogueRole.APP)"همراه شما" else "این جمله را شما بگویید",color=if(line.role==DialogueRole.APP)lilac else mint,fontWeight=FontWeight.Bold)
     English(line.en,if(layer==Layer.VOICE)24 else 21);if(line.fa.isNotBlank())Text(line.fa,color=muted,fontSize=14.sp)
     Button(onClick={onStop();pendingSpeech=if(line.role==DialogueRole.APP)progress.position else null;if(!onSpeak(line.en))pendingSpeech=null},modifier=Modifier.fillMaxWidth().testTag("dialogue_listen")){Text(if(line.role==DialogueRole.APP)"پخش نوبت برنامه" else "شنیدن نمونهٔ جملهٔ من")}
     if(line.role==DialogueRole.APP){Row{Switch(autoNext,{autoNext=it});Text("پس از پایان صدا به جمله بعد برو",fontSize=12.sp)};Row{Switch(autoMic,{autoMic=it});Text("در نوبت من میکروفن خودکار باز شود",fontSize=12.sp)};Text("شروع صدا با دکمه است. میکروفن خودکار فقط با روشن کردن گزینه فعال می‌شود.",color=muted,fontSize=11.sp)}
    }}
    if(line.role==DialogueRole.USER){
     item{Button(onClick={pendingSpeech=null;onMic()},enabled=!talking,modifier=Modifier.fillMaxWidth().heightIn(min=60.dp).testTag("dialogue_mic")){Text(if(listening)"پایان صحبت و سنجش جمله" else "گفتن این جمله با میکروفن")};Text(status,color=mint,fontSize=13.sp);TextButton(onClick={onStop();onSystem()},modifier=Modifier.testTag("dialogue_system")){Text("اگر میکروفن جواب نداد: گفتار سیستم")};Text("متن نهایی گفتار خودکار سنجیده می‌شود؛ نتیجه را ببین و بعد ادامه بده.",color=muted,fontSize=12.sp)}
     item{OutlinedTextField(input,onInput,label={Text("متن دریافت‌شده / تمرین نوشتاری")},maxLines=4,modifier=Modifier.fillMaxWidth().testTag("dialogue_input"))}
     item{Button(onClick={evaluate(input,recorded==input.trim())},enabled=input.isNotBlank()&&!listening,modifier=Modifier.fillMaxWidth().testTag("dialogue_grade")){Text("سنجش این جمله")}}
     progress.results[progress.position]?.let{r->item{Panel{Text(if(r.skipped)"این جمله رد شده است" else "شباهت متن: ${r.score}٪",fontSize=23.sp,color=mint,modifier=Modifier.testTag("dialogue_score"));Text("${r.attempts} تلاش • ${if(r.spoken)"متن گفتار" else "نوشتاری / ویرایش‌شده"}",color=muted);if(r.text.isNotBlank())English(r.text,17);val missing=Shadowing.compare(line.en,r.text).missing;if(!r.skipped&&missing.isNotEmpty()){Text("کلمات دریافت‌نشده:",color=lilac);English(missing.joinToString(" · "),16)};Text("این سنجش، شباهت کلمات و ترتیب آن‌هاست؛ امتیاز لهجه یا ارزیابی پاسخ آزاد نیست.",color=muted,fontSize=11.sp)}}}
    }else item{Text(status,color=muted,fontSize=12.sp)}
    item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={move(progress.position-1)},enabled=progress.position>0,modifier=Modifier.weight(1f)){Text("جمله قبلی")};Button(onClick={move(progress.position+1)},enabled=!listening&&(line.role==DialogueRole.APP||progress.results.containsKey(progress.position)),modifier=Modifier.weight(1f).testTag("dialogue_next")){Text("جمله بعدی")}};if(line.role==DialogueRole.USER)TextButton(onClick={persist(progress.skip(progress.position));move(progress.position+1)},enabled=!listening,modifier=Modifier.testTag("dialogue_skip")){Text("رد کردن این جمله با امتیاز صفر")}}
   }
   item{Panel{Text("نتیجهٔ کل مکالمه",fontSize=21.sp,fontWeight=FontWeight.Bold);Text("امتیاز کل: ${progress.average(dialogue)}٪",fontSize=25.sp,color=mint,modifier=Modifier.testTag("dialogue_total"));Text("میانگین همهٔ نوبت‌های شما؛ نوبت انجام‌نشده یا ردشده صفر حساب می‌شود.",color=muted,fontSize=12.sp);Text("پیشرفت و نتیجهٔ هر جمله خودکار در گوشی ذخیره می‌شود.",fontSize=12.sp);TextButton(onClick={showScript=!showScript},modifier=Modifier.testTag("dialogue_script")){Text(if(showScript)"بستن متن کامل" else "متن کامل و نتیجهٔ جمله‌به‌جمله")};TextButton(onClick={repeatConfirm=true},modifier=Modifier.testTag("dialogue_restart")){Text("شروع دوباره و پاک کردن امتیاز این مکالمه")}}}
   if(showScript)items(dialogue.lines.size){i->val l=dialogue.lines[i];val r=progress.results[i];Panel{Text("${i+1} • ${if(l.role==DialogueRole.APP)"برنامه" else "شما"}",color=if(l.role==DialogueRole.USER)mint else lilac);English(l.en,18);if(l.fa.isNotBlank())Text(l.fa,color=muted,fontSize=13.sp);if(l.role==DialogueRole.USER){Text(if(r==null)"هنوز سنجیده نشده" else if(r.skipped)"رد شده • صفر" else "${r.score}٪ • ${r.attempts} تلاش",color=mint);r?.takeIf{it.text.isNotBlank()}?.let{English(it.text,15)}};TextButton(onClick={move(i)}){Text("تمرین از این جمله")}}}
  }
  item{Spacer(Modifier.height(20.dp))}
 }
 if(repeatConfirm)AlertDialog(onDismissRequest={repeatConfirm=false},title={Text("شروع دوباره؟")},text={Text("امتیازهای همین مکالمه در همین حالت پاک می‌شوند.")},confirmButton={TextButton(onClick={onStop();pendingSpeech=null;onInput("");persist(DialogueProgress());repeatConfirm=false}){Text("شروع دوباره")}},dismissButton={TextButton(onClick={repeatConfirm=false}){Text("بستن")}})
 if(importDialog)DialogueImport(onClose={importDialog=false},onSave={title,level,text->val d=store.add(title,level,text);revision++;select(d);importDialog=false})
}
@Composable private fun DialogueImport(onClose:()->Unit,onSave:(String,String,String)->Unit){
 var title by remember{mutableStateOf("")};var text by remember{mutableStateOf("")};var level by remember{mutableStateOf("A1")};var error by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onClose,title={Text("مکالمهٔ خودم")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("متن انگلیسی را وارد کنید. هر خط یا جمله جدا می‌شود. بدون برچسب نقش‌ها نوبتی‌اند؛ برای تعیین نقش از A: / B: یا برنامه: / کاربر: استفاده کنید. ترجمهٔ خودکار ندارد.",fontSize=12.sp)
  OutlinedTextField(title,{title=it.take(80)},label={Text("نام مکالمه")},modifier=Modifier.testTag("import_title"))
  Row(Modifier.horizontalScroll(rememberScrollState())){DialogueCatalog.levels.forEach{l->FilterChip(level==l,{level=l},label={Text(l)})}}
  OutlinedTextField(text,{text=it.take(30000)},label={Text("متن چندخطی مکالمه")},modifier=Modifier.heightIn(min=160.dp,max=280.dp).testTag("import_text"))
  if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
 }},confirmButton={TextButton(onClick={try{onSave(title,level,text)}catch(e:Exception){error=e.message?:"متن معتبر نیست."}},modifier=Modifier.testTag("import_save")){Text("تقسیم جمله‌ها و ذخیره")}},dismissButton={TextButton(onClick=onClose){Text("بستن")}})
}
