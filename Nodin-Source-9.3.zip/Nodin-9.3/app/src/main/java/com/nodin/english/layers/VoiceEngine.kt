package com.nodin.english.layers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class SpeechMode(val title:String) { AUTO("خودکار گوشی"), DIALOG("پنجره گفتار گوشی"), DEVICE("فقط آفلاین") }

/** All operations and callbacks run on the UI thread. Each recognition session owns its callbacks. */
class VoiceEngine(
 private val activity:Activity,
 private val state:(String)->Unit,
 private val speaking:(Boolean)->Unit,
 private val result:(String)->Unit,
 private val volume:(Float)->Unit,
 private val listening:(Boolean)->Unit = {},
 private val systemDialog:(String)->Unit = {},
 private val factory:((Activity)->SpeechRecognizer)? = null,
 private val finalResult:(String)->Unit = {},
 private val ttsDone:(Boolean)->Unit = {}
) {
 private var tts:TextToSpeech?=null
 private var ready=false
 private var recognizer:SpeechRecognizer?=null
 private var closed=false
 private var session=0
 private var recording=false
 private var utterance=0
 private var activeUtterance:String?=null
 private val main=Handler(Looper.getMainLooper())
 private var timeout:Runnable?=null
 init {
  tts=TextToSpeech(activity){code->activity.runOnUiThread{if(!closed){ready=code==TextToSpeech.SUCCESS; if(ready){tts?.setLanguage(Locale.UK);tts?.setSpeechRate(.85f)}}}}
  tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
   override fun onStart(id:String?){activity.runOnUiThread{if(!closed&&id==activeUtterance)speaking(true)}}
   override fun onDone(id:String?){activity.runOnUiThread{if(!closed&&id==activeUtterance){activeUtterance=null;speaking(false);if(!recording)state("نوبت شماست");ttsDone(true)}}}
   override fun onError(id:String?){activity.runOnUiThread{if(!closed&&id==activeUtterance){activeUtterance=null;speaking(false);if(!recording)state("صدای تلفظ روی گوشی در دسترس نیست.");ttsDone(false)}}}
   override fun onStop(id:String?,interrupted:Boolean){activity.runOnUiThread{if(id==activeUtterance){activeUtterance=null;speaking(false);ttsDone(false)}}}
  })
 }
 fun say(text:String,language:String="en-GB"):Boolean {
  stopListening()
  if(!ready){state("برای شنیدن، موتور تبدیل متن به گفتار گوشی را فعال کنید.");return false}
  if((tts?.setLanguage(Locale.forLanguageTag(language))?:-1)<0){state("صدای این زبان نصب نیست؛ تنظیمات گفتار گوشی را بررسی کنید.");return false}
  val id="nodin-turn-${++utterance}";activeUtterance=id
  if(tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,id)!=TextToSpeech.SUCCESS){activeUtterance=null;state("شروع تلفظ ممکن نشد.");return false};return true
 }
 fun listen(language:String,mode:SpeechMode=SpeechMode.AUTO) {
  if(closed)return
  if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){state("اجازه میکروفن لازم است؛ دسترسی میکروفن برنامه را در تنظیمات گوشی فعال کنید.");return}
  stop()
  if(mode==SpeechMode.DIALOG){systemDialog(language);return}
  if(mode==SpeechMode.DEVICE&&(Build.VERSION.SDK_INT<31||!SpeechRecognizer.isOnDeviceRecognitionAvailable(activity))){state("موتور آفلاین در دسترس نیست. حالت خودکار یا پنجره گفتار گوشی را انتخاب کنید.");return}
  if(factory==null&&mode==SpeechMode.AUTO&&!SpeechRecognizer.isRecognitionAvailable(activity)){state("موتور داخل برنامه موجود نیست؛ پنجره گفتار گوشی باز می‌شود.");systemDialog(language);return}
  val id=++session
  fun valid()=!closed&&id==session
  fun finish(cancel:Boolean=false){val old=recognizer;recognizer=null;session++;recording=false;listening(false);volume(0f);timeout?.let{main.removeCallbacks(it)};timeout=null;main.post{try{if(cancel)old?.cancel();old?.destroy()}catch(_:Exception){}}}
  fun failed(code:Int){if(!valid())return;finish();val hint=when(code){
   SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS->"اجازه میکروفن یا کلید سراسری دسترسی میکروفن گوشی بسته است."
   SpeechRecognizer.ERROR_NO_MATCH->"صدا شنیده شد ولی متن تشخیص داده نشد؛ نزدیک‌تر و واضح‌تر صحبت کنید."
   SpeechRecognizer.ERROR_SPEECH_TIMEOUT->"گفتاری دریافت نشد؛ میکروفن و دسترسی آن را بررسی کنید."
   SpeechRecognizer.ERROR_NETWORK,SpeechRecognizer.ERROR_NETWORK_TIMEOUT->"ارتباط سرویس گفتار قطع است؛ اینترنت را بررسی کنید."
   SpeechRecognizer.ERROR_RECOGNIZER_BUSY->"سرویس گفتار مشغول است؛ چند لحظه بعد دوباره امتحان کنید."
   SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED->"این زبان در موتور انتخاب‌شده پشتیبانی نمی‌شود."
   SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE->"بستهٔ زبان آفلاین دانلود نشده است. حالت خودکار را انتخاب کنید."
   else->"سرویس گفتار پاسخ نداد (کد $code)."
  };state(hint)
  if(mode==SpeechMode.AUTO&&code in listOf(SpeechRecognizer.ERROR_CLIENT,SpeechRecognizer.ERROR_SERVER,SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)){state("$hint پنجرهٔ گفتار گوشی باز می‌شود.");systemDialog(language)}
  }
  try {
   recognizer=factory?.invoke(activity)?:if(mode==SpeechMode.DEVICE&&Build.VERSION.SDK_INT>=31)SpeechRecognizer.createOnDeviceSpeechRecognizer(activity) else SpeechRecognizer.createSpeechRecognizer(activity)
   recognizer?.setRecognitionListener(object:RecognitionListener {
    override fun onReadyForSpeech(b:Bundle?){if(valid())state("میکروفن باز است؛ صحبت کنید…")}
    override fun onBeginningOfSpeech(){if(valid())state("گفتار دریافت می‌شود…")}
    override fun onRmsChanged(rms:Float){if(valid())volume(((rms+2)/12).coerceIn(0f,1f))}
    override fun onBufferReceived(b:ByteArray?){}
    override fun onEndOfSpeech(){if(valid())state("در حال تبدیل صدا به متن…")}
    override fun onError(code:Int){failed(code)}
    override fun onResults(b:Bundle?){if(!valid())return;val text=b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();finish();if(text.isBlank())state("متن تشخیص داده نشد؛ دوباره امتحان کنید.")else{result(text);state("متن آماده است؛ آن را بررسی و سپس تأیید کنید.");finalResult(text)}}
    override fun onPartialResults(b:Bundle?){if(valid())b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let{result(it)}}
    override fun onEvent(t:Int,b:Bundle?){}
   })
   recording=true;listening(true);state("در حال اتصال به میکروفن…")
   recognizer?.startListening(recognitionIntent(language,mode==SpeechMode.DEVICE))
   timeout=Runnable{if(valid()){finish(true);state("سرویس گفتار بیش از حد منتظر ماند؛ پنجرهٔ گفتار گوشی را امتحان کنید.")}}
   main.postDelayed(timeout!!,45000)
  }catch(_:Exception){if(valid()){finish(true);state("شروع سرویس گفتار ممکن نشد؛ پنجرهٔ گفتار گوشی را امتحان کنید.");if(mode==SpeechMode.AUTO)systemDialog(language)}}
 }
 fun endListening(){try{recognizer?.stopListening();state("در حال دریافت متن نهایی…")}catch(_:Exception){stopListening()}}
 fun stopListening(){session++;recording=false;listening(false);timeout?.let{main.removeCallbacks(it)};timeout=null;val old=recognizer;recognizer=null;try{old?.cancel();old?.destroy()}catch(_:Exception){};volume(0f)}
 fun stop(){activeUtterance=null;stopListening();tts?.stop();speaking(false)}
 fun close(){closed=true;stop();tts?.shutdown();tts=null}
 companion object {
  fun recognitionIntent(language:String,offline:Boolean=false)=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
   .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
   .putExtra(RecognizerIntent.EXTRA_LANGUAGE,language)
   .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)
   .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,offline)
   .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)
   .putExtra(RecognizerIntent.EXTRA_PROMPT,if(language.startsWith("fa"))"فارسی صحبت کنید" else "Speak in English")
 }
}
