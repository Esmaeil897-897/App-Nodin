(function(){
 'use strict';
 if(!window.NodinNative || location.origin!=='https://appassets.androidplatform.net')return;
 const native=window.NodinNative,proto=Storage.prototype;
 const set=proto.setItem,get=proto.getItem,remove=proto.removeItem,clear=proto.clear;
 const tracked=k=>/^(fse:|fse_|thProgress|thDailyGoal|thSmartLearn|nodin:heard:)/.test(k);
 let epoch='',quiet=false,pending=0;
 const api=window.NodinClassic={authoritative:false,tracked,collect(){
   const values={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(tracked(k))values[k]=get.call(localStorage,k);}return values;
 }};
 function send(data){pending++;native.postMessage(JSON.stringify(Object.assign({cmd:'classicProgress',epoch},data)));}
 function status(s){
   const e=document.getElementById('classicBackupStatus');if(!e)return;
   e.textContent=s.error || (s.folder?'ذخیره خودکار در bcnodin فعال است':'ذخیره داخلی فعال است؛ پوشه bcnodin هنوز متصل نیست');
   if(s.savedAt && !s.error)e.textContent+=' · '+new Date(s.savedAt).toLocaleString('fa-IR');
 }
 window.onClassicBackupStatus=status;
 try {
   const xhr=new XMLHttpRequest();xhr.open('GET','/classic-progress',false);xhr.send();
   if(xhr.status!==200)throw Error('Local backup unavailable');
   const saved=JSON.parse(xhr.responseText);epoch=saved.epoch;api.epoch=epoch;
   if(saved.initialized){
     api.authoritative=true;
     for(const k of Object.keys(sessionStorage))if(k.startsWith('fse_hot_'))sessionStorage.removeItem(k);
     for(const k of Object.keys(localStorage))if(tracked(k))remove.call(localStorage,k);
     for(const [k,v] of Object.entries(saved.values))set.call(localStorage,k,v);
   } else send({op:'seed',values:api.collect()});
   api.authoritative=!!saved.initialized;
 }catch(e){console.error('Nodin classic backup initialization failed',e);}
 proto.setItem=function(k,v){
   k=String(k);v=String(v);set.call(this,k,v);
   if(this===localStorage && tracked(k) && epoch && !quiet)send({op:'set',key:k,value:v});
 };
 proto.removeItem=function(k){
   k=String(k);remove.call(this,k);
   if(this===localStorage && tracked(k) && epoch && !quiet)send({op:'remove',key:k});
 };
 proto.clear=function(){clear.call(this);if(this===localStorage && epoch && !quiet)send({op:'clear'});};
 api.replace=function(values){
   if(!values || typeof values!=='object' || Array.isArray(values))throw Error('Invalid classic storage');
   for(const [k,v] of Object.entries(values))if(!tracked(k)||typeof v!=='string')throw Error('Invalid classic storage');
   quiet=true;
   try {
     for(const k of Object.keys(localStorage))if(tracked(k))remove.call(localStorage,k);
     for(const [k,v] of Object.entries(values))set.call(localStorage,k,v);
   } finally {quiet=false;}
   send({op:'replace',values});
 };
 document.addEventListener('DOMContentLoaded',()=>{
   const panel=document.getElementById('settingsPanel');if(!panel)return;
   const field=document.createElement('details');field.className='field';field.id='classicBackupSettings';
   field.innerHTML='<summary>ذخیره خودکار یادگیری · bcnodin</summary><p id="classicBackupStatus">در حال بررسی ذخیره…</p><p>یک‌بار در حافظه اصلی، پوشه bcnodin را انتخاب کنید. اگر وجود ندارد با «پوشه جدید» بسازید. پس از اتصال، ذخیره و بازیابی خودکار است؛ ریست هر مسیر هم در همین فایل‌ها ثبت می‌شود.</p><button type="button" id="classicBackupFolder">انتخاب پوشه bcnodin</button>';
   panel.appendChild(field);
   document.getElementById('classicBackupFolder').onclick=()=>native.postMessage(JSON.stringify({cmd:'classicFolder'}));
   native.postMessage(JSON.stringify({cmd:'classicStatus'}));
 });
})();
