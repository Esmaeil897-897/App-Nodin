package com.nodin.english
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import com.nodin.english.layers.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
class DialogueTest {
 @get:Rule val ui=createAndroidComposeRule<LayersActivity>()
 private fun scroll(tag:String){ui.onNodeWithTag("dialogue_studio").performScrollToNode(hasTestTag(tag));ui.onNodeWithTag(tag).performScrollTo()}
 private fun shell(cmd:String){InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand(cmd).use{java.io.FileInputStream(it.fileDescriptor).readBytes()}}
 private fun hide(){ui.runOnUiThread{ui.activity.getSystemService(android.view.inputmethod.InputMethodManager::class.java).hideSoftInputFromWindow(ui.activity.window.decorView.windowToken,0);ui.activity.currentFocus?.clearFocus()};ui.waitForIdle()}
 @Test fun sentenceTurnsScoringResumeAndThreeModes(){
  shell("am force-stop com.android.launcher3")
  ui.onNodeWithTag("layer_VISUAL").performScrollTo().performClick()
  ui.onNodeWithTag("dialogue_studio").assertExists()
  ui.onNodeWithTag("dialogue_library").performClick()
  ui.onNodeWithTag("dialogue_studio").performScrollToNode(hasTestTag("dialogue_progressive_cafe_A1"))
  ui.onNodeWithTag("dialogue_progressive_cafe_A1").performClick()
  ui.onNodeWithTag("dialogue_listen").performClick()
  ui.waitUntil(12000){ui.onAllNodesWithText("جمله 2 از 8 • نوبت شما").fetchSemanticsNodes().isNotEmpty()}
  ui.onNodeWithTag("dialogue_position").assertTextContains("نوبت شما",substring=true)
  scroll("dialogue_input");ui.onNodeWithTag("dialogue_input").performTextInput("Hello.");hide()
  scroll("dialogue_grade");ui.onNodeWithTag("dialogue_grade").assertIsEnabled().performClick()
  scroll("dialogue_score");ui.onNodeWithTag("dialogue_score").assertTextEquals("شباهت متن: 100٪")
  scroll("dialogue_total");ui.onNodeWithTag("dialogue_total").assertTextEquals("امتیاز کل: 25٪")
  ui.onNodeWithTag("change_layer").performClick()
  ui.onNodeWithTag("layer_VISUAL").performScrollTo().performClick()
  ui.onNodeWithTag("dialogue_position").assertTextContains("جمله 2 از 8",substring=true)
  scroll("dialogue_score");ui.onNodeWithTag("dialogue_score").assertTextEquals("شباهت متن: 100٪")
  for(mode in listOf("AVATAR","VOICE")){
   ui.onNodeWithTag("change_layer").performClick();ui.onNodeWithTag("layer_$mode").performScrollTo().performClick()
   ui.onNodeWithTag("dialogue_studio").assertExists();ui.onNodeWithTag("dialogue_listen").assertExists()
   ui.onNodeWithTag("dialogue_studio").performScrollToIndex(0);shell("am force-stop com.android.launcher3");shell("screencap -p /sdcard/nodin-dialogue-${mode.lowercase()}-9.2.png")
  }
 }
 @Test fun parserAndBackupPreserveAssessments(){
  val parsed=DialogueParser.parse("A: Hello. How are you?\nB: I am well.\nA: See you soon.\nB: Goodbye.")
  assertEquals(5,parsed.size);assertEquals(DialogueRole.APP,parsed[1].role);assertEquals(DialogueRole.USER,parsed[2].role)
  assertEquals(listOf("Dr. Smith arrives at 9.30.","Please wait."),DialogueParser.sentences("Dr. Smith arrives at 9.30. Please wait."))
  assertEquals("صبح بخیر.",DialogueCatalog.builtIn.first().lines[0].fa);assertEquals("چه میل دارید؟",DialogueCatalog.builtIn.first().lines[1].fa);assertEquals(41,DialogueCatalog.builtIn.size);assertEquals(DialogueCatalog.levels.toSet(),ConversationCatalog.dialogues.map{it.level}.toSet())
  val ctx=InstrumentationRegistry.getInstrumentation().targetContext;val ds=DialogueStore(ctx);val old=LearningStore(ctx)
  val d=ds.add("Backup test","B2","A: Hello.\nB: Good morning.")
  try{val p=DialogueProgress(1).record(1,"Good morning.",100,true).record(1,"Good morning",100,true);ds.save(Layer.VOICE,d.id,p);ds.save(Layer.VISUAL,d.id,DialogueProgress());val raw=old.export();ds.save(Layer.VOICE,d.id,DialogueProgress());old.restore(raw);assertEquals(2,ds.load(Layer.VOICE,d.id).results[1]!!.attempts);assertEquals(100,ds.load(Layer.VOICE,d.id).average(d));assertEquals(0,ds.load(Layer.VISUAL,d.id).average(d));assertTrue(ds.customs().any{it.id==d.id})}finally{ds.delete(d.id)}
 }
}
