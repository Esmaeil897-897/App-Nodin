package com.nodin.english

import android.content.Intent
import android.webkit.WebView
import androidx.test.runner.lifecycle.ActivityLifecycleCallback
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry
import androidx.test.runner.lifecycle.Stage
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ClassicPersistenceTest {
 private val inst=InstrumentationRegistry.getInstrumentation()
 private val ctx=inst.targetContext
 private val device=UiDevice.getInstance(inst)
 private fun shell(cmd:String)=device.executeShellCommand(cmd)
 private fun web(a:MainActivity):WebView=a.findViewById<android.view.ViewGroup>(android.R.id.content).getChildAt(0) as WebView
 private fun js(s:Page,code:String):String {
  val done=CountDownLatch(1);var result=""
  s.onActivity{web(it).evaluateJavascript(code){value->result=value;done.countDown()}}
  assertTrue("JavaScript callback",done.await(15,TimeUnit.SECONDS));return result
 }
 private fun action(s:Page,code:String){s.onActivity{web(it).evaluateJavascript(code,null)}}
 private fun waitFor(s:Page,code:String){
  val until=System.currentTimeMillis()+20000
  while(System.currentTimeMillis()<until){if(js(s,code)=="true")return;Thread.sleep(100)}
  fail("Not ready: $code")
 }
 private inner class Page(val activity:MainActivity,val callback:ActivityLifecycleCallback) {
  fun onActivity(block:(MainActivity)->Unit){inst.runOnMainSync{block(activity)}}
  fun close(){
   onActivity{it.finish()}
   ActivityLifecycleMonitorRegistry.getInstance().removeLifecycleCallback(callback)
  }
 }
 private fun progress(text:String){inst.sendStatus(0,android.os.Bundle().apply{putString("stream","CLASSIC_TEST: "+text+"\n")})}
 private fun launch():Page {
  progress("launch")
  shell("pm grant com.nodin.english.stable android.permission.ACCESS_COARSE_LOCATION")
  shell("pm grant com.nodin.english.stable android.permission.ACCESS_FINE_LOCATION")
  val resumed=CountDownLatch(1);var activity:MainActivity?=null
  val callback=ActivityLifecycleCallback{a,stage->if(a is MainActivity && stage==Stage.RESUMED){activity=a;resumed.countDown()}}
  ActivityLifecycleMonitorRegistry.getInstance().addLifecycleCallback(callback)
  inst.runOnMainSync{ctx.startActivity(Intent(ctx,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}
  assertTrue("Classic activity resumed",resumed.await(30,TimeUnit.SECONDS))
  val s=Page(activity!!,callback)
  progress("activity resumed")
  waitFor(s,"document.readyState==='complete' && !!window.NodinClassic && document.getElementById('lpResetBtn')?.dataset.wired==='1'")
  progress("classic ready")
  return s
 }
 @Test fun aFolderAutosaveRecoveryAndReset(){
  shell("mkdir -p /sdcard/bcnodin")
  ctx.getSharedPreferences("native",0).edit().putBoolean("classicFolderOffered",true).commit()
  val s=launch()
  action(s,"window.__folderReload=1;NodinNative.postMessage(JSON.stringify({cmd:'classicFolder'})); true")
  val use=device.wait(Until.findObject(By.text(java.util.regex.Pattern.compile("(?i)use this folder"))),12000)
  assertNotNull("System folder picker",use);use.click()
  val allow=device.wait(Until.findObject(By.pkg(java.util.regex.Pattern.compile(".*documentsui")).text(java.util.regex.Pattern.compile("(?i)allow"))),5000)
  assertNotNull("Folder grant",allow);allow.click()
  waitFor(s,"window.__folderReload!==1 && document.readyState==='complete' && !!window.NodinClassic && document.getElementById('lpResetBtn')?.dataset.wired==='1'")
  val store=ClassicProgressStore.get(ctx)
  val until=System.currentTimeMillis()+15000
  while(!store.snapshot().optBoolean("folder")&&System.currentTimeMillis()<until){Thread.sleep(100)}
  if(!store.snapshot().optBoolean("folder")){
   inst.sendStatus(0,android.os.Bundle().apply{putString("stream","CLASSIC_STATUS "+store.status()+"\n"+shell("logcat -d -s NodinClassic:*"))})
   val diagnostic=java.io.File(ctx.cacheDir,"classic-failure.xml");device.dumpWindowHierarchy(diagnostic)
   inst.sendStatus(0,android.os.Bundle().apply{putString("stream",diagnostic.readText())})
  }
  assertTrue("bcnodin granted: "+store.status(),store.snapshot().optBoolean("folder"))
  val oldEpoch=js(s,"window.NodinClassic.epoch")
  action(s,"const values=NodinClassic.collect();const lp=JSON.stringify({stage:7,wordState:{hello:{passed:true,correct:4}},completedStages:[1,2,3,4,5,6],savedAt:Date.now(),v:1});values['fse_learn_path_v2']=lp;values['fse_learn_path_v2__bak']=lp;const op=JSON.stringify({stage:4,savedAt:Date.now(),v:1});values['fse_oxford_path_v1']=op;values['fse_oxford_path_v1__bak']=op;values['nodin:heard:mastery:v1']=JSON.stringify({sample:100});NodinClassic.replace(values);true")
  waitFor(s,"document.readyState==='complete' && window.NodinClassic?.epoch!=="+oldEpoch+" && document.getElementById('lpResetBtn')?.dataset.wired==='1' && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===7")
  val saved=System.currentTimeMillis()+15000
  while(store.snapshot().getJSONObject("values").optString("fse_learn_path_v2").contains("\"stage\":7").not()&&System.currentTimeMillis()<saved)Thread.sleep(100)
  assertTrue(store.snapshot().getJSONObject("values").getString("fse_learn_path_v2").contains("\"stage\":7"))
  // Destroy WebView storage; the authoritative native file must recover before lesson initialization.
  js(s,"localStorage.setItem('unrelated','keep'); true")
  // Bypass the hooked remove only for test damage, without sending a deletion to the backup.
  action(s,"window.__damageReload=1;const frame=document.createElement('iframe');document.body.appendChild(frame);frame.contentWindow.Storage.prototype.removeItem.call(localStorage,'fse_learn_path_v2');frame.remove();location.reload();true")
  waitFor(s,"window.__damageReload!==1 && document.readyState==='complete' && document.getElementById('lpResetBtn')?.dataset.wired==='1' && localStorage.getItem('fse_learn_path_v2') && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===7")
  // Exercise the real existing reset handler while auto-confirming in this test WebView.
  js(s,"window.confirm=()=>true;document.getElementById('lpUseSentencePath').checked=false;document.getElementById('lpUseOxfordPath').checked=false;document.getElementById('lpUseOxfordSequential').checked=false;document.getElementById('lpUseVerbsTenses').checked=false;document.getElementById('lpResetBtn').click();true")
  waitFor(s,"JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===1")
  action(s,"window.__resetReload=1;location.reload();true")
  waitFor(s,"window.__resetReload!==1 && document.readyState==='complete' && document.getElementById('lpResetBtn')?.dataset.wired==='1' && localStorage.getItem('fse_learn_path_v2') && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===1")
  assertEquals(4,JSONObject(JSONObject(js(s,"localStorage.getItem('fse_oxford_path_v1')").let{"{\"value\":$it}"}).getString("value")).getInt("stage"))
  // A new store instance reads actual disk and the granted shared folder, not cached state.
  val reopened=ClassicProgressStore(ctx)
  assertEquals(1,JSONObject(reopened.snapshot().getJSONObject("values").getString("fse_learn_path_v2")).getInt("stage"))
  js(s,"document.getElementById('settingsPanel').classList.remove('hidden');document.getElementById('classicBackupSettings').open=true;document.getElementById('classicBackupSettings').scrollIntoView();true")
  shell("screencap -p /sdcard/nodin-classic-autosave-9.3.png")
  s.close()
 }
 @Test fun bPrepareUpgradeData(){
  ctx.getSharedPreferences("native",0).edit().putBoolean("classicFolderOffered",true).commit()
  val s=launch();val oldEpoch=js(s,"NodinClassic.epoch")
  action(s,"const values=NodinClassic.collect();const lp=JSON.stringify({stage:9,wordState:{hello:{passed:true}},completedStages:[1,2,3],savedAt:Date.now(),v:1});values['fse_learn_path_v2']=lp;values['fse_learn_path_v2__bak']=lp;values['fse:quiz-stats']=JSON.stringify({score:12,asked:15});NodinClassic.replace(values);true")
  waitFor(s,"document.readyState==='complete' && window.NodinClassic?.epoch!=="+oldEpoch+" && document.getElementById('lpResetBtn')?.dataset.wired==='1' && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===9")
  val store=ClassicProgressStore.get(ctx);val until=System.currentTimeMillis()+15000
  while(!store.snapshot().getJSONObject("values").optString("fse_learn_path_v2").contains("\"stage\":9")&&System.currentTimeMillis()<until)Thread.sleep(100)
  assertTrue(store.snapshot().getJSONObject("values").getString("fse_learn_path_v2").contains("\"stage\":9"));s.close()
 }
 @Test fun cVerifyUpgradeData(){
  ctx.getSharedPreferences("native",0).edit().putBoolean("classicFolderOffered",true).commit()
  val s=launch();waitFor(s,"document.readyState==='complete' && document.getElementById('lpResetBtn')?.dataset.wired==='1' && localStorage.getItem('fse_learn_path_v2') && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===9")
  assertEquals(12,JSONObject(JSONObject("{\"v\":"+js(s,"localStorage.getItem('fse:quiz-stats')")+"}").getString("v")).getInt("score"));s.close()
 }
 @Test fun dDifferentSignatureFolderRecovery(){
  ctx.getSharedPreferences("native",0).edit().putBoolean("classicFolderOffered",true).commit()
  val s=launch();action(s,"window.__folderReload=1;NodinNative.postMessage(JSON.stringify({cmd:'classicFolder'}));true")
  val use=device.wait(Until.findObject(By.text(java.util.regex.Pattern.compile("(?i)use this folder"))),12000);assertNotNull(use);use.click()
  val allow=device.wait(Until.findObject(By.pkg(java.util.regex.Pattern.compile(".*documentsui")).text(java.util.regex.Pattern.compile("(?i)allow"))),5000);assertNotNull(allow);allow.click()
  waitFor(s,"window.__folderReload!==1 && document.readyState==='complete' && document.getElementById('lpResetBtn')?.dataset.wired==='1' && localStorage.getItem('fse_learn_path_v2') && JSON.parse(localStorage.getItem('fse_learn_path_v2')).stage===9")
  assertEquals(12,JSONObject(JSONObject("{\"v\":"+js(s,"localStorage.getItem('fse:quiz-stats')")+"}").getString("v")).getInt("score"))
  s.close()
 }

}
