package com.nodin.english

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nodin.english.layers.*
import kotlinx.coroutines.*

class LayersActivity:ComponentActivity() {
 private lateinit var store:LearningStore
 private lateinit var ai:AiSettings
 private lateinit var dialogues:DialogueStore
 private var dialogueFinal:((String)->Unit)?=null
 private var dialogueDone:((Boolean)->Unit)?=null
 private var dialogueCapture=false
 private lateinit var voice:VoiceEngine
 private var status by mutableStateOf("یک حالت را انتخاب کنید")
 private var talking by mutableStateOf(false)
 private var listening by mutableStateOf(false)
 private var energy by mutableStateOf(0f)
 private var input by mutableStateOf("")
 private var language by mutableStateOf("en-GB")
 private var speechMode by mutableStateOf(SpeechMode.AUTO)
 private var layer by mutableStateOf<Layer?>(null)
 private var lessonIndex by mutableIntStateOf(0)
 private var step by mutableIntStateOf(0)
 private var history by mutableStateOf<List<Turn>>(emptyList())
 private var busy by mutableStateOf(false)
 private var settings by mutableStateOf(false)
 private var pendingBackup=""
 private var active=false
 private var request:Job?=null
 private val lesson get()=Curriculum.lessons[lessonIndex]
 private val phrase get()=lesson.prompts[step % lesson.prompts.size]
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){allowed->
  if(allowed&&active)voice.listen(language,speechMode) else status="اجازهٔ میکروفن داده نشده است. تنظیمات گوشی ← برنامه‌ها ← Nodin Layers ← مجوزها را بررسی کنید."
 }
 private val speechDialog=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
  listening=false
  val text=if(r.resultCode==Activity.RESULT_OK)r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty() else ""
  if(text.isNotBlank()){input=text;status="متن از گفتار سیستم دریافت شد؛ بررسی و تأیید کنید.";if(dialogueCapture){dialogueCapture=false;dialogueFinal?.invoke(text)}}else status="گفتار سیستم لغو شد یا متنی برنگرداند؛ دوباره امتحان کنید."
 }
 private val export=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
  if(uri!=null)try{contentResolver.openOutputStream(uri)?.use{it.write(pendingBackup.toByteArray())}?:error("save");status="پشتیبان ذخیره شد."}catch(_:Exception){status="ذخیره پشتیبان ناموفق بود."};pendingBackup=""
 }
 private val restore=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->
  if(uri!=null)try{val raw=contentResolver.openInputStream(uri)?.use{readBackup(it)}?:error("read");store.restore(raw);layer?.let{choose(it)};status="پشتیبان بازیابی شد."}catch(_:Exception){status="فایل پشتیبان معتبر نیست."}
 }
 override fun onCreate(b:Bundle?) {
  super.onCreate(b);store=LearningStore(this);ai=AiSettings(this);dialogues=DialogueStore(this)
  voice=VoiceEngine(this,{status=it},{talking=it},{input=it},{energy=it},{listening=it},{openSpeechDialog(it)},finalResult={text->if(dialogueCapture){dialogueCapture=false;dialogueFinal?.invoke(text)}},ttsDone={dialogueDone?.invoke(it)})
  setContent {MaterialTheme(colorScheme=darkColorScheme(primary=Mint,secondary=Lilac,background=Navy,surface=Panel,onSurface=White,onBackground=White)){
   CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){Surface(Modifier.fillMaxSize(),color=Navy){if(layer==null)Picker() else Workspace(layer!!)}}
  }}
 }
 override fun onStart(){super.onStart();active=true}
 override fun onStop(){active=false;if(::voice.isInitialized)voice.stop();super.onStop()}
 override fun onDestroy(){request?.cancel();if(::voice.isInitialized)voice.close();super.onDestroy()}
 private fun readBackup(input:java.io.InputStream):String{val out=java.io.ByteArrayOutputStream();val b=ByteArray(4096);var n=input.read(b);while(n!=-1){require(out.size()+n<=2_000_000);out.write(b,0,n);n=input.read(b)};return out.toString("UTF-8")}
 private fun openSpeechDialog(lang:String){
  try{speechDialog.launch(VoiceEngine.recognitionIntent(lang));status="در پنجرهٔ گفتار گوشی صحبت کنید."}
  catch(_:ActivityNotFoundException){status="هیچ سرویس گفتار روی گوشی فعال نیست. Speech Services یا برنامهٔ Google و سرویس تشخیص گفتار گوشی را فعال کنید؛ سپس دوباره تلاش کنید."}
  catch(_:Exception){status="پنجرهٔ گفتار گوشی باز نشد؛ تنظیمات سرویس گفتار و دسترسی میکروفن را بررسی کنید."}
 }
 private fun startMicrophone(){if(busy)return;if(listening){voice.endListening();return};input="";if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)voice.listen(language,speechMode) else permission.launch(Manifest.permission.RECORD_AUDIO)}
 @androidx.annotation.OptIn(markerClass=[androidx.media3.common.util.UnstableApi::class])
 private fun choose(value:Layer){
  request?.cancel();busy=false;voice.stop()
  if(value==Layer.CLASSIC){startActivity(Intent(this,MainActivity::class.java));return}
  layer=value;lessonIndex=store.session(value).coerceIn(0,Curriculum.lessons.lastIndex);step=store.stage(value).coerceAtLeast(0)%lesson.prompts.size
  history=store.history(value);if(history.isEmpty())seed();input="";status="آمادهٔ تمرین"
 }
 private fun seed(){val p=phrase;history=listOf(Turn("assistant",p.en,p.fa,visual=p.visual.ifBlank{lesson.shape}));layer?.let{store.save(it,history)}}
 private fun selectLesson(index:Int){request?.cancel();busy=false;voice.stop();lessonIndex=index;step=0;input="";seed();saveStage();status="درس آماده است"}
 private fun saveStage(){layer?.let{store.setSession(it,lessonIndex,step)}}
 private fun advance(){voice.stop();step=(step+1)%lesson.prompts.size;input="";saveStage();status="گام بعدی آماده است"}
 private fun exit(){request?.cancel();busy=false;dialogueCapture=false;voice.stop();layer=null}
 private fun openLink(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){status="مرورگر در دسترس نیست."}}

 @Composable private fun Picker(){LazyColumn(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Spacer(Modifier.height(16.dp));Text("NODIN / LAYERS 9.2",color=Mint,fontWeight=FontWeight.Bold);Text("سه مسیر متفاوت برای تمرین",fontSize=26.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp));Text("۴۱ مکالمه • A1 تا C2 • تمرین جمله‌به‌جمله",color=Muted,modifier=Modifier.padding(top=8.dp))}
  item{AvatarArt(false,modifier=Modifier.height(170.dp))}
  items(Layer.entries.size){i->val mode=Layer.entries[i];Card(onClick={choose(mode)},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth().testTag("layer_${mode.name}")){
   Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text(mode.mark,color=Mint,fontSize=26.sp,fontWeight=FontWeight.Bold);Column(Modifier.weight(1f).padding(horizontal=15.dp)){Text(mode.title,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(mode.caption,color=Muted,fontSize=13.sp)};Text("←",color=Lilac,fontSize=24.sp)}
  }}
  item{Text("بخش کلاسیک همان نسخهٔ قبلی است. درس‌ها و تصاویر جدید آفلاین‌اند؛ منابع تکمیلی در مرورگر باز می‌شوند.",color=Muted,fontSize=12.sp);Spacer(Modifier.height(20.dp))}
 }}
 @Composable private fun Workspace(mode:Layer){
  var tab by remember(mode){mutableIntStateOf(0)}
  BackHandler{if(settings)settings=false else exit()}
  Scaffold(containerColor=Navy,topBar={Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp),verticalAlignment=Alignment.CenterVertically){TextButton(onClick={exit()},modifier=Modifier.testTag("change_layer")){Text("حالت‌ها")};Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text(mode.title,fontSize=19.sp,fontWeight=FontWeight.Bold);Text("NODIN 9.2",color=Mint,fontSize=11.sp)};TextButton(onClick={settings=true}){Text("گفتار / تنظیمات")}}}){pad->
   Column(Modifier.fillMaxSize().padding(pad)){
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
     listOf("مکالمه نوبتی","تمرین قبلی","کتابخانه درس‌ها","مرور واژه","منابع بیشتر").forEachIndexed{i,name->FilterChip(selected=tab==i,onClick={voice.stop();tab=i},label={Text(name)},modifier=Modifier.testTag("tab_$i"))}
    }
    Box(Modifier.weight(1f).navigationBarsPadding().imePadding()){
     when(tab){0->DialogueStudio(mode,dialogues,input,{input=it.take(3000)},status,listening,talking,energy,{voice.say(it)},{dialogueCapture=false;voice.stop()},{dialogueCapture=true;language="en-GB";startMicrophone()},{dialogueCapture=true;openSpeechDialog("en-GB")},{dialogueFinal=it},{dialogueDone=it})
      1->when(mode){Layer.VISUAL->VisualStudio();Layer.AVATAR->AvatarStudio();Layer.VOICE->VoiceStudio();else->{}}
      2->LessonLibrary{selectLesson(it);tab=1}
      3->WordReview()
      else->SourceLibrary()
     }
    }
   }
  }
  if(settings)SettingsDialog()
 }
 @Composable private fun English(text:String,modifier:Modifier=Modifier,size:Int=20){CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr){Text(text,modifier.fillMaxWidth(),fontSize=size.sp)}}
 @Composable private fun PanelCard(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){Card(modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)}}
 @Composable private fun TopicHeader(){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(lesson.title,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("${lesson.category} • ${lesson.level} • گام ${step+1} از ${lesson.prompts.size}",color=Muted,fontSize=12.sp)};TextButton(onClick={selectLesson((lessonIndex+1)%Curriculum.lessons.size)},modifier=Modifier.testTag("next_topic")){Text("موضوع بعدی")}}}
 @Composable private fun SpeechStatus(){
  Text(status,color=if(listening)Mint else Muted,fontSize=13.sp,modifier=Modifier.testTag("speech_status"))
  Row(verticalAlignment=Alignment.CenterVertically){FilterChip(selected=language=="en-GB",onClick={voice.stop();language="en-GB"},label={Text("English")});Spacer(Modifier.width(7.dp));FilterChip(selected=language=="fa-IR",onClick={voice.stop();language="fa-IR"},label={Text("فارسی")});TextButton(onClick={voice.stop();openSpeechDialog(language)},enabled=!busy,modifier=Modifier.testTag("system_speech")){Text("گفتار سیستم")}}
  Text("خودکار و گفتار سیستم ممکن است از اینترنت استفاده کنند. صدا به سرویس هوش مصنوعی Nodin فرستاده نمی‌شود.",color=Muted,fontSize=11.sp)
 }
 @Composable private fun InputBox(label:String="متن پاسخ"){OutlinedTextField(input,{input=it.take(3000)},modifier=Modifier.fillMaxWidth().testTag("message_input"),label={Text(label)},maxLines=3,shape=RoundedCornerShape(16.dp))}
 @Composable private fun MicrophoneButton(modifier:Modifier=Modifier){Button(onClick={startMicrophone()},enabled=!busy,modifier=modifier.testTag("microphone"),shape=RoundedCornerShape(18.dp)){Text(if(listening)"پایان صحبت و دریافت متن" else "میکروفن • صحبت کن")}}

 @Composable private fun VisualStudio(){
  var chosen by remember(lessonIndex,step){mutableStateOf<String?>(null)}
  var reveal by remember(lessonIndex,step){mutableStateOf(false)}
  val options=remember(lessonIndex,step){lesson.prompts.map{it.example}.distinct().sortedBy{(it+step).hashCode()}}
  LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp).testTag("visual_studio"),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item{TopicHeader();Text("با تصویر، پاسخ درست را پیدا کن",color=Mint,fontSize=18.sp,fontWeight=FontWeight.Bold)}
   item{PanelCard{SceneArt(phrase.visual.ifBlank{lesson.shape});English(phrase.en);Text(phrase.fa,color=Muted);LinearProgressIndicator(progress={ (step+1).toFloat()/lesson.prompts.size },modifier=Modifier.fillMaxWidth());TextButton(onClick={voice.say(phrase.en)}){Text("شنیدن سؤال")}}}
   item{Text("کدام پاسخ مناسب این موقعیت است؟",fontWeight=FontWeight.Bold)}
   items(options.size){i->val answer=options[i];OutlinedButton(onClick={chosen=answer;reveal=true;status=if(answer==phrase.example)"انتخاب درست است" else "این پاسخ برای سؤال دیگری از همین موضوع است"},modifier=Modifier.fillMaxWidth().testTag("visual_option_$i"),shape=RoundedCornerShape(16.dp)){English(answer,size=16)}}
   if(reveal)item{PanelCard{Text(if(chosen==phrase.example)"✓ پاسخ مناسب" else "پاسخ مناسب را ببین",color=Mint);English(phrase.example);TextButton(onClick={voice.say(phrase.example)}){Text("شنیدن پاسخ")};Button(onClick={advance()},modifier=Modifier.testTag("visual_next")){Text("تصویر و سؤال بعدی")}}}
   item{PanelCard{Text("یا پاسخ را با صدای خودت بگو",fontWeight=FontWeight.Bold);MicrophoneButton(Modifier.fillMaxWidth());SpeechStatus();InputBox();TextButton(onClick={chosen=input;reveal=true;status="نمونه را با پاسخ خودت مقایسه کن"},enabled=input.isNotBlank()&&!listening,modifier=Modifier.testTag("send")){Text("نمایش نمونه و مقایسه")}}}
   item{Spacer(Modifier.height(20.dp))}
  }
 }
 @Composable private fun AvatarStudio(){
  val scope=rememberCoroutineScope();val list=rememberLazyListState();var cloud by remember{mutableStateOf(false)};var hint by remember(lessonIndex,step){mutableStateOf(false)}
  DisposableEffect(Unit){onDispose{request?.cancel();busy=false;voice.stop()}}
  LaunchedEffect(history.size){if(history.size>1)list.animateScrollToItem(history.size+1)}
  fun send(){val text=input.trim();if(text.isEmpty()||busy||listening)return;voice.stop();history=(history+Turn("user",text,visual=phrase.visual.ifBlank{lesson.shape})).takeLast(80);store.save(Layer.AVATAR,history);input="";busy=true;status="در حال آماده‌سازی پاسخ…";request=scope.launch{
   try{val answer=if(cloud){if(!ai.validEndpoint(ai.endpoint))error("سرویس هوش مصنوعی را در تنظیمات وصل کنید.");AiClient.reply(ai.endpoint,ai.token,history,lesson).copy(visual=phrase.visual.ifBlank{lesson.shape})}else GuidedEngine.respond(text,lesson,step)
    ensureActive();history=(history+answer).takeLast(80);step=(step+1)%lesson.prompts.size;saveStage();store.save(Layer.AVATAR,history);status="پاسخ آماده شد";if(active)voice.say(answer.en)
   }catch(e:CancellationException){throw e}catch(e:Exception){status=e.message?:"سرویس پاسخ نداد"}finally{busy=false}
  }}
  Column(Modifier.fillMaxSize().testTag("avatar_studio")){
   LazyColumn(Modifier.weight(1f).padding(horizontal=16.dp).testTag("conversation_list"),state=list,verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{TopicHeader()}
    item{PanelCard{AvatarArt(talking,energy,Modifier.height(150.dp));Text("نقش‌آفرینی • شما در ${lesson.title}",color=Mint,fontWeight=FontWeight.Bold);SceneArt(phrase.visual.ifBlank{lesson.shape},Modifier.height(90.dp));Row(verticalAlignment=Alignment.CenterVertically){Switch(cloud,{cloud=it},enabled=!busy);Text("مکالمه آزاد با سرویس من",fontSize=13.sp)};Text(if(cloud)"متن با زدن ارسال به سرویس تنظیم‌شده فرستاده می‌شود" else "تمرین آفلاین با پاسخ‌های آماده؛ مدل زبانی نیست",color=Muted,fontSize=11.sp);TextButton(onClick={hint=!hint}){Text("راهنمای پاسخ")};if(hint)English(phrase.example,size=16)}}
    items(history.size){i->val t=history[i];PanelCard{Text(if(t.role=="user")"شما" else "همراه تمرین",color=if(t.role=="user")Mint else Lilac,fontSize=12.sp);if(t.role=="assistant")SceneArt(t.visual.ifBlank{lesson.shape},Modifier.height(80.dp));English(t.en,size=18);if(t.fa.isNotBlank())Text(t.fa,color=Muted);if(t.correction.isNotBlank())Text(t.correction,color=Gold,fontSize=13.sp);TextButton(onClick={voice.say(t.en)}){Text("دوباره بشنو")}}}
   }
   Column(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().imePadding().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
    Text(status,color=Mint,fontSize=12.sp);InputBox();Row{MicrophoneButton(Modifier.weight(1f));Spacer(Modifier.width(8.dp));Button(onClick={send()},enabled=!busy&&!listening&&input.isNotBlank(),modifier=Modifier.weight(1f).testTag("send")){Text(if(busy)"منتظر…" else "ارسال")}}
    TextButton(onClick={voice.stop();openSpeechDialog(language)},enabled=!busy){Text("اگر میکروفن جواب نداد: گفتار سیستم")}
   }
  }
 }
 @Composable private fun VoiceStudio(){
  var practiceAnswer by remember(lessonIndex,step){mutableStateOf(true)}
  var comparison by remember(lessonIndex,step){mutableStateOf<TextComparison?>(null)}
  val target=if(practiceAnswer)phrase.example else phrase.en
  LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp).testTag("voice_studio"),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item{TopicHeader();Text("بشنو ← تکرار کن ← متن را بررسی کن",fontSize=18.sp,fontWeight=FontWeight.Bold,color=Mint)}
   item{PanelCard{SceneArt(phrase.visual.ifBlank{lesson.shape});Row{FilterChip(practiceAnswer,{practiceAnswer=true;comparison=null},label={Text("تکرار پاسخ")});Spacer(Modifier.width(7.dp));FilterChip(!practiceAnswer,{practiceAnswer=false;comparison=null},label={Text("تکرار سؤال")})};English(target,size=24);Text(phrase.fa,color=Muted);Button(onClick={voice.say(target)},modifier=Modifier.fillMaxWidth().testTag("listen_target")){Text("۱ • جمله را بشنو")}}}
   item{PanelCard{VoiceWave(listening,energy);MicrophoneButton(Modifier.fillMaxWidth().heightIn(min=64.dp));SpeechStatus();InputBox("۲ • متن شنیده‌شده؛ قابل ویرایش");Button(onClick={comparison=Shadowing.compare(target,input);store.save(Layer.VOICE,(store.history(Layer.VOICE)+Turn("user",input,correction="تمرین متن: $target",visual=phrase.visual)).takeLast(80));status="مقایسهٔ متن آماده شد"},enabled=input.isNotBlank()&&!listening,modifier=Modifier.fillMaxWidth().testTag("send")){Text("۳ • مقایسهٔ متن")}}}
   comparison?.let{c->item{PanelCard{Text("شباهت متن: ${c.percent}٪",fontSize=25.sp,color=Mint,modifier=Modifier.testTag("text_comparison"));Text("این درصد، مقایسهٔ کلمات متن است؛ امتیاز تلفظ یا لهجه نیست.",color=Muted,fontSize=12.sp);if(c.missing.isNotEmpty()){Text("کلمه‌های دریافت‌نشده:",color=Gold);English(c.missing.joinToString(" · "),size=18)};Row{TextButton(onClick={voice.say(target)}){Text("دوباره بشنو")};Button(onClick={store.review(target,c.percent>=80);advance()}){Text("تمرین بعدی")}}}}}
   item{Spacer(Modifier.height(24.dp))}
  }
 }
 @Composable private fun LessonLibrary(onSelect:(Int)->Unit){
  var search by remember{mutableStateOf("")};var category by remember{mutableStateOf("همه")}
  val categories=listOf("همه")+Curriculum.lessons.map{it.category}.distinct()
  val lessons=Curriculum.lessons.withIndex().filter{(category=="همه"||it.value.category==category)&&(search.isBlank()||it.value.title.contains(search)||it.value.id.contains(search,true)||it.value.prompts.any{p->p.en.contains(search,true)||p.fa.contains(search)})}
  LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
   item{Text("کتابخانهٔ آفلاین",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("${Curriculum.lessons.size} موضوع و ${Curriculum.lessons.sumOf{it.prompts.size}} موقعیت دو‌زبانه",color=Mint);OutlinedTextField(search,{search=it},label={Text("جست‌وجوی فارسی یا انگلیسی")},modifier=Modifier.fillMaxWidth().testTag("lesson_search"));Row(Modifier.horizontalScroll(rememberScrollState())){categories.forEach{c->FilterChip(category==c,{category=c},label={Text(c)},modifier=Modifier.padding(end=6.dp))}}}
   items(lessons.size){i->val indexed=lessons[i];val l=indexed.value;Card(onClick={onSelect(indexed.index)},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth().testTag("lesson_${l.id}")){Column(Modifier.padding(16.dp)){SceneArt(l.shape);Text(l.title,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("${l.category} • ${l.level} • ${l.prompts.size} سؤال • ${l.words.size} کارت واژه",color=Mint,fontSize=12.sp);Text(l.subtitle,color=Muted,fontSize=13.sp)}}}
   if(lessons.isEmpty())item{Text("درسی با این جست‌وجو پیدا نشد.")}
   item{Text("درس‌ها تألیفی و مستقل‌اند. A1/A2 راهنمای دشواری تمرین‌اند و گواهی یا آزمون رسمی نیستند.",color=Muted,fontSize=12.sp);Spacer(Modifier.height(20.dp))}
  }
 }
 @Composable private fun WordReview(){
  val words=Curriculum.lessons.flatMap{l->l.words.map{l to it}}
  var onlyDue by remember{mutableStateOf(false)};var revision by remember{mutableIntStateOf(0)}
  val filtered=remember(onlyDue,revision){words.filter{!onlyDue||store.due(it.second.en)<=System.currentTimeMillis()}}
  LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   item{Text("مرور تصویری واژه‌ها",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("${words.size} کارت آموزشی • پیشرفت در حافظهٔ گوشی",color=Muted);FilterChip(onlyDue,{onlyDue=!onlyDue},label={Text("فقط واژه‌های آمادهٔ مرور")})}
   items(filtered.size){i->val (l,w)=filtered[i];var show by remember(l.id,w.en){mutableStateOf(false)}
    PanelCard{SceneArt(w.visual.ifBlank{l.shape},Modifier.height(95.dp));English(w.en,size=25);Text("${l.title} • مرحلهٔ ${store.level(w.en)} از ۶",color=Mint,fontSize=12.sp);TextButton(onClick={show=!show;voice.say(w.en)}){Text("شنیدن و نمایش معنی")};if(show){Text(w.fa);English(w.example,size=16)};Row{OutlinedButton(onClick={store.review(w.en,false);show=false;revision++}){Text("یادم نبود")};Spacer(Modifier.width(8.dp));Button(onClick={store.review(w.en,true);show=false;revision++}){Text("بلدم")}}}
   }
   if(filtered.isEmpty())item{Text("فعلاً واژه‌ای برای مرور نیست. فیلتر را بردارید تا همهٔ کارت‌ها دیده شوند.")}
   item{Spacer(Modifier.height(20.dp))}
  }
 }
 @Composable private fun SourceLibrary(){LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item{Text("منابع تکمیلی زبان",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("منابع زیر با اینترنت در مرورگر گوشی باز می‌شوند. درس‌های این برنامه بازنشر دوره‌های آن‌ها نیست.",color=Muted,fontSize=13.sp);SpeechStatus()}
  items(ResourceLibrary.links.size){i->val r=ResourceLibrary.links[i];PanelCard{SceneArt(if(i==0)"people" else if(i==1)"phone" else "book",Modifier.height(90.dp));English(r.title,size=19);Text(r.description);Button(onClick={openLink(r.url)}){Text("باز کردن منبع")}}}
  item{Spacer(Modifier.height(20.dp))}
 }}
 @Composable private fun SettingsDialog(){
  var endpoint by remember{mutableStateOf(ai.endpoint)};var token by remember{mutableStateOf(ai.token)};var error by remember{mutableStateOf("")}
  AlertDialog(onDismissRequest={settings=false},title={Text("گفتار و تنظیمات محیط‌های جدید")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Text("مسیر تشخیص گفتار",color=Mint,fontWeight=FontWeight.Bold)
   SpeechMode.entries.forEach{m->Row(Modifier.fillMaxWidth().clickable{voice.stop();speechMode=m},verticalAlignment=Alignment.CenterVertically){RadioButton(speechMode==m,{voice.stop();speechMode=m});Text(m.title)}}
   Text("خودکار از موتور معمول گوشی استفاده می‌کند. فقط آفلاین نیازمند موتور و بستهٔ زبان نصب‌شده است. اگر متن دریافت نشد، پنجرهٔ گفتار گوشی را امتحان کنید.",fontSize=12.sp,color=Muted)
   OutlinedButton(onClick={settings=false;startMicrophone()},modifier=Modifier.fillMaxWidth()){Text("آزمایش میکروفن")}
   Text("راهنمای رفع مشکل: مجوز میکروفن این برنامه، کلید سراسری میکروفن گوشی و سرویس تشخیص گفتار فعال باشند. حالت خودکار ممکن است اینترنت لازم داشته باشد.",fontSize=12.sp)
   TextButton(onClick={try{startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}catch(_:Exception){}}){Text("باز کردن مجوزهای برنامه در گوشی")}
   HorizontalDivider();Text("سرویس مکالمهٔ آزاد (اختیاری)",color=Mint)
   OutlinedTextField(endpoint,{endpoint=it},label={Text("نشانی HTTPS /chat")},singleLine=true)
   OutlinedTextField(token,{token=it},label={Text("کلید دسترسی سرویس")},singleLine=true,visualTransformation=PasswordVisualTransformation())
   Text("بدون سرویس، آواتار تمرین آماده دارد. کلید اصلی مدل باید روی سرور بماند.",fontSize=12.sp,color=Muted)
   TextButton(onClick={pendingBackup=store.export();export.launch("Nodin-Layers-backup.json")}){Text("پشتیبان محیط‌های جدید")}
   TextButton(onClick={restore.launch(arrayOf("application/json","text/plain"))}){Text("بازیابی پشتیبان")}
   if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
  }},confirmButton={TextButton(onClick={if(endpoint.isNotBlank()&&!ai.validEndpoint(endpoint)){error="نشانی باید HTTPS معتبر باشد.";return@TextButton};try{ai.endpoint=endpoint;ai.token=token;status="تنظیمات ذخیره شد";settings=false}catch(_:Exception){error="ذخیرهٔ امن تنظیمات ممکن نشد"}}){Text("ذخیره")}},dismissButton={TextButton(onClick={settings=false}){Text("بستن")}})
 }
 companion object {val Navy=Color(0xFF0D1426);val Panel=Color(0xFF19243A);val Mint=Color(0xFF63E6C5);val Lilac=Color(0xFFB2ACFF);val Muted=Color(0xFFACB9D0);val White=Color(0xFFE5EDFC);val Gold=Color(0xFFFFD48C)}
}
