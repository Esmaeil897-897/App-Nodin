package com.nodin.english.layers

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class DialogueRole { APP, USER }
data class DialogueLine(val role:DialogueRole,val en:String,val fa:String="",val visual:String="people")
data class Dialogue(val id:String,val title:String,val level:String,val lines:List<DialogueLine>,val custom:Boolean=false)
data class LineAttempt(val text:String,val score:Int,val attempts:Int=1,val skipped:Boolean=false,val spoken:Boolean=false)
data class DialogueProgress(val position:Int=0,val results:Map<Int,LineAttempt> = emptyMap()) {
 fun record(index:Int,text:String,score:Int,spoken:Boolean)=copy(results=results+(index to LineAttempt(text,score,(results[index]?.attempts?:0)+1,spoken=spoken)))
 fun skip(index:Int)=copy(results=results+(index to LineAttempt("",0,(results[index]?.attempts?:0),skipped=true)))
 fun assessed(d:Dialogue)=d.lines.indices.count{d.lines[it].role==DialogueRole.USER&&results[it]?.skipped==false}
 fun average(d:Dialogue):Int {val user=d.lines.indices.filter{d.lines[it].role==DialogueRole.USER};return if(user.isEmpty())0 else user.sumOf{results[it]?.score?:0}/user.size}
 fun spokenCount(d:Dialogue)=results.values.count{it.spoken&&!it.skipped}
}
object DialogueParser {
 private val prefix=Regex("^(برنامه|کاربر|گوینده ?[۱۲]|app|program|user|a|b)\\s*[:：]\\s*(.+)$",RegexOption.IGNORE_CASE)
 fun sentences(text:String):List<String> {
  // Protect common titles and decimal points before separating complete sentences.
  val protected=text.replace(Regex("\\b(Mr|Mrs|Ms|Dr|Prof)\\.",RegexOption.IGNORE_CASE)){it.value.dropLast(1)+"∯"}
   .replace(Regex("(?<=\\d)\\.(?=\\d)"),"∯")
  return protected.split(Regex("(?<=[.!?])\\s+")).map{it.replace('∯','.').trim()}.filter{it.isNotBlank()}
 }
 fun parse(text:String):List<DialogueLine> {
  require(text.length<=30000){"متن بیش از حد طولانی است."};val result=mutableListOf<DialogueLine>()
  text.lines().filter{it.isNotBlank()}.forEach{raw->
   val match=prefix.matchEntire(raw.trim());val explicit=match?.groupValues?.get(1)?.lowercase()
   val role=if(explicit==null)null else if(explicit in listOf("کاربر","گوینده۲","گوینده ۲","user","b"))DialogueRole.USER else DialogueRole.APP
   sentences(match?.groupValues?.get(2)?:raw).forEach{s->require(s.length<=1000){"یک جمله بسیار بلند است."};result+=DialogueLine(role?:if(result.size%2==0)DialogueRole.APP else DialogueRole.USER,s)}
  }
  require(result.size in 2..120){"مکالمه باید بین ۲ تا ۱۲۰ جمله باشد."}
  require(result.any{it.role==DialogueRole.APP}&&result.any{it.role==DialogueRole.USER}){"برای هر دو نقش حداقل یک جمله لازم است."}
  return result
 }
}
object DialogueCatalog {
 val levels=listOf("A1","A2","B1","B2","C1","C2")
 val builtIn:List<Dialogue> by lazy {
  Curriculum.lessons.map{lesson->Dialogue("lesson_${lesson.id}",lesson.title,lesson.level,lesson.prompts.flatMap{p->
   DialogueParser.sentences(p.en).map{DialogueLine(DialogueRole.APP,it,p.fa,p.visual.ifBlank{lesson.shape})}+
   DialogueParser.sentences(p.example).map{DialogueLine(DialogueRole.USER,it,"نمونه پاسخ شما",p.visual.ifBlank{lesson.shape})}
  })}+ConversationCatalog.dialogues
 }
}
class DialogueStore(context:Context) {
 private val prefs=context.getSharedPreferences("nodin_layers_v1",Context.MODE_PRIVATE)
 private fun key(layer:Layer,id:String)="dialogue_progress_${layer.name}_$id"
 fun selection(layer:Layer)=prefs.getString("dialogue_selected_${layer.name}","lesson_cafe")?:"lesson_cafe"
 fun select(layer:Layer,id:String){prefs.edit().putString("dialogue_selected_${layer.name}",id).apply()}
 fun load(layer:Layer,id:String):DialogueProgress=try{decodeProgress(JSONObject(prefs.getString(key(layer,id),"{}")?:"{}"))}catch(_:Exception){DialogueProgress()}
 fun save(layer:Layer,id:String,p:DialogueProgress){prefs.edit().putString(key(layer,id),encodeProgress(p).toString()).apply()}
 fun customs():List<Dialogue> = try{val a=JSONArray(prefs.getString("dialogue_custom","[]"));(0 until a.length()).map{decodeDialogue(a.getJSONObject(it))}}catch(_:Exception){emptyList()}
 fun add(title:String,level:String,text:String):Dialogue {val lines=DialogueParser.parse(text);require(level in DialogueCatalog.levels);val existing=customs();require(existing.size<30){"حداکثر ۳۰ مکالمه دلخواه ذخیره می‌شود."};val d=Dialogue("custom_${java.util.UUID.randomUUID()}",title.trim().take(80).ifBlank{"مکالمهٔ من"},level,lines,true);saveCustoms(existing+d);return d}
 fun delete(id:String){saveCustoms(customs().filter{it.id!=id});val edit=prefs.edit();Layer.entries.filter{it!=Layer.CLASSIC}.forEach{edit.remove(key(it,id));if(selection(it)==id)edit.remove("dialogue_selected_${it.name}")};edit.apply()}
 private fun saveCustoms(ds:List<Dialogue>){val a=JSONArray();ds.forEach{a.put(encodeDialogue(it))};prefs.edit().putString("dialogue_custom",a.toString()).apply()}
 companion object {
  fun encodeProgress(p:DialogueProgress):JSONObject {val a=JSONArray();p.results.forEach{(i,r)->a.put(JSONObject().put("index",i).put("text",r.text).put("score",r.score).put("attempts",r.attempts).put("skipped",r.skipped).put("spoken",r.spoken))};return JSONObject().put("position",p.position).put("results",a)}
  fun decodeProgress(o:JSONObject):DialogueProgress {val a=o.optJSONArray("results")?:JSONArray();require(a.length()<=120);val rs=mutableMapOf<Int,LineAttempt>();for(i in 0 until a.length()){val r=a.getJSONObject(i);val index=r.getInt("index");require(index in 0..119);val text=r.getString("text");require(text.length<=3000);rs[index]=LineAttempt(text,r.getInt("score").coerceIn(0,100),r.optInt("attempts",1).coerceIn(0,100000),r.optBoolean("skipped"),r.optBoolean("spoken"))};return DialogueProgress(o.optInt("position").coerceIn(0,120),rs)}
  fun encodeDialogue(d:Dialogue):JSONObject {val a=JSONArray();d.lines.forEach{a.put(JSONObject().put("role",it.role.name).put("en",it.en).put("fa",it.fa).put("visual",it.visual))};return JSONObject().put("id",d.id).put("title",d.title).put("level",d.level).put("lines",a)}
  fun decodeDialogue(o:JSONObject):Dialogue {val id=o.getString("id");require(id.startsWith("custom_")&&id.length<=80);val a=o.getJSONArray("lines");require(a.length() in 2..120);val lines=(0 until a.length()).map{val l=a.getJSONObject(it);val en=l.getString("en");require(en.length in 1..1000);DialogueLine(DialogueRole.valueOf(l.getString("role")),en,l.optString("fa").take(1000),l.optString("visual","people"))};val level=o.getString("level");require(level in DialogueCatalog.levels);require(lines.any{it.role==DialogueRole.USER}&&lines.any{it.role==DialogueRole.APP});return Dialogue(id,o.getString("title").take(80),level,lines,true)}
 }
}
