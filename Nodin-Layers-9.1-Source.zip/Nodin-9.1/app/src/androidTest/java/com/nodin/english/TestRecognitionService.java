package com.nodin.english;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Collections;

/** Test APK only. Java keeps the separate service process independent of target Kotlin libraries. */
public final class TestRecognitionService extends RecognitionService {
    private final Handler main = new Handler(Looper.getMainLooper());
    private Runnable pending;

    private static Bundle transcript(String text) {
        Bundle bundle = new Bundle();
        bundle.putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION,
                new ArrayList<>(Collections.singletonList(text)));
        return bundle;
    }

    @Override protected void onStartListening(Intent intent, Callback callback) {
        try {
            callback.readyForSpeech(new Bundle());
            callback.beginningOfSpeech();
            if ("zz".equals(intent.getStringExtra(RecognizerIntent.EXTRA_LANGUAGE))) {
                callback.error(SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE);
                return;
            }
            callback.partialResults(transcript("I'd like"));
            pending = () -> {
                try {
                    callback.endOfSpeech();
                    callback.results(transcript("I'd like a coffee, please."));
                } catch (RemoteException ignored) { }
                pending = null;
            };
            main.postDelayed(pending, 700);
        } catch (RemoteException ignored) { }
    }

    @Override protected void onStopListening(Callback callback) {
        Runnable result = pending;
        pending = null;
        if (result != null) {
            main.removeCallbacks(result);
            result.run();
        }
    }

    @Override protected void onCancel(Callback callback) {
        if (pending != null) main.removeCallbacks(pending);
        pending = null;
    }
}
