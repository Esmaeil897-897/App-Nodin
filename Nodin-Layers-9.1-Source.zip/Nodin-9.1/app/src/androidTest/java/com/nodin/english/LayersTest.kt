package com.nodin.english
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
class LayersTest {
 @get:Rule val ui=createAndroidComposeRule<LayersActivity>()
 private fun capture(name:String){ui.waitForIdle();androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand("screencap -p /sdcard/$name.png").use{java.io.FileInputStream(it.fileDescriptor).readBytes()}}
 @Test fun distinctModesAndExpandedLibrary(){
  ui.onNodeWithTag("layer_CLASSIC").assertExists()
  ui.onNodeWithTag("layer_VISUAL").performScrollTo().performClick()
  ui.onNodeWithTag("visual_studio").assertExists()
  ui.onNodeWithTag("visual_studio").performScrollToNode(hasText("I'd like a coffee, please."))
  ui.onNodeWithText("I'd like a coffee, please.",substring=false).performClick()
  ui.onNodeWithTag("visual_studio").performScrollToNode(hasTestTag("visual_next"))
  ui.onNodeWithTag("visual_next").assertExists()
  capture("nodin-visual-9.1")
  ui.onNodeWithTag("tab_1").performClick()
  ui.onNodeWithTag("lesson_search").performTextInput("قطار")
  ui.onNodeWithTag("lesson_train").performScrollTo().performClick()
  ui.onNodeWithText("Where would you like to go?",substring=false).assertExists()
  ui.onNodeWithTag("tab_3").performClick()
  ui.onNodeWithText("British Council • Speaking",substring=false).assertExists()
  ui.onNodeWithTag("change_layer").performClick()
  ui.onNodeWithTag("layer_AVATAR").performScrollTo().performClick()
  ui.onNodeWithTag("avatar_studio").assertExists()
  ui.onNodeWithTag("message_input").performTextInput("I'd like a coffee, please.")
  androidx.test.espresso.Espresso.closeSoftKeyboard()
  ui.waitForIdle()
  ui.onNodeWithTag("send").performClick()
  ui.onNodeWithTag("conversation_list").performScrollToNode(hasText("Thank you. Would you like milk in your coffee?"))
  ui.onNodeWithText("Thank you. Would you like milk in your coffee?",substring=false).assertExists()
  capture("nodin-avatar-9.1")
  ui.onNodeWithTag("change_layer").performClick()
  ui.onNodeWithTag("layer_VOICE").performScrollTo().performClick()
  ui.onNodeWithTag("voice_studio").assertExists()
  ui.onNodeWithTag("voice_studio").performScrollToNode(hasTestTag("message_input"))
  ui.onNodeWithTag("message_input").performTextInput("I'd like a coffee, please.")
  androidx.test.espresso.Espresso.closeSoftKeyboard()
  ui.waitForIdle()
  ui.onNodeWithTag("voice_studio").performScrollToNode(hasTestTag("send"))
  ui.onNodeWithTag("send").performScrollTo().assertIsDisplayed().assertIsEnabled().performClick()
  ui.onNodeWithTag("voice_studio").performScrollToNode(hasTestTag("text_comparison"))
  ui.onNodeWithTag("text_comparison").assertTextEquals("شباهت متن: 100٪")
  capture("nodin-voice-9.1")
 }
}
