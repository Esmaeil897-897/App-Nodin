package com.nodin.english
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
/** Test APK only: deterministic framework callbacks, never records real audio. */
class TestRecognitionService:RecognitionService(){
 private val main=Handler(Looper.getMainLooper())
 private var pending:Runnable?=null
 override fun onStartListening(intent:Intent,callback:Callback){
  callback.readyForSpeech(Bundle());callback.beginningOfSpeech()
  if(intent.getStringExtra(RecognizerIntent.EXTRA_LANGUAGE)=="zz"){callback.error(SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE);return}
  val partial=Bundle().apply{putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION,arrayListOf("I'd like"))}
  callback.partialResults(partial)
  pending=Runnable{callback.endOfSpeech();callback.results(Bundle().apply{putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION,arrayListOf("I'd like a coffee, please."))})}
  main.postDelayed(pending!!,700)
 }
 override fun onStopListening(callback:Callback){pending?.let{main.removeCallbacks(it);it.run()};pending=null}
 override fun onCancel(callback:Callback){pending?.let{main.removeCallbacks(it)};pending=null}
}
