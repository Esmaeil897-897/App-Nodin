package com.nodin.english
import android.content.ComponentName
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import com.nodin.english.layers.*
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
class SpeechCompatibilityTest {
 private fun grant(){val i=InstrumentationRegistry.getInstrumentation();listOf(i.targetContext.packageName,i.context.packageName).forEach{pkg->i.uiAutomation.executeShellCommand("pm grant $pkg android.permission.RECORD_AUDIO").use{java.io.FileInputStream(it.fileDescriptor).readBytes()}}}
 @Test fun normalIntentDoesNotForceOffline(){
  val intent=VoiceEngine.recognitionIntent("en-GB")
  assertFalse(intent.getBooleanExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true))
  assertTrue(intent.getBooleanExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false))
  assertTrue(VoiceEngine.recognitionIntent("fa-IR",true).getBooleanExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,false))
  assertEquals(100,Shadowing.compare("I'd like a coffee, please.","I would like a coffee please").percent)
  assertTrue(Shadowing.compare("A return ticket to London","ticket").percent<50)
  assertEquals(23,Curriculum.lessons.size)
  assertEquals(92,Curriculum.lessons.sumOf{it.prompts.size})
 }
 @Test fun recognitionFrameworkDeliversPartialFinalAndFallback(){
  grant();val i=InstrumentationRegistry.getInstrumentation();val final=CountDownLatch(1);val fallback=CountDownLatch(1);val partial=CountDownLatch(1);var engine:VoiceEngine?=null;var last="";val states=java.util.concurrent.CopyOnWriteArrayList<String>()
  ActivityScenario.launch(LayersActivity::class.java).use{scenario->
   scenario.onActivity{a->engine=VoiceEngine(a,{states.add(it)}, {}, {text->last=text;if(text=="I'd like")partial.countDown();if(text=="I'd like a coffee, please.")final.countDown()}, {}, {}, {fallback.countDown()}, {SpeechRecognizer.createSpeechRecognizer(it,ComponentName(i.context,TestRecognitionService::class.java))});engine!!.listen("en-GB")}
   val partialReady=partial.await(12,TimeUnit.SECONDS);assertTrue("Partial transcript delivered; states=$states",partialReady)
   val finalReady=final.await(12,TimeUnit.SECONDS);assertTrue("Final transcript delivered; states=$states; last=$last",finalReady);assertEquals("I'd like a coffee, please.",last)
   scenario.onActivity{engine!!.listen("zz")}
   assertTrue("Unavailable language opens system fallback",fallback.await(12,TimeUnit.SECONDS))
   scenario.onActivity{engine!!.close()}
  }
 }
}
