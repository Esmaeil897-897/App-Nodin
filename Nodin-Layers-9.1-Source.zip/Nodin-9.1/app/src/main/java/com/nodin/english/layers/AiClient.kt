package com.nodin.english.layers
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.HttpsURLConnection

class AiSettings(context:Context) {
 private val prefs=context.getSharedPreferences("nodin_ai_settings",Context.MODE_PRIVATE)
 var endpoint:String
  get()=prefs.getString("endpoint","").orEmpty()
  set(v){prefs.edit().putString("endpoint",v.trim()).apply()}
 private fun key():SecretKey{val store=KeyStore.getInstance("AndroidKeyStore");store.load(null);val alias="nodin_layers_service";val existing=store.getKey(alias,null) as? SecretKey;if(existing!=null)return existing;return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply{init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())}.generateKey()}
 var token:String
  get(){return try{val a=prefs.getString("token","").orEmpty().split(":");if(a.size!=2)"" else Cipher.getInstance("AES/GCM/NoPadding").run{init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(a[0],Base64.NO_WRAP)));String(doFinal(Base64.decode(a[1],Base64.NO_WRAP)),Charsets.UTF_8)}}catch(_:Exception){""}}
  set(v){if(v.isBlank()){prefs.edit().remove("token").apply();return};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());val encrypted=c.doFinal(v.toByteArray());prefs.edit().putString("token",Base64.encodeToString(c.iv,Base64.NO_WRAP)+":"+Base64.encodeToString(encrypted,Base64.NO_WRAP)).apply()}
 fun validEndpoint(value:String):Boolean = try{val u=URL(value);u.protocol=="https"&&u.host.isNotEmpty()&&u.userInfo==null&&u.ref==null}catch(_:Exception){false}
}
object AiClient {
 suspend fun reply(endpoint:String,token:String,turns:List<Turn>,lesson:Lesson):Turn=withContext(Dispatchers.IO){
  val url=URL(endpoint);require(url.protocol=="https"&&url.userInfo==null)
  val c=url.openConnection() as HttpsURLConnection;c.connectTimeout=12000;c.readTimeout=30000;c.requestMethod="POST";c.doOutput=true;c.instanceFollowRedirects=false;c.setRequestProperty("Content-Type","application/json; charset=utf-8");if(token.isNotBlank())c.setRequestProperty("Authorization","Bearer $token")
  val a=JSONArray();turns.takeLast(12).forEach{a.put(JSONObject().put("role",it.role).put("content",it.en))}
  try{c.outputStream.use{it.write(JSONObject().put("messages",a).put("lesson",lesson.id).toString().toByteArray(Charsets.UTF_8))};val code=c.responseCode;if(code !in 200..299)throw IllegalStateException(if(code==401||code==403)"کلید سرویس پذیرفته نشد." else "پاسخ سرویس ناموفق بود ($code).")
   val raw=c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val b=ByteArray(4096);var n=input.read(b);while(n!=-1){if(out.size()+n>65536)throw IllegalStateException("پاسخ سرویس بیش از حد بزرگ است.");out.write(b,0,n);n=input.read(b)};out.toString("UTF-8")};val o=JSONObject(raw);val en=o.getString("english").trim();require(en.isNotEmpty()&&en.length<=6000);Turn("assistant",en,o.optString("persian"),o.optString("correction"))
  }finally{c.disconnect()}
 }
}
