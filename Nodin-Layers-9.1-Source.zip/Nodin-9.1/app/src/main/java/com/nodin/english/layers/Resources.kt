package com.nodin.english.layers
import java.util.Locale

data class LearningResource(val title:String,val description:String,val url:String)
object ResourceLibrary {
 val links=listOf(
  LearningResource("British Council • Speaking","ویدئو و تمرین مکالمهٔ سطح مقدماتی و بالاتر","https://learnenglish.britishcouncil.org/free-resources/speaking"),
  LearningResource("British Council • Listening","فایل شنیداری و تمرین درک مطلب مقدماتی","https://learnenglish.britishcouncil.org/free-resources/listening/a1"),
  LearningResource("British Council • Grammar","توضیح گرامر و تمرین A1–A2","https://learnenglish.britishcouncil.org/free-resources/grammar/a1-a2"),
  LearningResource("Cambridge Dictionary","معنی واژه، مثال و تلفظ بریتانیایی","https://dictionary.cambridge.org/dictionary/english/"),
  LearningResource("Oxford Learner’s Dictionaries","فرهنگ زبان‌آموز و فهرست واژه‌های کاربردی","https://www.oxfordlearnersdictionaries.com/")
 )
}
data class TextComparison(val percent:Int,val missing:List<String>)
object Shadowing {
 fun words(text:String):List<String> = text.lowercase(Locale.UK).replace('’','\'')
  .replace("i'd","i would").replace("i'm","i am").replace("i'll","i will").replace("it's","it is").replace("don't","do not").replace("can't","cannot")
  .replace(Regex("[^\\p{L}\\p{N} ]")," ").split(Regex("\\s+")).filter{it.isNotBlank()}
 fun compare(expected:String,spoken:String):TextComparison {
  val a=words(expected);val b=words(spoken);if(a.isEmpty())return TextComparison(0,emptyList())
  val d=Array(a.size+1){IntArray(b.size+1)}
  for(i in 0..a.size)d[i][0]=i;for(j in 0..b.size)d[0][j]=j
  for(i in 1..a.size)for(j in 1..b.size)d[i][j]=minOf(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+if(a[i-1]==b[j-1])0 else 1)
  val counts=b.groupingBy{it}.eachCount().toMutableMap();val missing=a.filter{w->val n=counts[w]?:0;if(n>0){counts[w]=n-1;false}else true}
  return TextComparison(((1f-d[a.size][b.size].toFloat()/a.size)*100).toInt().coerceIn(0,100),missing)
 }
}
