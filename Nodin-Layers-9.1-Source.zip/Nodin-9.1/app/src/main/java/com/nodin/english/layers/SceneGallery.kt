package com.nodin.english.layers

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.unit.dp
import kotlin.math.*

/** Original vector artwork. Available offline, scales without a bitmap download. */
@Composable fun SceneArt(shape:String,modifier:Modifier=Modifier){
 Canvas(modifier.fillMaxWidth().height(150.dp)){
  val scale=min(size.width/320f,size.height/150f)
  withTransform({translate(size.width/2-160*scale,size.height/2-75*scale);scale(scale,scale,Offset.Zero)}){
   val mint=Color(0xFF65E5C4);val gold=Color(0xFFFFD08C);val lilac=Color(0xFFB3A7FA);val ink=Color(0xFF122C42)
   fun rect(x:Float,y:Float,w:Float,h:Float,c:Color,r:Float=8f)=drawRoundRect(c,Offset(x,y),Size(w,h),CornerRadius(r))
   fun line(x:Float,y:Float,x2:Float,y2:Float,c:Color=gold,w:Float=4f)=drawLine(c,Offset(x,y),Offset(x2,y2),w,StrokeCap.Round)
   fun circle(x:Float,y:Float,r:Float,c:Color)=drawCircle(c,r,Offset(x,y))
   fun person(x:Float,y:Float,c:Color){circle(x,y,12f,c);rect(x-15,y+17,30f,40f,c,13f)}
   fun building(c:Color){rect(103f,24f,114f,99f,c,13f);for(i in 0..2)for(j in 0..1)rect(115f+i*33,37f+j*28,17f,17f,ink,3f);rect(145f,91f,29f,32f,ink,3f)}
   drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF20324E),Color(0xFF263D54))),Offset(8f,4f),Size(304f,142f),CornerRadius(22f))
   circle(251f,33f,19f,Color(0xFF496D83));circle(47f,97f,28f,Color(0xFF3A5369));line(33f,126f,287f,126f,Color(0xFF506984),2f)
   when(shape){
    "cafe","coffee"->{rect(120f,53f,67f,58f,gold,15f);circle(195f,77f,20f,gold);circle(195f,77f,12f,ink);drawOval(Color(0xFF765142),Offset(125f,49f),Size(57f,14f));for(i in 0..2)line(135f+i*17,38f,140f+i*17,22f,lilac,3f)}
    "milk","water"->{rect(137f,32f,48f,82f,if(shape=="milk")Color(0xFFE5E8F4) else Color(0xFF86CFFA));rect(146f,20f,29f,14f,mint,3f);rect(142f,62f,38f,30f,lilac,4f)}
    "soup","plate"->{drawOval(gold,Offset(109f,92f),Size(102f,21f));drawArc(mint,0f,180f,true,Offset(115f,39f),Size(90f,99f));drawOval(Color(0xFFEFB47F),Offset(116f,48f),Size(88f,26f));line(225f,45f,225f,106f,lilac);circle(225f,38f,9f,lilac)}
    "egg"->{drawOval(gold,Offset(126f,30f),Size(70f,91f));drawOval(Color(0xFFFFEACD),Offset(138f,41f),Size(20f,33f))}
    "shirt"->{val p=Path().apply{moveTo(136f,35f);lineTo(111f,48f);lineTo(96f,70f);lineTo(120f,83f);lineTo(129f,69f);lineTo(129f,118f);lineTo(192f,118f);lineTo(192f,69f);lineTo(201f,83f);lineTo(225f,70f);lineTo(210f,48f);lineTo(184f,35f);quadraticTo(160f,57f,136f,35f);close()};drawPath(p,lilac);line(149f,75f,174f,75f,mint,3f)}
    "basket","shop"->{rect(112f,55f,100f,59f,gold,10f);drawArc(mint,180f,180f,false,Offset(131f,18f),Size(62f,71f),style=Stroke(6f));for(i in 0..3)line(126f+i*22,67f,126f+i*22,103f,ink,3f)}
    "train","bus"->{rect(105f,30f,112f,82f,if(shape=="train")mint else gold,16f);for(i in 0..2)rect(115f+i*33,43f,25f,28f,ink,5f);circle(123f,113f,10f,ink);circle(199f,113f,10f,ink);line(118f,94f,204f,94f,lilac,5f);if(shape=="train"){line(103f,127f,218f,127f,gold,3f);line(139f,20f,182f,20f,mint)}}
    "ticket","paper","passport"->{rect(115f,24f,90f,99f,if(shape=="passport")lilac else Color(0xFFE5E8F4),10f);for(i in 0..3)line(129f,47f+i*16,188f,47f+i*16,ink,3f);if(shape=="ticket"){circle(115f,80f,8f,ink);circle(205f,80f,8f,ink)}else if(shape=="passport")circle(160f,97f,13f,mint)}
    "card","money"->{rect(104f,42f,114f,70f,if(shape=="money")mint else lilac,12f);rect(104f,55f,114f,14f,ink,0f);rect(119f,81f,23f,17f,gold,3f);line(173f,90f,203f,90f,gold,3f)}
    "clock"->{circle(160f,74f,48f,mint);circle(160f,74f,41f,ink);for(i in 0..11){val a=i*PI/6;line(160f+cos(a).toFloat()*33,74f+sin(a).toFloat()*33,160f+cos(a).toFloat()*37,74f+sin(a).toFloat()*37,lilac,2f)};line(160f,74f,160f,47f,gold);line(160f,74f,181f,83f,gold);circle(160f,74f,5f,gold)}
    "calendar"->{rect(113f,33f,95f,87f,Color(0xFFE5E8F4),10f);rect(113f,33f,95f,23f,lilac,6f);for(i in 0..2)for(j in 0..2)circle(134f+i*27,72f+j*16,4f,if(i==1&&j==1)Color(0xFFCC586B) else ink);line(136f,22f,136f,41f,mint,6f);line(184f,22f,184f,41f,mint,6f)}
    "home","hotel","clinic","work","kitchen","pharmacy"->{building(if(shape=="clinic"||shape=="pharmacy")Color(0xFFE5E8F4) else lilac);if(shape=="clinic"||shape=="pharmacy"){rect(152f,29f,16f,39f,mint,1f);rect(140f,40f,40f,16f,mint,1f)};if(shape=="kitchen"){rect(145f,75f,30f,45f,Color(0xFFE5E8F4));line(145f,96f,175f,96f,ink,2f)}}
    "tap"->{line(123f,55f,189f,55f,mint,14f);line(189f,55f,189f,72f,mint,14f);line(132f,47f,132f,105f,mint,14f);line(117f,108f,149f,108f,gold,6f);circle(189f,98f,8f,Color(0xFF86CFFA));line(132f,31f,154f,31f,gold,5f)}
    "plane"->{val p=Path().apply{moveTo(156f,22f);lineTo(166f,22f);lineTo(172f,62f);lineTo(224f,88f);lineTo(224f,98f);lineTo(171f,82f);lineTo(171f,111f);lineTo(190f,124f);lineTo(131f,124f);lineTo(151f,111f);lineTo(151f,82f);lineTo(99f,98f);lineTo(99f,88f);lineTo(150f,62f);close()};drawPath(p,mint)}
    "suitcase","parcel"->{rect(119f,42f,82f,73f,gold,9f);if(shape=="suitcase"){drawRoundRect(mint,Offset(143f,25f),Size(35f,23f),CornerRadius(5f),style=Stroke(5f));circle(132f,121f,6f,ink);circle(189f,121f,6f,ink)}else{rect(151f,42f,19f,73f,mint,0f);line(119f,62f,201f,62f,ink,3f)}}
    "sun","weather","umbrella"->{if(shape=="umbrella"){drawArc(lilac,180f,180f,true,Offset(110f,32f),Size(103f,88f));line(160f,72f,160f,116f,gold);drawArc(gold,0f,180f,false,Offset(143f,101f),Size(18f,22f),style=Stroke(4f))}else{circle(151f,64f,26f,gold);for(i in 0..7){val a=i*PI/4;line(151f+cos(a).toFloat()*33,64f+sin(a).toFloat()*33,151f+cos(a).toFloat()*42,64f+sin(a).toFloat()*42,gold,3f)};if(shape=="weather"){circle(188f,88f,23f,lilac);circle(211f,91f,16f,lilac);rect(164f,87f,62f,23f,lilac)}}}
    "tree"->{line(159f,74f,159f,123f,gold,9f);circle(144f,54f,27f,mint);circle(176f,55f,30f,mint);circle(160f,34f,26f,mint)}
    "phone"->{rect(131f,20f,59f,108f,lilac,13f);rect(137f,34f,47f,77f,ink,7f);circle(161f,120f,3f,gold);for(i in 0..2)line(146f,55f+i*17,174f,55f+i*17,mint,3f)}
    "book"->{val p=Path().apply{moveTo(159f,39f);quadraticTo(120f,26f,105f,41f);lineTo(105f,109f);quadraticTo(129f,96f,159f,112f);quadraticTo(186f,96f,216f,109f);lineTo(216f,41f);quadraticTo(189f,26f,159f,39f);close()};drawPath(p,gold);line(159f,41f,159f,109f,ink,3f);for(i in 0..2){line(116f,56f+i*15,147f,56f+i*15,ink,2f);line(171f,56f+i*15,204f,56f+i*15,ink,2f)}}
    "map","left","right","road"->{val p=Path().apply{moveTo(104f,38f);lineTo(142f,27f);lineTo(180f,40f);lineTo(216f,27f);lineTo(216f,111f);lineTo(180f,123f);lineTo(142f,110f);lineTo(104f,123f);close()};drawPath(p,mint);line(142f,28f,142f,110f,ink,2f);line(180f,42f,180f,122f,ink,2f);if(shape=="left"||shape=="right"){val dir=if(shape=="left")-1 else 1;line(138f,76f,183f,76f,ink,6f);val tip=if(dir<0)138f else 183f;line(tip,76f,tip-dir*14,61f,ink,6f);line(tip,76f,tip-dir*14,91f,ink,6f)}else{circle(163f,77f,12f,Color(0xFFDF6C83));line(163f,88f,163f,103f,Color(0xFFDF6C83),5f)}}
    "ball"->{circle(160f,75f,48f,Color(0xFFE5E8F4));circle(160f,75f,15f,ink);for(i in 0..4){val a=i*PI*2/5;val x=160f+cos(a).toFloat()*35;val y=75f+sin(a).toFloat()*35;circle(x,y,10f,ink);line(160f,75f,x,y,ink,2f)}}
    else->{person(120f,58f,lilac);person(198f,58f,mint);person(160f,74f,gold)}
   }
  }
 }
}
@Composable fun VoiceWave(listening:Boolean,energy:Float,modifier:Modifier=Modifier){
 val loop=rememberInfiniteTransition(label="voice")
 val pulse by loop.animateFloat(0f,6.28f,infiniteRepeatable(tween(1600,easing=LinearEasing)),label="wave")
 Canvas(modifier.fillMaxWidth().height(100.dp)){
  val centre=size.width/2;val unit=min(size.width/25,size.height/4)
  for(i in -9..9){val h=if(listening)(.25f+abs(sin(pulse+i*.4f))*(.5f+energy))*size.height*.55f else size.height*.1f
   drawLine(if(listening)Color(0xFF65E5C4) else Color(0xFF57698B),Offset(centre+i*unit,size.height/2-h/2),Offset(centre+i*unit,size.height/2+h/2),unit*.33f,StrokeCap.Round)
  }
 }
}
