package com.nodin.english.layers

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class Layer(val title: String, val caption: String, val mark: String) {
 CLASSIC("کلاسیک", "همان برنامه کامل قبلی، با رادیو و اخبار", "01"),
 VISUAL("تصویری", "آزمون تصویری با انتخاب پاسخ و کارت‌های آموزشی", "02"),
 AVATAR("آواتار", "نقش‌آفرینی در ۲۳ موقعیت با راهنمای پاسخ", "03"),
 VOICE("گفتاری", "شنیدن، تکرار و مقایسهٔ متن تشخیص‌داده‌شده", "04")
}
data class Turn(val role:String,val en:String,val fa:String="",val correction:String="",val visual:String="")
data class Phrase(val en:String,val fa:String,val example:String,val visual:String="")
data class Lesson(val id:String,val title:String,val subtitle:String,val shape:String,val prompts:List<Phrase>,val words:List<Phrase>,val category:String="روزمره",val level:String="A1")
object Curriculum {
 val lessons=listOf(
  Lesson("cafe","در کافه","یک سفارش ساده و مؤدبانه","cafe",listOf(
   Phrase("Good morning. What would you like?","صبح بخیر. چه میل دارید؟","I'd like a coffee, please."),
   Phrase("Would you like milk in your coffee?","در قهوه‌تان شیر می‌خواهید؟","Yes, a little milk, please.","milk"),
   Phrase("Would you like anything to eat?","چیزی برای خوردن میل دارید؟","A sandwich, please.","plate"),
   Phrase("Is that everything?","همین کافی است؟","Yes, thank you. How much is it?","money")),
   listOf(Phrase("please","لطفاً","A coffee, please."),Phrase("coffee","قهوه","I'd like a coffee."),Phrase("milk","شیر","A little milk, please."),Phrase("sandwich","ساندویچ","A sandwich, please.","plate"))),
  Lesson("intro","آشنایی و معرفی","از خودت و زندگی‌ات بگو","people",listOf(
   Phrase("Hello. What is your name?","سلام. نام شما چیست؟","My name is Esmaeil."),
   Phrase("Where do you live?","کجا زندگی می‌کنید؟","I live in Warwickshire."),
   Phrase("What do you do?","شغل شما چیست؟","I work as a delivery driver."),
   Phrase("What do you enjoy doing?","از چه کاری لذت می‌برید؟","I enjoy travelling with my family.")),
   listOf(Phrase("family","خانواده","I love my family."),Phrase("live","زندگی کردن","I live in Warwick."),Phrase("work","کار کردن","I work as a driver."),Phrase("travel","سفر کردن","I like to travel."))),
  Lesson("road","در مسیر","گفت‌وگو هنگام خرابی خودرو","road",listOf(
   Phrase("What is wrong with your car?","ماشین شما چه مشکلی دارد؟","The gears will not engage."),
   Phrase("Where are you now?","الان کجا هستید؟","I am at a motorway service station."),
   Phrase("Are you in a safe place?","در محل امن هستید؟","Yes, I am away from traffic."),
   Phrase("Do you need vehicle recovery?","به خودروبر نیاز دارید؟","Yes, please send a recovery vehicle.")),
   listOf(Phrase("safe","امن","I am in a safe place."),Phrase("recovery","حمل خودروی خراب","I need vehicle recovery."),Phrase("traffic","ترافیک / عبور خودروها","Stay away from traffic."),Phrase("gear","دنده","The gears will not engage.")))
 ) + ExpandedCatalog.lessons
}
object GuidedEngine {
 fun respond(text:String,lesson:Lesson,step:Int):Turn {
  val next=lesson.prompts[(step+1)%lesson.prompts.size]
  return Turn("assistant","Thank you. ${next.en}","ممنون. ${next.fa}","نمونه پاسخ: ${lesson.prompts[step%lesson.prompts.size].example}",next.visual.ifBlank{lesson.shape})
 }
}
class LearningStore(context:Context) {
 private val prefs=context.getSharedPreferences("nodin_layers_v1",Context.MODE_PRIVATE)
 fun history(layer:Layer):List<Turn> = try {
  val a=JSONArray(prefs.getString("history_${layer.name}","[]"));(0 until a.length()).map { val o=a.getJSONObject(it);Turn(o.getString("role"),o.getString("en"),o.optString("fa"),o.optString("correction"),o.optString("visual")) }
 }catch(_:Exception){emptyList()}
 fun save(layer:Layer,turns:List<Turn>) {val a=JSONArray();turns.takeLast(80).forEach{a.put(JSONObject().put("role",it.role).put("en",it.en).put("fa",it.fa).put("correction",it.correction).put("visual",it.visual))};prefs.edit().putString("history_${layer.name}",a.toString()).apply()}
 fun session(layer:Layer)=prefs.getInt("session_${layer.name}",0)
 fun stage(layer:Layer)=prefs.getInt("stage_${layer.name}",0)
 fun setSession(layer:Layer,index:Int,step:Int){prefs.edit().putInt("session_${layer.name}",index).putInt("stage_${layer.name}",step).apply()}
 fun level(word:String)=prefs.getInt("level_$word",0)
 fun due(word:String)=prefs.getLong("due_$word",0)
 fun review(word:String,known:Boolean){val level=if(known)(level(word)+1).coerceAtMost(6) else 0;val delays=longArrayOf(60_000,600_000,86_400_000,259_200_000,604_800_000,1_209_600_000,2_592_000_000);prefs.edit().putInt("level_$word",level).putLong("due_$word",System.currentTimeMillis()+delays[level]).apply()}
 fun export():String { val o=JSONObject().put("format","nodin-layers-v1");val values=JSONObject();prefs.all.forEach{(k,v)->values.put(k,v)};return o.put("values",values).toString(2) }
 fun restore(raw:String) {require(raw.length<2_000_000);val o=JSONObject(raw);require(o.getString("format")=="nodin-layers-v1");val values=o.getJSONObject("values");val edit=prefs.edit();values.keys().forEach{k->when { k.startsWith("history_")-> {val a=JSONArray(values.getString(k));require(a.length()<=80);for(i in 0 until a.length()){val t=a.getJSONObject(i);require(t.getString("role") in listOf("assistant","user"));t.getString("en")};edit.putString(k,a.toString())}; k.startsWith("session_")||k.startsWith("stage_")->edit.putInt(k,values.getInt(k).coerceAtLeast(0)); k.startsWith("level_")->edit.putInt(k,values.getInt(k).coerceIn(0,6)); k.startsWith("due_")->edit.putLong(k,values.getLong(k)) }};require(edit.commit()) }
}
