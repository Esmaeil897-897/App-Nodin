package com.nodin.english.layers

object ExpandedCatalog {
 val lessons=listOf(
  Lesson("shop","خرید در فروشگاه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","basket",listOf(
   Phrase("Can I help you?","می‌توانم کمکتان کنم؟","I am looking for a blue shirt.","shirt"),
   Phrase("What size do you need?","چه سایزی لازم دارید؟","I need a medium, please.","shirt"),
   Phrase("Would you like to try it on?","می‌خواهید آن را امتحان کنید؟","Yes. Where is the changing room?","shop"),
   Phrase("How would you like to pay?","چطور می‌خواهید پرداخت کنید؟","I will pay by card.","card")),
   listOf(Phrase("shirt","پیراهن","I am looking for a blue shirt.","basket"),Phrase("size","اندازه","I am looking for a blue shirt.","basket"),Phrase("receipt","رسید","I am looking for a blue shirt.","basket"),Phrase("basket","سبد","I am looking for a blue shirt.","basket")),"روزمره","A1"),
  Lesson("train","قطار و اتوبوس","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","train",listOf(
   Phrase("Where would you like to go?","کجا می‌خواهید بروید؟","A return ticket to London, please.","ticket"),
   Phrase("When do you want to travel?","چه زمانی می‌خواهید سفر کنید؟","Tomorrow morning, please.","calendar"),
   Phrase("Which platform is it?","کدام سکو است؟","It leaves from platform three.","train"),
   Phrase("Is the bus stop nearby?","ایستگاه اتوبوس نزدیک است؟","Yes. It is next to the station.","bus")),
   listOf(Phrase("ticket","بلیت","A return ticket to London, please.","train"),Phrase("return","رفت و برگشت","A return ticket to London, please.","train"),Phrase("platform","سکو","It leaves from platform three.","train"),Phrase("station","ایستگاه","Yes. It is next to the station.","train")),"سفر","A1"),
  Lesson("clinic","رزرو وقت پزشک","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","clinic",listOf(
   Phrase("Would you like to book an appointment?","می‌خواهید وقت رزرو کنید؟","Yes. Is there an appointment tomorrow?","calendar"),
   Phrase("What would you like to discuss?","دربارهٔ چه چیزی می‌خواهید صحبت کنید؟","I have had a cough for three days.","clinic"),
   Phrase("Can you confirm your name?","نامتان را تأیید می‌کنید؟","My name is Sam Taylor.","people"),
   Phrase("Do you need an interpreter?","به مترجم نیاز دارید؟","Yes. A Persian interpreter, please.","people")),
   listOf(Phrase("appointment","وقت ملاقات","Yes. Is there an appointment tomorrow?","clinic"),Phrase("cough","سرفه","I have had a cough for three days.","clinic"),Phrase("interpreter","مترجم شفاهی","Yes. A Persian interpreter, please.","clinic"),Phrase("reception","پذیرش","Yes. Is there an appointment tomorrow?","clinic")),"خدمات","A2"),
  Lesson("pharmacy","گفت‌وگو در داروخانه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","pharmacy",listOf(
   Phrase("How can I help you today?","امروز چطور کمکتان کنم؟","I would like to speak to the pharmacist.","pharmacy"),
   Phrase("Do you have a prescription?","نسخه دارید؟","Yes. Here is my prescription.","paper"),
   Phrase("Do you have any allergies?","حساسیتی دارید؟","I am allergic to penicillin.","pharmacy"),
   Phrase("Is there anything else?","چیز دیگری لازم دارید؟","Could you explain the label, please?","paper")),
   listOf(Phrase("pharmacist","داروساز","I would like to speak to the pharmacist.","pharmacy"),Phrase("prescription","نسخه","Yes. Here is my prescription.","pharmacy"),Phrase("label","برچسب","Could you explain the label, please?","pharmacy"),Phrase("allergy","حساسیت","I would like to speak to the pharmacist.","pharmacy")),"خدمات","A2"),
  Lesson("home","خانه و تعمیرات","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","home",listOf(
   Phrase("What needs repairing?","چه چیزی نیاز به تعمیر دارد؟","The kitchen tap is leaking.","tap"),
   Phrase("When did the problem start?","مشکل از چه زمانی شروع شد؟","It started yesterday evening.","calendar"),
   Phrase("When can someone visit?","چه زمانی کسی می‌تواند بیاید؟","I will be at home on Friday morning.","home"),
   Phrase("Can you describe the problem?","می‌توانید مشکل را توصیف کنید؟","There is water under the sink.","tap")),
   listOf(Phrase("tap","شیر آب","The kitchen tap is leaking.","home"),Phrase("leak","نشتی","The kitchen tap is leaking.","home"),Phrase("repair","تعمیر","The kitchen tap is leaking.","home"),Phrase("sink","سینک","There is water under the sink.","home")),"روزمره","A2"),
  Lesson("restaurant","رستوران و غذا","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","plate",listOf(
   Phrase("A table for how many people?","میز برای چند نفر؟","A table for three, please.","people"),
   Phrase("What would you like to eat?","چه غذایی میل دارید؟","I would like the vegetable soup.","soup"),
   Phrase("Would you like a drink?","نوشیدنی میل دارید؟","A glass of water, please.","water"),
   Phrase("Can I bring you anything else?","چیز دیگری بیاورم؟","Could we have the bill, please?","paper")),
   listOf(Phrase("table","میز","A table for three, please.","plate"),Phrase("soup","سوپ","I would like the vegetable soup.","plate"),Phrase("bill","صورتحساب","Could we have the bill, please?","plate"),Phrase("water","آب","A glass of water, please.","plate")),"روزمره","A1"),
  Lesson("airport","فرودگاه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","plane",listOf(
   Phrase("Where are you flying today?","امروز به کجا پرواز می‌کنید؟","I am flying to Catania.","plane"),
   Phrase("May I see your travel document?","می‌توانم مدرک سفرتان را ببینم؟","Here is my travel document.","passport"),
   Phrase("Do you have a bag to check in?","چمدانی برای تحویل دارید؟","Yes. I have one suitcase.","suitcase"),
   Phrase("Do you know your gate number?","شمارهٔ گیتتان را می‌دانید؟","My flight leaves from gate twelve.","ticket")),
   listOf(Phrase("flight","پرواز","My flight leaves from gate twelve.","plane"),Phrase("gate","گیت","My flight leaves from gate twelve.","plane"),Phrase("suitcase","چمدان","Yes. I have one suitcase.","plane"),Phrase("document","مدرک","Here is my travel document.","plane")),"سفر","A2"),
  Lesson("hotel","هتل و اقامت","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","hotel",listOf(
   Phrase("Do you have a reservation?","رزرو دارید؟","Yes. The booking is under Taylor.","paper"),
   Phrase("How many nights are you staying?","چند شب می‌مانید؟","We are staying for five nights.","calendar"),
   Phrase("Would you like breakfast?","صبحانه میل دارید؟","Yes. What time is breakfast?","plate"),
   Phrase("How can I help with your room?","دربارهٔ اتاق چطور کمک کنم؟","Could we have an extra towel?","hotel")),
   listOf(Phrase("reservation","رزرو","Yes. The booking is under Taylor.","hotel"),Phrase("room","اتاق","Yes. The booking is under Taylor.","hotel"),Phrase("towel","حوله","Could we have an extra towel?","hotel"),Phrase("breakfast","صبحانه","Yes. What time is breakfast?","hotel")),"سفر","A1"),
  Lesson("workplace","محیط کار و شیفت","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","work",listOf(
   Phrase("What time does your shift start?","شیفتتان چه ساعتی شروع می‌شود؟","My shift starts at nine.","clock"),
   Phrase("Can you cover a shift tomorrow?","می‌توانید فردا یک شیفت را پوشش دهید؟","I can work in the afternoon.","calendar"),
   Phrase("Do you need any help?","کمکی لازم دارید؟","Could you show me how to use this?","work"),
   Phrase("When will the task be ready?","کار چه زمانی آماده می‌شود؟","I will finish it before lunch.","clock")),
   listOf(Phrase("shift","شیفت","My shift starts at nine.","work"),Phrase("task","کار محول‌شده","My shift starts at nine.","work"),Phrase("break","زمان استراحت","My shift starts at nine.","work"),Phrase("colleague","همکار","My shift starts at nine.","work")),"کار","A2"),
  Lesson("delivery","تحویل سفارش","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","parcel",listOf(
   Phrase("Which order are you collecting?","کدام سفارش را تحویل می‌گیرید؟","I am collecting order twenty-four.","paper"),
   Phrase("Where should I leave the parcel?","بسته را کجا بگذارم؟","Please leave it by the front door.","home"),
   Phrase("Can you confirm the address?","آدرس را تأیید می‌کنید؟","It is twelve Green Street.","map"),
   Phrase("Is there a problem with the order?","سفارش مشکلی دارد؟","One item is missing from the bag.","basket")),
   listOf(Phrase("order","سفارش","I am collecting order twenty-four.","parcel"),Phrase("parcel","بسته","I am collecting order twenty-four.","parcel"),Phrase("address","نشانی","I am collecting order twenty-four.","parcel"),Phrase("missing","گمشده / موجود نیست","One item is missing from the bag.","parcel")),"کار","A2"),
  Lesson("weather","آب‌وهوا","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","weather",listOf(
   Phrase("What is the weather like today?","امروز هوا چطور است؟","It is sunny but quite cold.","sun"),
   Phrase("Will it rain this afternoon?","امروز بعدازظهر باران می‌بارد؟","Yes. I will take an umbrella.","umbrella"),
   Phrase("Is it warm enough for a walk?","هوا برای پیاده‌روی به‌اندازهٔ کافی گرم است؟","Yes. Let us go to the park.","tree"),
   Phrase("What should I wear?","چه چیزی بپوشم؟","You should take a warm coat.","shirt")),
   listOf(Phrase("sunny","آفتابی","It is sunny but quite cold.","weather"),Phrase("rain","باران","It is sunny but quite cold.","weather"),Phrase("umbrella","چتر","Yes. I will take an umbrella.","weather"),Phrase("cold","سرد","It is sunny but quite cold.","weather")),"روزمره","A1"),
  Lesson("family","خانواده و مدرسه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","family",listOf(
   Phrase("Who do you live with?","با چه کسی زندگی می‌کنید؟","I live with my family.","family"),
   Phrase("How old is your child?","فرزندتان چند سال دارد؟","My daughter is eight years old.","people"),
   Phrase("What time does school start?","مدرسه چه ساعتی شروع می‌شود؟","School starts at half past eight.","clock"),
   Phrase("What do you do at the weekend?","آخر هفته چه کار می‌کنید؟","We visit the park together.","tree")),
   listOf(Phrase("daughter","دختر","My daughter is eight years old.","family"),Phrase("school","مدرسه","School starts at half past eight.","family"),Phrase("weekend","آخر هفته","I live with my family.","family"),Phrase("together","با هم","We visit the park together.","family")),"زندگی","A1"),
  Lesson("phone","تماس و قرار","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","phone",listOf(
   Phrase("Could I speak to Alex, please?","می‌توانم با الکس صحبت کنم؟","One moment. I will check.","phone"),
   Phrase("Would you like to leave a message?","می‌خواهید پیامی بگذارید؟","Please ask Alex to call me back.","paper"),
   Phrase("Can you repeat the number?","می‌توانید شماره را تکرار کنید؟","Yes. I will say it slowly.","phone"),
   Phrase("Is Friday convenient for you?","جمعه برایتان مناسب است؟","Yes. Friday afternoon is fine.","calendar")),
   listOf(Phrase("message","پیام","One moment. I will check.","phone"),Phrase("repeat","تکرار کردن","One moment. I will check.","phone"),Phrase("slowly","آهسته","Yes. I will say it slowly.","phone"),Phrase("call","تماس گرفتن","Please ask Alex to call me back.","phone")),"خدمات","A2"),
  Lesson("bank","پرداخت و بانک","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","card",listOf(
   Phrase("How can I help with your account?","دربارهٔ حسابتان چطور کمک کنم؟","I would like to check my balance.","card"),
   Phrase("Would you like a receipt?","رسید می‌خواهید؟","Yes. A receipt, please.","paper"),
   Phrase("How much would you like to withdraw?","چقدر می‌خواهید برداشت کنید؟","Fifty pounds, please.","money"),
   Phrase("Has your card been lost?","کارتتان گم شده است؟","Yes. I need to report a lost card.","card")),
   listOf(Phrase("balance","موجودی","I would like to check my balance.","card"),Phrase("withdraw","برداشت کردن","I would like to check my balance.","card"),Phrase("pound","پوند","Fifty pounds, please.","card"),Phrase("account","حساب","I would like to check my balance.","card")),"خدمات","A2"),
  Lesson("time","زمان و برنامه روزانه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","clock",listOf(
   Phrase("What time do you get up?","چه ساعتی بیدار می‌شوید؟","I get up at seven o’clock.","clock"),
   Phrase("When is your English class?","کلاس انگلیسی‌تان چه زمانی است؟","It is on Tuesday evening.","book"),
   Phrase("What are you doing tomorrow?","فردا چه کار می‌کنید؟","I am visiting a friend.","people"),
   Phrase("How often do you exercise?","هر چند وقت ورزش می‌کنید؟","I exercise twice a week.","ball")),
   listOf(Phrase("morning","صبح","I get up at seven o’clock.","clock"),Phrase("evening","عصر / شب","It is on Tuesday evening.","clock"),Phrase("tomorrow","فردا","I get up at seven o’clock.","clock"),Phrase("twice","دو بار","I exercise twice a week.","clock")),"زندگی","A1"),
  Lesson("study","کلاس و یادگیری","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","book",listOf(
   Phrase("Do you understand the question?","سؤال را متوجه می‌شوید؟","Could you explain it again, please?","book"),
   Phrase("How do you spell your name?","نامتان را چطور هجی می‌کنید؟","It is S-A-M.","paper"),
   Phrase("What does this word mean?","این واژه چه معنی دارد؟","Could you give me an example?","book"),
   Phrase("Would you like to practise together?","می‌خواهید با هم تمرین کنیم؟","Yes. Let us practise speaking.","people")),
   listOf(Phrase("question","سؤال","Could you explain it again, please?","book"),Phrase("example","مثال","Could you give me an example?","book"),Phrase("spell","هجی کردن","Could you explain it again, please?","book"),Phrase("understand","فهمیدن","Could you explain it again, please?","book")),"زندگی","A1"),
  Lesson("kitchen","آشپزی و آشپزخانه","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","kitchen",listOf(
   Phrase("What are you cooking?","چه غذایی می‌پزید؟","I am making vegetable soup.","soup"),
   Phrase("Do we have any milk?","شیر داریم؟","Yes. There is some in the fridge.","milk"),
   Phrase("How many eggs do you need?","چند تخم‌مرغ لازم دارید؟","I need two eggs.","egg"),
   Phrase("Is the food ready?","غذا آماده است؟","It will be ready in ten minutes.","clock")),
   listOf(Phrase("fridge","یخچال","Yes. There is some in the fridge.","kitchen"),Phrase("egg","تخم‌مرغ","I need two eggs.","kitchen"),Phrase("cook","پختن","I am making vegetable soup.","kitchen"),Phrase("ready","آماده","It will be ready in ten minutes.","kitchen")),"روزمره","A1"),
  Lesson("directions","پرسیدن مسیر","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","map",listOf(
   Phrase("Where is the nearest station?","نزدیک‌ترین ایستگاه کجاست؟","Go straight ahead and turn left.","left"),
   Phrase("Is it far from here?","از اینجا دور است؟","It is about ten minutes on foot.","map"),
   Phrase("Should I turn right here?","اینجا باید به راست بپیچم؟","Yes. Turn right at the traffic lights.","right"),
   Phrase("What is next to the library?","کنار کتابخانه چیست؟","The post office is next to the library.","home")),
   listOf(Phrase("left","چپ","Go straight ahead and turn left.","map"),Phrase("right","راست","Yes. Turn right at the traffic lights.","map"),Phrase("straight","مستقیم","Go straight ahead and turn left.","map"),Phrase("near","نزدیک","Go straight ahead and turn left.","map")),"سفر","A1"),
  Lesson("post","پست و بسته","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","parcel",listOf(
   Phrase("Where are you sending this parcel?","این بسته را کجا می‌فرستید؟","I am sending it to Birmingham.","parcel"),
   Phrase("Would you like a tracked service?","سرویس دارای رهگیری می‌خواهید؟","Yes. I would like tracking.","map"),
   Phrase("What is inside the parcel?","داخل بسته چیست؟","It contains a book and a shirt.","book"),
   Phrase("Would you like proof of postage?","مدرک ارسال می‌خواهید؟","Yes. Please give me a receipt.","paper")),
   listOf(Phrase("send","فرستادن","I am sending it to Birmingham.","parcel"),Phrase("tracking","رهگیری","Yes. I would like tracking.","parcel"),Phrase("postage","هزینهٔ پست","I am sending it to Birmingham.","parcel"),Phrase("contain","حاوی بودن","It contains a book and a shirt.","parcel")),"خدمات","A2"),
  Lesson("leisure","تفریح و ورزش","چهار موقعیت کاربردی با ترجمه و نمونه پاسخ","ball",listOf(
   Phrase("What do you like doing?","چه کاری دوست دارید؟","I enjoy swimming and walking.","water"),
   Phrase("Would you like to play football?","می‌خواهید فوتبال بازی کنید؟","Yes. Let us play in the park.","ball"),
   Phrase("What are you watching?","چه چیزی تماشا می‌کنید؟","I am watching a film with my family.","phone"),
   Phrase("Where shall we meet?","کجا همدیگر را ببینیم؟","Let us meet outside the café.","cafe")),
   listOf(Phrase("swim","شنا کردن","I enjoy swimming and walking.","ball"),Phrase("walk","راه رفتن","I enjoy swimming and walking.","ball"),Phrase("film","فیلم","I am watching a film with my family.","ball"),Phrase("meet","ملاقات کردن","Let us meet outside the café.","ball")),"زندگی","A1")
 )
}