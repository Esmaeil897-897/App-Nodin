package com.nodin.english
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
class LayersTest {
 @get:Rule val ui=createAndroidComposeRule<LayersActivity>()
 @Test fun chooseLayerPracticeAndReturn(){
  ui.onNodeWithTag("layer_CLASSIC").assertExists()
  ui.onNodeWithTag("layer_VISUAL").performScrollTo().performClick()
  ui.onNodeWithTag("message_input").performTextInput("I'd like a coffee, please.")
  ui.onNodeWithTag("send").performClick()
  ui.waitUntil(10000){ui.onAllNodesWithText("Thank you. Would you like milk in your coffee?").fetchSemanticsNodes().isNotEmpty()}
  ui.onNodeWithTag("change_layer").performClick()
  ui.onNodeWithTag("layer_AVATAR").performScrollTo().performClick()
  ui.onAllNodesWithText("I'd like a coffee, please.",substring=false).assertCountEquals(0)
  ui.onNodeWithTag("change_layer").performClick()
  ui.onNodeWithTag("layer_VOICE").performScrollTo().performClick()
  ui.onNodeWithTag("message_input").assertExists()
 }
}
