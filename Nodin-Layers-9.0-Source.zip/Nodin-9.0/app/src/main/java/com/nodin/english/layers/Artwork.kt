package com.nodin.english.layers
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable fun AvatarArt(speaking:Boolean,energy:Float=0f,modifier:Modifier=Modifier){
 val loop=rememberInfiniteTransition(label="avatar")
 val t by loop.animateFloat(0f,6.283f,infiniteRepeatable(tween(4200,easing=LinearEasing)),label="float")
 val mouth by loop.animateFloat(.05f,.62f,infiniteRepeatable(tween(230),RepeatMode.Reverse),label="mouth")
 Canvas(modifier.height(230.dp).fillMaxWidth()){
  val u=min(size.width,size.height)/240f;val cx=size.width/2;val cy=size.height/2+sin(t)*4*u
  drawCircle(Brush.radialGradient(listOf(Color(0xFF284266),Color.Transparent),Offset(cx,cy),135*u),135*u,Offset(cx,cy))
  drawCircle(Color(0xFF41E0C5).copy(alpha=.15f),101*u,Offset(cx,cy),style=Stroke(1.5f*u))
  for(i in 0..7){val a=t+i*.785f;drawCircle(if(i%2==0)Color(0xFF41E0C5) else Color(0xFF9C9EFF),3*u,Offset(cx+cos(a)*101*u,cy+sin(a)*101*u))}
  drawOval(Color(0xFF090F21).copy(alpha=.5f),Offset(cx-59*u,cy+81*u),Size(118*u,15*u))
  drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFB3FFF0),Color(0xFF35BCAF))),Offset(cx-65*u,cy-64*u),Size(130*u,132*u),androidx.compose.ui.geometry.CornerRadius(44*u))
  drawRoundRect(Color(0xFF102B43),Offset(cx-53*u,cy-37*u),Size(106*u,76*u),androidx.compose.ui.geometry.CornerRadius(27*u))
  val blink=if(t>5.8f&&t<6.04f)1.8f else 9f
  drawOval(Color(0xFFB8FFE9),Offset(cx-31*u,cy-16*u),Size(13*u,blink*u));drawOval(Color(0xFFB8FFE9),Offset(cx+18*u,cy-16*u),Size(13*u,blink*u))
  val open=if(speaking)mouth else .06f
  drawRoundRect(Color(0xFF8BF6D7),Offset(cx-12*u,cy+9*u),Size(24*u,(3+17*open)*u),androidx.compose.ui.geometry.CornerRadius(8*u))
  drawLine(Color(0xFFB6FAEC),Offset(cx,cy-64*u),Offset(cx,cy-83*u),4*u);drawCircle(Color(0xFFFFD087),6*u,Offset(cx,cy-85*u))
  if(speaking||energy>0){for(i in -5..5){val h=(8+abs(sin(t*3+i))*26+(energy*12))*u;drawLine(Color(0xFF5DE4C6),Offset(cx+i*12*u,cy+106*u-h/2),Offset(cx+i*12*u,cy+106*u+h/2),4*u,StrokeCap.Round)}}
 }
}
@Composable fun SceneArt(shape:String,modifier:Modifier=Modifier){Canvas(modifier.height(140.dp).fillMaxWidth()){
 val u=min(size.width/320,size.height/150);val x=size.width/2;val y=size.height/2
 drawCircle(Color(0xFF34426B),58*u,Offset(x,y))
 when(shape){
 "cafe"->{drawRoundRect(Color(0xFFFFD48C),Offset(x-38*u,y-20*u),Size(66*u,56*u),androidx.compose.ui.geometry.CornerRadius(13*u));drawCircle(Color(0xFFFFD48C),18*u,Offset(x+32*u,y+2*u),style=Stroke(8*u));drawOval(Color(0xFF8B6149),Offset(x-32*u,y-24*u),Size(54*u,13*u));for(i in -1..1)drawLine(Color(0xFFD4D8EF),Offset(x+i*15*u,y-40*u),Offset(x+i*15*u+5*u,y-58*u),3*u,StrokeCap.Round);drawLine(Color(0xFF9AA8CE),Offset(x-60*u,y+43*u),Offset(x+60*u,y+43*u),4*u,StrokeCap.Round)}
 "road"->{val path=Path().apply{moveTo(x-30*u,y-58*u);lineTo(x+18*u,y-58*u);lineTo(x+81*u,y+63*u);lineTo(x-81*u,y+63*u);close()};drawPath(path,Color(0xFF19243E));for(i in 0..3)drawLine(Color(0xFFFFD48C),Offset(x,y-44*u+i*27*u),Offset(x,y-31*u+i*27*u),4*u);drawRoundRect(Color(0xFF5DE4C6),Offset(x-47*u,y+5*u),Size(47*u,27*u),androidx.compose.ui.geometry.CornerRadius(8*u));drawCircle(Color(0xFF0F1729),7*u,Offset(x-38*u,y+32*u));drawCircle(Color(0xFF0F1729),7*u,Offset(x-10*u,y+32*u))}
 else->{for(i in -1..1){val off=i*39*u;drawCircle(if(i==0)Color(0xFF5DE4C6) else Color(0xFFABA9FF),14*u,Offset(x+off,y-20*u));drawRoundRect(if(i==0)Color(0xFF5DE4C6) else Color(0xFFABA9FF),Offset(x+off-18*u,y),Size(36*u,44*u),androidx.compose.ui.geometry.CornerRadius(15*u))}}
 }
}}
