package com.nodin.english;
import android.app.Activity;
import android.os.*;
import android.webkit.WebView;
import androidx.media3.common.*;
import androidx.media3.exoplayer.ExoPlayer;
import org.json.*;
@androidx.media3.common.util.UnstableApi
final class NativeRadioCheck {
 private final Activity activity;private final WebView web;private final Handler handler=new Handler(Looper.getMainLooper());private ExoPlayer player;private JSONArray stations,results;private int index;private String token;
 NativeRadioCheck(Activity a,WebView w){activity=a;web=w;}
 void cancel(){handler.removeCallbacksAndMessages(null);if(player!=null){player.release();player=null;}}
 void check(JSONObject data){cancel();stations=data.optJSONArray("stations");results=new JSONArray();index=0;token=data.optString("token");next();}
 private void next(){if(stations==null||index>=Math.min(16,stations.length())){web.evaluateJavascript("window.onNodinRadioChecked?.("+JSONObject.quote(token)+","+results+");",null);return;}JSONObject station=stations.optJSONObject(index++);if(station==null){next();return;}String url=station.optString("stream");android.net.Uri uri=android.net.Uri.parse(url);if(!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null){next();return;}
 player=new ExoPlayer.Builder(activity).build();player.setVolume(0);ExoPlayer current=player;final boolean[] finished={false};Runnable finish=()->{if(finished[0])return;finished[0]=true;handler.removeCallbacksAndMessages(null);current.release();player=null;next();};player.addListener(new Player.Listener(){public void onIsPlayingChanged(boolean playing){if(playing&&!finished[0]&&current.getCurrentTracks().isTypeSupported(C.TRACK_TYPE_AUDIO)){results.put(station);finish.run();}}public void onPlayerError(PlaybackException error){finish.run();}});handler.postDelayed(finish,7000);player.setMediaItem(MediaItem.fromUri(uri));player.prepare();player.play();
 }
}
