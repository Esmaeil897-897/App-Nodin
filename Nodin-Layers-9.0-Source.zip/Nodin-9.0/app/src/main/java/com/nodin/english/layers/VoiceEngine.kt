package com.nodin.english.layers
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceEngine(private val activity:Activity,private val state:(String)->Unit,private val speaking:(Boolean)->Unit,private val result:(String)->Unit,private val volume:(Float)->Unit) {
 private var tts:TextToSpeech?=null;private var ready=false;private var recognizer:SpeechRecognizer?=null;private var closed=false
 init{tts=TextToSpeech(activity){code->activity.runOnUiThread{if(!closed){ready=code==TextToSpeech.SUCCESS;if(ready){tts?.setLanguage(Locale.UK);tts?.setSpeechRate(.85f)}else state("موتور تلفظ آماده نیست؛ سرویس گفتار گوشی را بررسی کنید.")}}};tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){override fun onStart(id:String?){activity.runOnUiThread{speaking(true)}};override fun onDone(id:String?){activity.runOnUiThread{speaking(false);state("نوبت شماست")}};override fun onError(id:String?){activity.runOnUiThread{speaking(false);state("پخش صدا ممکن نشد.")}};override fun onStop(id:String?,interrupted:Boolean){activity.runOnUiThread{speaking(false)}}})}
 fun say(text:String,language:String="en-GB"){stopListening();if(!ready){state("موتور تلفظ هنوز آماده نیست.");return};val available=tts?.setLanguage(Locale.forLanguageTag(language))?:TextToSpeech.LANG_NOT_SUPPORTED;if(available<0){state("صدای این زبان روی گوشی نصب نیست.");return};if(tts?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"nodin-layer-turn")!=TextToSpeech.SUCCESS)state("شروع تلفظ ممکن نشد.")}
 fun listen(language:String){if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){state("اجازه میکروفن لازم است.");return};stop();if(!SpeechRecognizer.isRecognitionAvailable(activity)){state("سرویس تشخیص گفتار روی گوشی موجود نیست.");return}
  recognizer=if(Build.VERSION.SDK_INT>=31&&SpeechRecognizer.isOnDeviceRecognitionAvailable(activity))SpeechRecognizer.createOnDeviceSpeechRecognizer(activity) else SpeechRecognizer.createSpeechRecognizer(activity)
  recognizer?.setRecognitionListener(object:RecognitionListener {
   override fun onReadyForSpeech(b:Bundle?){state("در حال شنیدن…")};override fun onBeginningOfSpeech(){};override fun onRmsChanged(rms:Float){volume((rms/10).coerceIn(0f,1f))};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){state("در حال تبدیل صدا به متن…")}
   override fun onError(code:Int){stopListening();state(when(code){SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS->"اجازه میکروفن داده نشده است.";SpeechRecognizer.ERROR_NO_MATCH,SpeechRecognizer.ERROR_SPEECH_TIMEOUT->"گفتار تشخیص داده نشد؛ دوباره امتحان کنید.";else->"تشخیص گفتار ناموفق بود ($code). اینترنت و سرویس گفتار را بررسی کنید."})}
   override fun onResults(b:Bundle?){val text=b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();stopListening();if(text.isNotBlank()){result(text);state("متن آماده است؛ برای پاسخ، ارسال را بزنید.")}else state("متن تشخیص داده نشد.")};override fun onPartialResults(b:Bundle?){};override fun onEvent(t:Int,b:Bundle?){}
  });try{recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,language).putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true).putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1));state("آماده شنیدن…")}catch(_:Exception){stopListening();state("شروع تشخیص گفتار ممکن نشد.")}
 }
 fun stopListening(){val old=recognizer;recognizer=null;old?.cancel();old?.destroy();volume(0f)}
 fun stop(){stopListening();tts?.stop();speaking(false)}
 fun close(){closed=true;stop();tts?.shutdown();tts=null}
}
