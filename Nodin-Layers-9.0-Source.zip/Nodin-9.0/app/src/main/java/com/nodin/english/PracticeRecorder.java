package com.nodin.english;
import android.app.Activity;
import android.media.MediaRecorder;
import android.webkit.WebView;
import java.io.*;
import org.json.JSONObject;
final class PracticeRecorder {
 private final Activity activity;private final WebView web;private MediaRecorder recorder;private File file;
 PracticeRecorder(Activity a,WebView w){activity=a;web=w;}
 void event(String text){web.evaluateJavascript("window.onNodinPracticeRecording?.({text:"+JSONObject.quote(text)+"});",null);}
 void start(){cancel();try{file=File.createTempFile("practice-",".m4a",activity.getCacheDir());recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setOutputFile(file.getAbsolutePath());recorder.prepare();recorder.start();event("ضبط شروع شد؛ برای ذخیره، پایان ضبط را بزنید.");}catch(Exception e){cancel();event("ضبط ممکن نشد؛ اجازه میکروفن و برنامه‌های ضبط دیگر را بررسی کنید.");}}
 boolean finish(){if(recorder==null){event("ابتدا ضبط را شروع کنید.");return false;}try{recorder.stop();recorder.release();recorder=null;return true;}catch(Exception e){cancel();event("ضبط خیلی کوتاه یا ناموفق بود.");return false;}}
 void export(android.net.Uri uri){try(InputStream in=new FileInputStream(file);OutputStream out=activity.getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);event("فایل صوتی در محل انتخاب‌شده ذخیره شد.");}catch(Exception e){event("ذخیره فایل صوتی ناموفق بود.");}finally{cancel();}}
 void cancelActive(){if(recorder!=null){cancel();event("ضبط با خروج از برنامه متوقف شد.");}}
 void cancel(){if(recorder!=null){try{recorder.stop();}catch(Exception ignored){}recorder.release();recorder=null;}if(file!=null){file.delete();file=null;}}
}
