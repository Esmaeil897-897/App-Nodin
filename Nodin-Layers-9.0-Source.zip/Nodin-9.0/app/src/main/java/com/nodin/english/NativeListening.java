package com.nodin.english;
import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.speech.*;
import android.webkit.WebView;
import org.json.JSONObject;
import java.util.ArrayList;
final class NativeListening implements RecognitionListener {
 private final Activity activity;private final WebView web;private SpeechRecognizer recognizer;private boolean active;private String language="en-GB";private final Handler handler=new Handler(Looper.getMainLooper());
 NativeListening(Activity a,WebView w){activity=a;web=w;}
 void event(String type,String text){JSONObject o=new JSONObject();try{o.put("type",type);o.put("text",text);web.evaluateJavascript("window.onNodinListening?.("+o+");",null);}catch(Exception ignored){}}
 void start(String lang){stop();language=lang.matches("en-GB|fa-IR|tr-TR|it-IT|el-GR")?lang:"en-GB";if(!SpeechRecognizer.isRecognitionAvailable(activity)){event("error","سرویس تشخیص گفتار روی گوشی موجود نیست؛ سرویس گفتار Google را فعال کنید.");return;}recognizer=SpeechRecognizer.createSpeechRecognizer(activity);recognizer.setRecognitionListener(this);active=true;listen();}
 private void listen(){if(!active||recognizer==null)return;Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,language).putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true).putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);try{recognizer.startListening(intent);event("listening","");}catch(Exception e){stop();event("error","شروع تشخیص صدا ممکن نشد.");}}
 void stop(){active=false;handler.removeCallbacksAndMessages(null);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}event("stopped","");}
 public void onReadyForSpeech(Bundle b){event("listening","");}public void onBeginningOfSpeech(){}public void onRmsChanged(float v){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){}
 private String text(Bundle b){ArrayList<String> values=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);return values==null||values.isEmpty()?"":values.get(0);}
 public void onResults(Bundle b){event("final",text(b));if(active)handler.postDelayed(this::listen,400);}
 public void onPartialResults(Bundle b){event("partial",text(b));}
 public void onError(int code){if(active&&(code==SpeechRecognizer.ERROR_NO_MATCH||code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT)){handler.postDelayed(this::listen,700);return;}stop();event("error",code==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS?"اجازهٔ میکروفن داده نشده است.":"تشخیص گفتار متوقف شد ("+code+"). اینترنت و سرویس گفتار گوشی را بررسی کنید.");}
 public void onEvent(int type,Bundle b){}
}
