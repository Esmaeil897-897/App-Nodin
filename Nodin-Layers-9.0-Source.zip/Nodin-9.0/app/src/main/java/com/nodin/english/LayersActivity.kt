package com.nodin.english

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.nodin.english.layers.*
import kotlinx.coroutines.*

class LayersActivity:ComponentActivity(){
 private lateinit var store:LearningStore;private lateinit var ai:AiSettings;private lateinit var voice:VoiceEngine
 private var status by mutableStateOf("آماده تمرین")
 private var talking by mutableStateOf(false)
 private var energy by mutableStateOf(0f)
 private var input by mutableStateOf("")
 private var language by mutableStateOf("en-GB")
 private var layer by mutableStateOf<Layer?>(null)
 private var lessonIndex by mutableIntStateOf(0)
 private var turnStep by mutableIntStateOf(0)
 private var history by mutableStateOf<List<Turn>>(emptyList())
 private var pendingBackup="";private var active=false
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){allowed->if(allowed&&active)voice.listen(language)else status="اجازه میکروفن داده نشده است."}
 private val export=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)try{contentResolver.openOutputStream(uri)?.use{it.write(pendingBackup.toByteArray())}?:error("save");status="پشتیبان ذخیره شد."}catch(_:Exception){status="ذخیره پشتیبان ناموفق بود."};pendingBackup=""}
 private val restore=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{val raw=contentResolver.openInputStream(uri)?.use{readBackup(it)}?:error("read");store.restore(raw);layer?.let{history=store.history(it)};status="پشتیبان بازیابی شد."}catch(_:Exception){status="فایل پشتیبان معتبر نیست."}}
 override fun onCreate(b:Bundle?){super.onCreate(b);store=LearningStore(this);ai=AiSettings(this);voice=VoiceEngine(this,{status=it},{talking=it},{input=it},{energy=it});setContent{
  MaterialTheme(colorScheme=darkColorScheme(primary=Mint,secondary=Lilac,background=Navy,surface=Panel,onSurface=Color(0xFFE5EDFC),onBackground=Color(0xFFE5EDFC))){CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl){Surface(Modifier.fillMaxSize(),color=Navy){if(layer==null)Picker()else Studio(layer!!)}}}
 }}
 override fun onStart(){super.onStart();active=true}
 override fun onStop(){active=false;if(::voice.isInitialized)voice.stop();super.onStop()}
 override fun onDestroy(){if(::voice.isInitialized)voice.close();super.onDestroy()}
 private fun readBackup(input:java.io.InputStream):String{val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(4096);var n=input.read(buffer);while(n!=-1){require(out.size()+n<=2_000_000);out.write(buffer,0,n);n=input.read(buffer)};return out.toString("UTF-8")}
 @androidx.annotation.OptIn(markerClass = [androidx.media3.common.util.UnstableApi::class])
 private fun choose(value:Layer){voice.stop();if(value==Layer.CLASSIC){startActivity(Intent(this,MainActivity::class.java));return};layer=value;history=store.history(value);if(history.isEmpty()){val p=Curriculum.lessons[lessonIndex].prompts[0];history=listOf(Turn("assistant",p.en,p.fa))};input="";turnStep=0;status="آماده تمرین"}
 @Composable private fun Picker(){LazyColumn(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal=22.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  item{Spacer(Modifier.height(16.dp));Text("NODIN / LAYERS",color=Mint,fontSize=13.sp,fontWeight=FontWeight.Bold);Text("امروز چطور یاد بگیریم؟",fontSize=29.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp));Text("یک محیط را انتخاب کن. هر زمان می‌توانی حالت را عوض کنی.",color=Muted,modifier=Modifier.padding(top=8.dp))}
  item{AvatarArt(false,modifier=Modifier.fillMaxWidth())}
  items(Layer.entries.size){i->val l=Layer.entries[i];val c=if(i%2==0)Mint else Lilac;Card(onClick={choose(l)},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth().testTagCompat("layer_${l.name}")){Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).background(c.copy(alpha=.13f),RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center){Text(l.mark,color=c,fontWeight=FontWeight.Bold)};Column(Modifier.weight(1f).padding(horizontal=16.dp)){Text(l.title,fontSize=21.sp,fontWeight=FontWeight.Bold);Text(l.caption,color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=5.dp))};Text("←",color=c,fontSize=25.sp)}}}
  item{Text("کلاسیک شامل امکانات قبلی است. محیط‌های جدید داده و پیشرفت جداگانه دارند.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=12.dp));Spacer(Modifier.height(16.dp))}
 }}
 @Composable private fun Studio(mode:Layer){val scope=rememberCoroutineScope();var tab by remember(mode){mutableIntStateOf(0)};var settings by remember{mutableStateOf(false)};var busy by remember{mutableStateOf(false)};var job by remember{mutableStateOf<Job?>(null)};var cloud by remember{mutableStateOf(false)};var feedback by remember{mutableStateOf("")};val lesson=Curriculum.lessons[lessonIndex];val conversationList=rememberLazyListState()
  LaunchedEffect(history.size,tab){if(tab==0&&history.size>1)conversationList.animateScrollToItem(history.size+1)}
  DisposableEffect(mode){onDispose{job?.cancel();voice.stop()}}
  BackHandler{job?.cancel();voice.stop();layer=null}
  fun send(){val text=input.trim();if(text.isEmpty()||busy)return;voice.stop();val turns=(history+Turn("user",text)).takeLast(80);history=turns;store.save(mode,turns);input="";busy=true;status=if(cloud)"منتظر پاسخ هوش مصنوعی…" else "آماده‌سازی تمرین…";job=scope.launch{try{val answer=if(cloud){if(!ai.validEndpoint(ai.endpoint))throw IllegalStateException("ابتدا سرویس هوش مصنوعی را در تنظیمات وصل کنید.");AiClient.reply(ai.endpoint,ai.token,turns,lesson)}else GuidedEngine.respond(text,lesson,turnStep);ensureActive();history=(history+answer).takeLast(80);turnStep++;store.save(mode,history);status="پاسخ آماده است";if(active)voice.say(answer.en)}catch(e:CancellationException){throw e}catch(e:Exception){status=e.message?:"ارتباط با سرویس ممکن نشد."}finally{busy=false}}}
  Scaffold(containerColor=Navy,topBar={Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(onClick={job?.cancel();voice.stop();layer=null},modifier=Modifier.testTagCompat("change_layer")){Text("حالت‌ها")};Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text("NODIN",fontWeight=FontWeight.Bold,fontSize=18.sp);Text(mode.title,color=Mint,fontSize=12.sp)};TextButton(onClick={settings=true}){Text("تنظیمات")}}},bottomBar={if(tab==0)Column(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().imePadding().padding(12.dp)){Text(status,color=if(busy)Lilac else Mint,fontSize=12.sp);OutlinedTextField(value=input,onValueChange={input=it.take(3000)},placeholder={Text(if(language=="en-GB")"پاسخ انگلیسی یا متن دلخواه…" else "متن فارسی…")},modifier=Modifier.fillMaxWidth().padding(top=6.dp).testTagCompat("message_input"),maxLines=3,shape=RoundedCornerShape(16.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Button(onClick={permission.launch(Manifest.permission.RECORD_AUDIO)},enabled=!busy,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp)){Text("صحبت کن")};Spacer(Modifier.width(8.dp));Button(onClick={send()},enabled=!busy&&input.isNotBlank(),modifier=Modifier.weight(1f).testTagCompat("send"),shape=RoundedCornerShape(14.dp)){Text(if(busy)"منتظر…" else "ارسال")};TextButton(onClick={job?.cancel();voice.stop();status="متوقف شد"}){Text("توقف")}}}}){pad->
   LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp).testTagCompat("conversation_list"),state=conversationList,verticalArrangement=Arrangement.spacedBy(14.dp)){
    item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("مکالمه","درس‌های تصویری","مرور واژه‌ها").forEachIndexed{i,label->FilterChip(selected=tab==i,onClick={voice.stop();tab=i},label={Text(label)})}}}
    if(tab==0){
     item{if(mode==Layer.VISUAL)SceneArt(lesson.shape)else AvatarArt(talking,energy);Row(verticalAlignment=Alignment.CenterVertically){Text(lesson.title,fontWeight=FontWeight.Bold,fontSize=21.sp,modifier=Modifier.weight(1f));AssistChip(onClick={lessonIndex=(lessonIndex+1)%Curriculum.lessons.size;turnStep=0;val p=Curriculum.lessons[lessonIndex].prompts[0];history=listOf(Turn("assistant",p.en,p.fa));store.save(mode,history)},label={Text("موضوع بعدی")})};Text(if(cloud)"هوش مصنوعی آنلاین • متن با ارسال به سرویس شما فرستاده می‌شود" else "تمرین هدایت‌شده • پاسخ‌ها از درس آماده هستند",color=Muted,fontSize=12.sp);Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=cloud,onCheckedChange={cloud=it});Text("مکالمه آزاد با سرویس خودم",fontSize=13.sp)};Text("تشخیص گفتار ممکن است از سرویس گوشی و اینترنت استفاده کند.",color=Muted,fontSize=11.sp)}
     items(history.size){i->val turn=history[i];Card(colors=CardDefaults.cardColors(containerColor=if(turn.role=="user")Color(0xFF183C43) else Panel),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(if(turn.role=="user")"شما" else if(cloud)"همراه" else "راهنمای درس",color=if(turn.role=="user")Mint else Lilac,fontSize=11.sp);CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Ltr){Text(turn.en,fontSize=18.sp,modifier=Modifier.padding(top=8.dp).fillMaxWidth())};if(turn.fa.isNotBlank())Text(turn.fa,color=Muted,modifier=Modifier.padding(top=8.dp));if(turn.correction.isNotBlank())Text(turn.correction,color=Color(0xFFFFD48C),fontSize=13.sp,modifier=Modifier.padding(top=8.dp));Row{TextButton(onClick={voice.say(turn.en)}){Text("شنیدن انگلیسی")};if(turn.fa.isNotBlank())TextButton(onClick={voice.say(turn.fa,"fa-IR")}){Text("شنیدن فارسی")}}}}}
     item{Spacer(Modifier.height(12.dp))}
    }else if(tab==1){items(Curriculum.lessons.size){i->val l=Curriculum.lessons[i];Card(onClick={lessonIndex=i;turnStep=0;val p=l.prompts[0];history=listOf(Turn("assistant",p.en,p.fa));store.save(mode,history);tab=0},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(18.dp)){SceneArt(l.shape);Text(l.title,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(l.subtitle,color=Muted);Text("${l.prompts.size} گام مکالمه • ${l.words.size} واژه",color=Mint,fontSize=12.sp,modifier=Modifier.padding(top=10.dp))}}}}
    else{val words=Curriculum.lessons.flatMap{it.words};item{Text("مرور با فاصله زمانی",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("با «بلدم» زمان مرور بعدی طولانی‌تر می‌شود. واژه‌های فراموش‌شده زودتر برمی‌گردند.",color=Muted,fontSize=13.sp);if(feedback.isNotBlank())Text(feedback,color=Mint)};items(words.size){i->val w=words[i];var reveal by remember(w.en){mutableStateOf(false)};var version by remember{mutableIntStateOf(0)};val level=remember(version){store.level(w.en)};val isDue=remember(version){store.due(w.en)<=System.currentTimeMillis()};Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(w.en,fontSize=23.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("مرحله $level / ۶",color=Mint,fontSize=12.sp)};Text(if(isDue)"زمان مرور رسیده" else "مرور بعدی در آینده",color=Muted,fontSize=11.sp);TextButton(onClick={reveal=!reveal;voice.say(w.en)}){Text(if(reveal)"پنهان کردن معنی" else "شنیدن و نمایش معنی")};if(reveal){Text(w.fa);Text(w.example,color=Muted,fontSize=13.sp)};Row{OutlinedButton(onClick={store.review(w.en,false);version++;reveal=false;feedback="واژه برای مرور زودتر ثبت شد."}){Text("یادم نبود")};Spacer(Modifier.width(8.dp));Button(onClick={store.review(w.en,true);version++;reveal=false;feedback="پیشرفت ذخیره شد."}){Text("بلدم")}}}}}}
   }
  }
  if(settings)SettingsDialog(onClose={settings=false})
 }
 @Composable private fun SettingsDialog(onClose:()->Unit){var endpoint by remember{mutableStateOf(ai.endpoint)};var token by remember{mutableStateOf(ai.token)};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onClose,title={Text("گفتار و هوش مصنوعی")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("زبان ورودی گفتار",color=Mint);Row{FilterChip(selected=language=="en-GB",onClick={language="en-GB"},label={Text("انگلیسی")});Spacer(Modifier.width(8.dp));FilterChip(selected=language=="fa-IR",onClick={language="fa-IR"},label={Text("فارسی")})};Text("برای مکالمه آزاد، نشانی HTTPS سرویس خودتان را وارد کنید. کلید اصلی مدل فقط در سرور نگهداری می‌شود.",fontSize=12.sp);OutlinedTextField(endpoint,{endpoint=it},label={Text("نشانی سرویس /chat")},singleLine=true);OutlinedTextField(token,{token=it},label={Text("کلید دسترسی سرویس")},visualTransformation=PasswordVisualTransformation(),singleLine=true);Text("فقط با روشن کردن حالت آنلاین و زدن ارسال، متن مکالمه به سرویس شما فرستاده می‌شود.",fontSize=11.sp,color=Muted);TextButton(onClick={pendingBackup=store.export();export.launch("Nodin-Layers-backup.json")}){Text("ذخیره پشتیبان محیط‌های جدید")};TextButton(onClick={restore.launch(arrayOf("application/json","text/plain"))}){Text("بازیابی پشتیبان")};if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={if(endpoint.isNotBlank()&&!ai.validEndpoint(endpoint)){error="نشانی باید HTTPS معتبر باشد.";return@TextButton};try{ai.endpoint=endpoint;ai.token=token;status="تنظیمات ذخیره شد.";onClose()}catch(_:Exception){error="ذخیره امن تنظیمات ممکن نشد."}}){Text("ذخیره")}},dismissButton={TextButton(onClick=onClose){Text("بستن")}})}
 companion object{val Navy=Color(0xFF0D1426);val Panel=Color(0xFF19243A);val Mint=Color(0xFF63E6C5);val Lilac=Color(0xFFB2ACFF);val Muted=Color(0xFFACB9D0)}
}
private fun Modifier.testTagCompat(tag:String)=this.testTag(tag)
